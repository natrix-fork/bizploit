# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from core.basePlugins.baseConsolePlugin import baseConsolePlugin
import random

class baseAgent(baseConsolePlugin):
	'''
	This class represents the base for Agents.
	Agents are generated from agents plugins.
	'''
	def __init__( self ):
		baseConsolePlugin.__init__(self)
		self._id = -1
		self._connector = None
		self._target = None
		
		self._kb = None
		self._om = None
	
		
	def setID(self, id):
		self._id = id
	
	def getID(self):
		return self._id
	
	def sh(self):
		'''
		Must be implemented by Agent children
		'''
		raise bizploitException('Method sh must be implemented!')
	
	def getName(self):
		return self.__class__.__name__
		
	def setConnector(self, conn):
		self._connector = conn
	
	def getConnector(self):
		return self._connector
	
	def setTarget(self, target):
		self._target = target
	
	def getTarget(self):
		return self._target

	def stop(self):
		raise bizploitException('Method stop must be implemented!')
	
	def getKB(self):
		return self._kb

	def setKB(self, value):
		self._kb = value
		
	def getOM(self):
		return self._om

	def setOM(self, value):
		self._om = value
