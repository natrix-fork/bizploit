# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
# exceptions
from core.exceptions.bizploitException import bizploitException
from core.exceptions.couldNotConnectException import couldNotConnectException 

import socket
import struct 
import time

class libMon_SAPGATEWAY:
	'''
	SAPGATEWAY Monitor Libary.
	The GW Monitor library listens in the sapgwXX port.
	It is controlled through the gw/monitor profile parameter:
		gw/monitor = 0: Monitor disabled
		gw/monitor = 1: Monitor enabled locally
		gw/monitor = 2: Monitor enabled locally and remotely
	
	@author: Mariano Nu�ez  Di Croce 
	'''
	def __init__( self, gwhost = '', gwserv = '3300'):
		self._socket = None
		self._gwhost = gwhost
		self._gwserv = gwserv
		self._connected = False
		
	def connect(self):
		'''
		Connects with the target SAP Gateway.
		'''
		if self._connected:
			self._socket.close()
			
		dstport = self._gwserv
		self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		# Check if gwserv is port number or port description
		if not dstport.isdigit():
			try:
				dstport = socket.getservbyname(self._gwserv)
			except:
				raise bizploitException('Service ' + self._gwserv + ' cannot be resolved. Check your services file.')
		try:
			self._socket.connect((self._gwhost, int(dstport)))
			self._connected = True
			# TODO: Check access to the monitor.
		except socket.error, msg:
			raise couldNotConnectException(str(msg[1]))
		
		return True
		
	def disconnect(self):
		'''
		Disconnects from current Gateway
		'''
		try:
			self._socket.close()
		except socket.error, msg:
			# We don't care. We'll reconnect later
			pass
		self._connected = False
		
	def call_receive(self, header, command):
		'''
		Sends a Monitor command and process the results
		
		@parameters command: Command packet to send.
		'''
		# Header for monitor commands
		msg = header + command
		# 4-byte length header
		command = struct.pack('!L', len(msg)) + msg
		try:
			self._socket.send(command)
		except socket.error, e:
			raise bizploitException(str(e))
		else:
			try:
				size = self._socket.recv(4)
				size = struct.unpack('!L', size)[0]
				# Receive the rest
				data = ''
				while len(data) < size:
					data += self._socket.recv(size)				
				return data
				
			except Exception, e:
				raise bizploitException('SAP Gateway Monitor communication error. If the \'shutdown\' command was issued, it was successful.')
		
		return ''

	def call(self, header, command):
		'''
		Sends a Monitor command
		
		@parameters command: Command packet to send.
		'''
		# Header for monitor commands
		msg = header + command
		# 4-byte length header
		command = struct.pack('!L', len(msg)) + msg
		try:
			self._socket.send(command)
			time.sleep(1)
		except socket.error, e:
			raise bizploitException(str(e))
				
		return 
	
	def isConnected(self):
		return self._connected
