# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

import fwk.connectors.lib.libSAPRFC as libSAPRFC


RFC_STRUCT_MSXXLIST = [{ 'NAME': 'MSNAME',  'TYPE': libSAPRFC.RFCTYPE_CHAR,'LEN':40,  'DESC':'Application Server Name'},  
							 { 'NAME': 'HOST',  'TYPE': libSAPRFC.RFCTYPE_CHAR,'LEN':32,  'DESC':'Name of Application Server'},  
							 { 'NAME': 'SERV',  'TYPE': libSAPRFC.RFCTYPE_CHAR,'LEN':20,  'DESC':'Service'},  
							 { 'NAME': 'MSGTYPES',  'TYPE': libSAPRFC.RFCTYPE_BYTE,'LEN':1,  'DESC':'Services'},  
							 { 'NAME': 'HOSTADR',  'TYPE': libSAPRFC.RFCTYPE_BYTE,'LEN':4,  'DESC':'Host IP address'},  
							 { 'NAME': 'SERVNO',  'TYPE': libSAPRFC.RFCTYPE_BYTE,'LEN':2,  'DESC':'Service port number'},  
							 { 'NAME': 'STATE',  'TYPE': libSAPRFC.RFCTYPE_BYTE,'LEN':1,  'DESC':'Server Status'}
							 ]

RFC_STRUCT_MSXXLIST_SERVICES_MS_DIA = { 'VALUE':1,  'TXT':'Dialog'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_VB  = { 'VALUE':2,  'TXT':'Update'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_ENQ =  { 'VALUE':4,  'TXT':'Enqueue'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_BTC  = { 'VALUE':8,  'TXT':'Batch'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_SPO  = { 'VALUE':16,  'TXT':'Spool'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_VB2  = { 'VALUE':32,  'TXT':'Update2'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_ATP  = { 'VALUE':64,  'TXT':'Atp'}
RFC_STRUCT_MSXXLIST_SERVICES_MS_ICMAN  = { 'VALUE':128,  'TXT':'ICM'}

RFC_STRUCT_MSXXLIST_STATUS_ACTIVE  = { 'VALUE':1,  'TXT':'Active'}
RFC_STRUCT_MSXXLIST_STATUS_PASSIVE  = { 'VALUE':2,  'TXT':'Passive'}
RFC_STRUCT_MSXXLIST_STATUS_SHUTDOWN  = { 'VALUE':3,  'TXT':'Shutdown'}
RFC_STRUCT_MSXXLIST_STATUS_STOP  = { 'VALUE':4,  'TXT':'Stop'}
RFC_STRUCT_MSXXLIST_STATUS_STARTING  = { 'VALUE':5,  'TXT':'Starting'}
RFC_STRUCT_MSXXLIST_STATUS_INITIAL  = { 'VALUE':6,  'TXT':'Initial'}
RFC_STRUCT_MSXXLIST_STATUS_OTHER  = { 'VALUE':-1,  'TXT':'Active'}

def structLen(struct):
	'''
	Calculates the length of a repository structure
	'''
	lng = 0
	for it in struct:
		lng += it['LEN']
	
	return lng
	
