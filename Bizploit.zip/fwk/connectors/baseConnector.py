# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.data.configurable import configurable
from fwk.connectors.libConnWrapper import libConnWrapper as wrapper
from core.exceptions.bizploitException import bizploitException

import core.baseResult.pluginResult as pluginResult

class baseConnector(configurable):
    '''
    base Connector class
    
    @author: Mariano Nu�ez Di Croce 
    '''
    def __init__( self):
        self._connID = -1
        self._connName = ''
        self._lib = None
        self._libMon = None 
        self._conn = None
        self._discovered = False
        
        self._kb = None
        self._om = None
    
    def setConn(self, connObj):
        self._conn = connObj
    
    def getConn(self):
        return self._conn
        
    def setID(self, connID):
        self._connID = connID
    
    def getID(self):
        return self._connID
    
    def getName(self):
        return self._connName
        
    def getConfiguration(self):
        '''
        Returns configuration of the connector for the current target.
        Should be implemented by children.
        '''
        return ''
    
    # Redefine the call and getattr methods for accesing the backend library
    def __getattr__(self, attrName):
        if attrName == 'lib':
            return wrapper(self._lib)
        elif attrName == 'libMon':
            return wrapper(self._libMon)
        else:
            raise AttributeError            

    def confByDiscover(self, system, port):
        '''
        Auto-Configure the connector if the target was DISCOVERED.
        '''
        raise bizploitException('Method confByDiscover not implemented')

    def getSocket(self):
        return self._socket
    
    def checkConnection(self):
        self.connect()
        self.disconnect()

    def __eq__(self,  aConn):
        '''
        Each connector has to implement its own eq method
        '''
        raise 'Connector ' + self._connName + ' has not eq method defined'

    def getDiscovered(self):
        return self._discovered

    def setDiscovered(self, value):
        self._discovered = value
    
    def getKB(self):
        return self._kb

    def setKB(self, value):
        self._kb = value
        
    def getOM(self):
        return self._om

    def setOM(self, value):
        self._om = value
        
    def isConfigurable(self):
        return True
    
    def getFriendlyName(self):
        return self._connName + ' (' + str(self._connID) + ')'

    def getPluginResults(self):
        '''
        Returns a tuple with the following format.
        (vulns high risk, vulns mid risk, vulns low risk, info)
        '''
        high = []
        mid = []
        low = []
        info = []
        
        for plugin in self._kb.getPluginsForConnector(self):
            for key in self._kb.getKeysForPlugin(self, plugin):
                res = self._kb.getResultForKey(self, plugin, key)
                if res and isinstance(res, pluginResult.pluginResult):                
                    if res.getRisk() == pluginResult.RISK_HIGH:
                        high.append(res)
                    elif res.getRisk() == pluginResult.RISK_MEDIUM:
                        mid.append(res)
                    elif res.getRisk() == pluginResult.RISK_LOW:
                        low.append(res)
                    elif res.getRisk() == pluginResult.RISK_INFO:
                        info.append(res)

        return (high, mid, low, info)