# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri <jsantarsieri@onapsis.com>    
    
Base Copyright 2010 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from fwk.connectors.baseConnector import baseConnector
from core.exceptions.bizploitException import bizploitException #@UnresolvedImport
from core.exceptions.couldNotConnectException import couldNotConnectException
import urllib2 as ulib
import base64
import socket
import httplib

class baseJ2EEConnector(baseConnector):

    def __init__(self):
        baseConnector.__init__(self)
        self._host = '127.0.0.1'
        self._port = 80
        self._basePath = ''
        self._isHTTPS = False
        self._vhost = ''
        self._httpUser = ''
        self._httpPassword = ''
        self._authType = 'BASIC'

        self._userAgents = self._loadUserAgents()
        self._currentUA = 'bizploit'
        self._reqHeaders = {}

        self.setReqHeader('User-Agent', self._userAgents['recommended'])
        self._debugHandle = ulib.HTTPHandler(debuglevel=1)
        
        self._secVerified = False
            
    def _loadUserAgents(self):
        map = {}
        map['bizploit'] = 'bizploit v1.00 HTTP Connector'
        map['IE5.5'] = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
        map['recommended'] = 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.2pre) Gecko/20100216'
        return map

    
    def verifySSL(self):
        if self._secVerified == False:
            if self._isHTTPS == True:
                self._secVerified = True
                return True
            else:
                url = 'https://'+self._host+':'+str(self._port)
                try:
                    if ulib.urlopen(url).read():
                        self._secVerified = True
                        return True
                    else:
                        self._secVerified = True
                        return False
                except:
                    self._secVerified = True
                    return False
    
    def _createURL(self):
        '''handler = 'https://' if self._isHTTPS else 'http://'
        if self.verifySSL() == True:
            self._isHTTPS = True'''
            
        handler = 'https://' if self._isHTTPS else 'http://'     
        return '%s%s:%s/' % (handler, self._host, self._port)

    def getDefaultHeaders(self):
        # Check if we have to authenticate the request        
        if self._httpUser or self._httpPassword:
            if self._authType == 'BASIC':
                authstring = base64.encodestring(self._httpUser + ':' + self._httpPassword)[:-1]
                self.setReqHeader('Authorization', 'Basic ' + authstring)

        return self._reqHeaders

    def connect(self):
        '''
        Connects with the remote web server.
        '''
        try:
            req = ulib.Request(self._createURL(), headers=self.getDefaultHeaders())
            ulib.urlopen(req)
        except ulib.URLError, e:
            if hasattr(e, 'code'):
                return True
            else:
                raise couldNotConnectException(str(e))

    def getURI(self, uri, headers={}, okCodes=[200], followRedirect=True, keepSessionCookies=True, specificHandler=None):
        '''
        Gets the requested uri and returns the response object.
        @uri: URI relative to the / directory of the webserver (without the /)
        @headers: optional header values
        @okCodes: list of error codes that mean that the URI check was successful and should return the content anyway
        '''
        handler = None

        # We remove the / in case it's there
        if uri[0] == '/':
            uri = uri[1:]

            
        # Configure request headers
        if not headers:
            headers = self.getDefaultHeaders()

        try:
            req = ulib.Request(self._createURL() + uri, headers=headers)

            if specificHandler:
                handler = specificHandler
            elif followRedirect and keepSessionCookies:
                handler = redirectHandler()

            if handler:
                handler.setCallback(self)
                opener = ulib.build_opener(handler)
                resp = opener.open(req)
            else:
                resp = ulib.urlopen(req)

            # We got a 200. check if we need to store cookies
            if keepSessionCookies and not specificHandler and isinstance(resp, ulib.Request):
                self.addCookie(resp.headers.get('Set-Cookie'))

        except ulib.URLError, cause:
            if hasattr(cause, 'code'):
                if cause.code in okCodes:
                    return cause
            raise bizploitException(str(cause))
        else:
            return resp

    def checkURI(self, uri, headers={},timeout=10):
        '''
        Checks if the requested URI exists. Uses the HEAD method.
        @uri: URI relative to the / directory of the webserver (without the /)
        @headers: optional header values
        @return: the HTTP code.
        '''
        socket.setdefaulttimeout(timeout)
        
        # We remove the / in case it's there
        if uri[0] == '/':
            uri = uri[1:]

        # Configure request headers
        if not headers:
            headers = self.getDefaultHeaders()
        
        try:
            
            target_url  = self.getHost() + self.getBasePath() if(len(self.getBasePath().strip())>0) else self.getHost()
            
            if self._isHTTPS:
                conn = httplib.HTTPSConnection(target_url,self.getPort())
            else:
                conn = httplib.HTTPConnection(target_url,self.getPort())
            if str(uri).startswith('/'):
                conn.request("HEAD", uri)
            else:
                conn.request("HEAD", '/'+uri)
            
            res = conn.getresponse()
            return res.status
        except socket.timeout,e:
            raise couldNotConnectException(str(e))
        except Exception,e:
            return str(e)
        
        
        '''
        last version
        # We remove the / in case it's there
        if uri[0] == '/':
            uri = uri[1:]

        # Configure request headers
        if not headers:
            headers = self.getDefaultHeaders()

        try:
            req = ulib.Request(self._createURL() + uri, headers=headers)
            ulib.urlopen(req)
            return 200
        except ulib.URLError, e:
            if hasattr(e, 'code'):
                return e.code

        return 0
        '''

    def confByDiscover(self, system, port, saprouter=None):
        if saprouter:
                return False

        self._host = system
        self._port = port
        return True

    def getServerHeader(self, headers={}):
        '''
        Connects to the web server, issues a request for the index page and returns the Server header.
        '''
        header = ''
        if not headers:
            headers = self.getDefaultHeaders()

        try:
            req = ulib.Request(self._createURL(), headers=headers)
            resp = ulib.urlopen(req)
        except ulib.URLError, e:
            if hasattr(e, 'code'):
                header = e.headers.dict['server']
        else:
            header = resp.info()['server']

        return header

    def printURL(self, uri):
        '''
        Prints the absolute URL from an uri
        '''

        if uri[0] == '/':
            uri = uri[1:]

        return self._createURL() + uri


    # Standard Methods
    def getOptionsXML(self):
        return '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="host">\
                <default>' + self._host + '</default>\
                <desc>SAProuter host</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>False</visible>\
            </Option>\
            <Option name="port">\
                <default>' + str(self._port) + '</default>\
                <desc>HTTP(S) port</desc>\
                <type>Integer</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
             <Option name="basePath">\
                <default>' + str(self._basePath) + '</default>\
                <desc>Base Path</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="isHTTPS">\
                <default>' + str(self._isHTTPS) + '</default>\
                <desc>Use HTTPS?</desc>\
                <type>Boolean</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="vhost">\
                <default>' + self._vhost + '</default>\
                <desc>Virtual Host</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpUser">\
                <default>' + self._httpUser + '</default>\
                <desc>HTTP User</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpPassword">\
                <default>' + self._httpPassword + '</default>\
                <desc>HTTP Password</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="authType">\
                <default>' + self._authType + '</default>\
                <desc>Authentication Type</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '

    def getHost(self):
        return self._host

    def getPort(self):
        return self._port
    
    def getBasePath(self):
        return self._basePath

    def getIsHTTPS(self):
        return self._isHTTPS

    def setHost(self, value):
        self._host = value

    def setPort(self, value):
        self._port = value

    def setBasePath(self, path):
        self._basePath = path
    
    def setIsHTTPS(self, value):
        self._isHTTPS = value

    def setReqHeader(self, name, value):
        self._reqHeaders[name] = value

    def setCookie(self, value):
        self._reqHeaders['Cookie'] = value

    def addCookie(self, value, appendValue='&'):
        if 'Cookie' in self._reqHeaders.keys():
            listOfCookies = self._reqHeaders['Cookie'].split(appendValue)
            if value not in listOfCookies:
                self._reqHeaders['Cookie'] += appendValue + value
        else:
            self._reqHeaders['Cookie'] = value

    def getUser(self):
        return self._httpUser

    def getPassword(self):
        return self._httpPassword

    def setUser(self, value):
        self._httpUser = value

    def setPassword(self, value):
        self._httpPassword = value

    def getAuthType(self):
        return self._authType

    def setAuthType(self, value):
        self._authType = value



class redirectHandler(ulib.HTTPRedirectHandler):
    '''
    Follows redirects and keeps track of session cookies
    '''

    def setCallback(self, cb):
        self._cb = cb


    def http_error_302(self, req, fp, code, msg, headers):

        # Keep Session cookies
        cookie = headers.get('Set-Cookie')
        if cookie:
            req.add_header('Cookie', cookie)
            self._cb.addCookie(cookie)

        result = ulib.HTTPRedirectHandler.http_error_302(self, req, fp, code, msg, headers)
        result.status = code
        return result

    http_error_301 = http_error_302
