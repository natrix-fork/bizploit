# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author: Jordan Santarsieri <mnunez@onapsis.com>    
    
Copyright 2010 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.couldNotConnectException import couldNotConnectException
from fwk.connectors.baseJ2EEConnector import baseJ2EEConnector #@UnresolvedImport
from core.exceptions.bizploitException import bizploitException #@UnresolvedImport
from core.lib.misc import resolveHostList #@UnresolvedImport
import urllib2 as ulib
import gzip, StringIO
import base64

class connSAPPORTAL(baseJ2EEConnector):
    ''' This connector was specifically developed to connect to SAP Portal.
Created on 15/02/2010
@author: Jordan Santarsieri <jsantarsieri@onapsis.com>'''
    def __init__(self):
        baseJ2EEConnector.__init__(self)
        self._connName = 'SAPPORTAL'
        self._port = 50000
        self._recommendedUA = 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.2pre) Gecko/20100216'

    def getConfiguration(self):
        return  'SAP Portal Host:' + self._host + '\n'  \
                'SAP Portal Port:' + str(self._port) + '\n'  \
                'HTTP / HTTPS:' + ('HTTPS' if self.getIsHTTPS() else 'HTTP')

    def _getResponseCode(self, url):
        data = self.getURI(url, followRedirect=False, okCodes=[200, 500])
        if data.getcode() == 200:
            #Si me da un 200, me fijo en el fuente
            if data.read() != '' and 'Internal Server Error' not in data.read() and 'logonServlet?redirectURL' not in data.url:
                return self._getWebSecurity() + self._host + ':' + str(self._port) + url + ',Anonymous Access'
            else:
                return self._getWebSecurity() + self._host + ':' + str(self._port) + url + ',Restricted Access'
        else:
            return self._getWebSecurity() + self._host + ':' + str(self._port) + url + ',Webdynpro Access Error'

    def _getWebSecurity(self):
        '''
        This method will return the prefix of the website due his security
        '''
        if self._isHTTPS == True:
            return 'https://'
        # FQMAAAICKA==, sap lo devuelve siempre cuando usamos http en un secure port
        elif base64.b64encode(self._getWebContentGET('http://' + self._host + ':' + str(self._port)))== 'FQMAAAICKA==':
            return 'https://'
        else:
            return 'http://'

    def _getWebContentGET(self, url):
        try:
            #Debido a que SAP resulto ser muy delicado con los headers, los fixeo aca
            h = {"User-Agent": self._recommendedUA, "Host":self.getHost(), "Accept":'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language':'en-us,en;q=0.5', 'Accept-Encoding':'gzip,deflate', 'Accept-Charset':'ISO-8859-1,utf-8;q=0.7,*;q=0.7', 'Keep-Alive':'115', 'Cookie':'ServerID=1027; saplb_*=(J2EE26076100)26076151; JSESSIONID=(J2EE26076100)ID1059387751DB10309403815527930284End'}
            r = ulib.Request(url, headers=h)
            f = ulib.urlopen(r)
            if f.headers.get('content-encoding', None) == 'gzip':
                compressedstream = StringIO.StringIO(f.read())
                gzipper = gzip.GzipFile(fileobj=compressedstream)
                data = gzipper.read()
                return data
            else:
                return f.read()
        except ulib.HTTPError, cause:
            raise bizploitException(str(cause))
        except ulib.URLError, cause:
            raise bizploitException(str(cause))


    def anonAccessKM(self):
        '''
        This method will try to access to the km without any credentials
        @return the html code of the km elements
        '''
        #Me aseguro que sea sin passwd
        newObject = connSAPPORTAL()
        newObject.setAuthType('')
        newObject.setHost(self.getHost())
        code = newObject._getWebContentGET(self._getWebSecurity() + str(newObject.getHost()) + "/irj/go/km/navigation/")        
        code = code.split('</')
        tabla = []
        for line in code:
            if 'class="urTxtStd"' in line:
                line = line.split('urTxtStd"')
                tabla.append(line[1].strip())
        return tabla


    def connect(self):
        '''
        Connects with the remote web server.
        '''
        try:
            req = ulib.Request(self._createURL(), headers=self.getDefaultHeaders())
            ulib.urlopen(req)
        except ulib.URLError, e:
            if hasattr(e, 'code'):
                return True
            #else:
        except Exception, e: #agregado por Indio
                raise couldNotConnectException(str(e))

    def confByDiscover(self, system, port, saprouter=None):
        if saprouter:
                return False

        self._host = system
        self._port = port
        return True

    def __eq__(self, aConn):
        '''
        Redefinition of the equals method to compare against other connectors directly in python.
        @param aConn: connector to compare to.
        '''
        # We check if we are comparing against a new connector or an already existing one.
        # We have to do this, otherwise the comparison will always say true if we don't care about IDs.
        if not isinstance(aConn, connSAPPORTAL):
            return False

        myIP = ''
        otherIP = ''
        try:
            myIP, otherIP = resolveHostList([self._host, aConn.getHost()])
        except bizploitException, e:
            self._om.debug(self, 'Error: ' + str(e))

        if self._connID == -1:
            return myIP == otherIP and self._port == aConn.getPort()
        else:
            return self._connID == aConn.getID() and \
                        myIP == otherIP and self._port == aConn.getPort()

    def preconfig(self, target):
        '''
        Preconfigures the connector according to the parent target configuration
        '''
        self._host = target.getHost()

    # Standard Methods
    def getOptionsXML(self):
        return '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="host">\
                <default>' + self._host + '</default>\
                <desc>SAProuter host</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>False</visible>\
            </Option>\
            <Option name="port">\
                <default>' + str(self._port) + '</default>\
                <desc>HTTP(S) port</desc>\
                <type>Integer</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="isHTTPS">\
                <default>' + str(self._isHTTPS) + '</default>\
                <desc>Use HTTPS?</desc>\
                <type>Boolean</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="vhost">\
                <default>' + self._vhost + '</default>\
                <desc>Virtual Host</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpUser">\
                <default>' + self._httpUser + '</default>\
                <desc>HTTP User</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpPassword">\
                <default>' + self._httpPassword + '</default>\
                <desc>HTTP Password</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="authType">\
                <default>' + self._authType + '</default>\
                <desc>Authentication Type</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '
