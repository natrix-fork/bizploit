# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import sys
import struct
import random
import string
import re
import time
import socket
from core.exceptions.bizploitException import bizploitException


'''
This module defines some misc functions that are used around the project.

@author: Mariano Nuñez Di Croce 
'''


def factory(ModuleName, *args):
	'''
	This function creates an instance of a class thats inside a module
	with the same name.
		
	@parameter ModuleName: What do you want to instanciate ?
	@return: An instance.
	'''
	try:
		__import__(ModuleName)
	except ImportError, e:
		print 'Module ' + ModuleName + ' could not be loaded.'
		raise bizploitException('Module ' + ModuleName + ' could not be loaded.', e)
	aModule = sys.modules[ModuleName]
	className = ModuleName.split('.')[len(ModuleName.split('.'))-1]
	aClass = getattr( aModule , className )
	return apply(aClass, args)

def fakeUnicode(raw):
	'''
	This functions receives a raw variable and peforms a conversion to Unicode.
	
	@parameter raw: Data to be converted
	@return: Unicode representation
	'''
	res = ''
	for i in raw:
		res += struct.pack('H', ord(i))
	return res


def resolveService(port):
	'''
	Check if serv is port number or service name
	
	@parameter port: Port number or name
	@returns: port integer
	'''
	dstport = 0
	if isinstance(port, str) and not port.isdigit():
		try:
			dstport = socket.getservbyname(port)
		except:
			raise bizploitException('Service ' + port + ' cannot be resolved. Check your services file')
	else:
		return int(port)
	
	return dstport
	
def mixCase(str):
	'''
		This function receives a string and returns the same string, but with mixed case.
		
		@parameter str: string to transform
		@return: mixed-case string
		
		@author: Mariano Nuñez Di Croce 
	'''
	res = ''
	for c in str:
		if random.random()>0.5:
			res += string.upper(c)
		else:
			res += string.lower(c)
	return res	

def readFile(srcFile,  ignoreCommentEmpty=False):
	'''
	Reads a file and returns the content in a list.
	'''
	content = []
	try:
		fd = open( srcFile )
		for line in fd:
			line = line.strip()
			if not ignoreCommentEmpty or (line != '' and line[0] != '#'):					
				content.append(line.strip())
		fd.close()
	except:
		raise bizploitException('Failed to open file : ' + srcFile )
	
	return content

def validateInput(input,  regex):
	if re.compile(regex).match(input):
		return True
	else:
		return False

def getPortRange(rangestr):
	_tmp1 = rangestr.split(',')
	numericrange = list()
	xrange = anotherxrange
	for _tmp2 in _tmp1:
		_tmp3 = _tmp2.split('-',1)
		if len(_tmp3) > 1:
			if not (_tmp3[0].isdigit() or _tmp3[1].isdigit()):
				print "The ranges need to be digits"
				return []
			startport,endport = map(int,[_tmp3[0],_tmp3[1]])
			endport += 1
			numericrange.append(xrange(startport,endport))
		else:
			if not _tmp3[0].isdigit():
				print "The ranges need to be digits"
				return []
			singleport = int(_tmp3[0])
			numericrange.append(xrange(singleport,singleport+1))
	return numericrange

class anotherxrange(object):
	"""A pure-python implementation of xrange.

	Can handle float/long start/stop/step arguments and slice indexing"""

	__slots__ = ['_slice']
	def __init__(self, *args):
		self._slice = slice(*args)
		if self._slice.stop is None:
			# slice(*args) will never put None in stop unless it was
			# given as None explicitly.
			raise TypeError("xrange stop must not be None")

	@property
	def start(self):
		if self._slice.start is not None:
			return self._slice.start
		return 0
	@property
	def stop(self):
		return self._slice.stop
	@property
	def step(self):
		if self._slice.step is not None:
			return self._slice.step
		return 1

	def __hash__(self):
		return hash(self._slice)

	def __cmp__(self, other):
		return (cmp(type(self), type(other)) or
				cmp(self._slice, other._slice))

	def __repr__(self):
		return '%s(%r, %r, %r)' % (self.__class__.__name__,
								   self.start, self.stop, self.step)

	def __len__(self):
		return self._len()

	def _len(self):
		return max(0, int((self.stop - self.start) / self.step))

	def __getitem__(self, index):
		if isinstance(index, slice):
			start, stop, step = index.indices(self._len())
			return xrange(self._index(start),
						  self._index(stop), step*self.step)
		elif isinstance(index, (int, long)):
			if index < 0:
				fixed_index = index + self._len()
			else:
				fixed_index = index

			if not 0 <= fixed_index < self._len():
				raise IndexError("Index %d out of %r" % (index, self))

			return self._index(fixed_index)
		else:
			raise TypeError("xrange indices must be slices or integers")

	def _index(self, i):
		return self.start + self.step * i

def iprange(args):
	# If it is a list of targets, parse them all
	ranges = [x.strip() for x in args.split(',')]	
	
	for arg in ranges:		
		try:
			r = getranges(arg)
		except bizploitException,  e:
			raise e
			
		if r is None:
			continue
		
		startip,endip = r
		curip = startip
		
		if isinstance(curip, str):
				yield(curip)
		else:	
			while curip <= endip:
				yield(numToDottedQuad(curip))
				curip += 1

def getranges2(ipstring):
    _tmp = ipstring.split('.')
    if len(_tmp) != 4:
        raise ValueError, "needs to be a Quad dotted ip"
    _tmp2 = map(lambda x: x.split('-'),_tmp)
    startip = list()
    endip = list()
    for dot in _tmp2:
        if dot[0] == '*':
            startip.append('0')
            endip.append('255')
        elif len(dot) == 1:
            startip.append(dot[0])
            endip.append(dot[0])
        elif len(dot) == 2:
            startip.append(dot[0])
            endip.append(dot[1])
    naddr1 = '.'.join(startip)
    naddr2 = '.'.join(endip)
    return(naddr1,naddr2)


def getranges(ipstring):
	ipstring = ipstring.strip()
	if re.match(
		'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}-\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$',
		ipstring
		):
		naddr1,naddr2 = map(dottedQuadToNum,ipstring.split('-'))
	elif re.match(
		'^(\d{1,3}(-\d{1,3})*)\.(\*|\d{1,3}(-\d{1,3})*)\.(\*|\d{1,3}(-\d{1,3})*)\.(\*|\d{1,3}(-\d{1,3})*)$',
		ipstring
		):
		naddr1,naddr2 = map(dottedQuadToNum,getranges2(ipstring))
	elif re.match(
		'^.*?\/\d{,2}$',
		ipstring
		):
		r = getmaskranges(ipstring)
		if r is None:
			return
		naddr1,naddr2 = r
	else:
		# we attempt to resolve the host
		from socket import gethostbyname
		try:
			dottedQuadToNum(gethostbyname(ipstring))
			naddr1 = ipstring
			naddr2 = naddr1
		except socket.error:
			raise bizploitException('Could not resolve \'%s\'' % ipstring)
			return
	return((naddr1,naddr2))

def getmaskranges(ipstring):
    addr,mask = ipstring.rsplit('/',1)
    if not re.match('^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$',addr):
        from socket import gethostbyname
        try:
            print 'Could not resolve %s' % addr
            addr = gethostbyname(addr)
        except socket.error:
            return

    naddr = dottedQuadToNum(addr)
    masklen = int(mask)
    if not 0 <= masklen <= 32:
        raise ValueError
    naddr1 = naddr & (((1<<masklen)-1)<<(32-masklen))
    naddr2 = naddr1 + (1<<(32-masklen)) - 1
    return (naddr1,naddr2)

def dottedQuadToNum(ip):
    "convert decimal dotted quad string to long integer"
    return struct.unpack('!L',socket.inet_aton(ip))[0]

def numToDottedQuad(n):
		"convert long int to dotted quad string"
		return socket.inet_ntoa(struct.pack('!L',n))


def validateID(id,  id_name,  idList=None):
	'''
	Validates that the specified id is numerical and is present in the id list.
	'''
	res = 0
	try:
		res = int(id)
	except:
		raise bizploitException('The ' + id_name + ' ID must be numerical.')	
			
	if idList !=None and res not in idList:
		raise bizploitException('Error: ' + id_name +' ID ' + str(res) + ' is not available.')
	
	return res

def timestamp(format=0):
    lt = time.localtime(time.time())
    if format == 0:
        return "%04d%02d%02d_%02d%02d%02d" % (lt[0], lt[1], lt[2], lt[3], lt[4], lt[5])
    elif format == 1:
        return "%04d-%02d-%02d %02d:%02d:%02d" % (lt[0], lt[1], lt[2], lt[3], lt[4], lt[5])


def resolveHostList(host_list):
	'''
	Resolves hostsnames to ips for comparison in targets and connectors
	@return: ip_host1, ip_host2, ... - Exception if failure
	'''	
	res = []
	
	for host in host_list:
		try:
			myIP = socket.gethostbyname(host)			
		except Exception,  e:
			raise bizploitException('It is impossible to resolve target hostname \'' + host + '\'. Check your DNS configuration.')
		else:
			res.append(myIP)
	
	return res		
	