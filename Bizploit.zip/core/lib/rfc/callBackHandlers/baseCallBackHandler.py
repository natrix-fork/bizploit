# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
class baseCallBackHandler:
	'''
	This class represents a base callback handler to use in external registered servers.
	Callback handlers should inherit from it and MUST implement the handler() method.
	'''
	def __init__(self):
		self.cnt = 0
		self._bizploit = None
		self._commands = []
		self._om = None
		self._kb = None
		self._parent = None
	
	def LoopHandler(self, srfc):
		self.cnt += 1
		if self.cnt >= 30000:
				return -1
		return 1
		
	def handler(self, iface, srfc):
		'''
		Implement Function Call handling code in concrete callback handlers.
		'''
	
	# This is ugly!!!
	def setCore(self, bizploit):
		self._bizploit = bizploit
	
	def setCommands(self, commands):
		self._commands = commands
		
	def getKB(self):
		return self._kb

	def setKB(self, value):
		self._kb = value
		
	def getOM(self):
		return self._om

	def setOM(self, value):
		self._om = value
	
	def setParent(self, value):
		self._parent = value
