# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from string import letters, digits
from random import choice, randint

class fuzzer:
	'''
	This class ain't a real fuzzer! It's only used to generate random-like strings for some stealthness or specific needs.
	'''

	def createRandAlpha(self, length=0):
		'''
		Create a random string ONLY with letters
		
		@return: A random string only composed by letters.
		'''
		if length == 0:
			jibber = ''.join([letters])
			ru = ''.join([choice(jibber) for x in range(randint(10, 30))])
		else:
			jibber = ''.join([letters])
			ru = ''.join([choice(jibber) for x in range(length)])
		return ru
		
	def createRandAlNum(self, length=0):
		'''
		Create a random string with random length
		
		@return: A random string of with length > 10 and length < 30.
		'''
		if length == 0:
			jibber = ''.join([letters, digits])
			ru = ''.join([choice(jibber) for x in range(randint(10, 30))])
		else:
			jibber = ''.join([letters, digits])
			ru = ''.join([choice(jibber) for x in range(length)])
		return ru

	def createRandNum(self, length=0):
		'''
		Create a random string ONLY with numbers
		
		@return: A random string only composed by numbers.
		'''
		if length == 0:
			jibber = ''.join([digits])
			ru = ''.join([choice(jibber) for x in range(randint(10, 30))])
		else:
			jibber = ''.join([digits])
			ru = ''.join([choice(jibber) for x in range(length)])
		return ru
		
