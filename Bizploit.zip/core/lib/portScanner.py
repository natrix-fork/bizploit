# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import core.kb.knowledgeBase as kb
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
import socket
import sys
import threading
import core.lib.misc as misc
import Queue

# TODO: Stop adding TODOs!
# TODO: Fingerprinting... not really worth it right now...
# TODO: UDP Scanning
# TODO: Stealth scanning.
# TODO: Add port descriptions. Too boring..

class portScanner():
    '''
    Performs TCP port scanning over defined target.
    Useful for discovery stage.
    Mode can be one of:
        sap: Perform quick SAP related ports scan.
        normal: Perform SAP related ports + interesting/administration ports.
        full: Perform full TCP port scan.
        else -> port range: e.g 3300-3400,22,21,3600-3650
    
    @author: Mariano Nu�ez Di Croce 
    '''
    def __init__(self, targetIP, mode,  maxThreads=30):
        self._targetIP = targetIP
        self._mode = mode
        self._maxThreads = maxThreads
        self._socket = None
        self._openPorts = {}
        self._closedPorts = {}
        self._filteredPorts = {}
        self._timeout = 3
        self._portDbNormal = {}
        self._portDbSAP = {}
        self._stopScan = threading.Event()
        
        self._createPortsDB()
        
    def scanTCP(self):
        '''
        Performs TCP connect() scan.
        '''
        ports = []
        om.out.debug(self,'Creating port list...')
        ports = self.createPortList(self._mode)
        
        self._clearPorts()
        res = self.scan(self._targetIP,  ports)
        
        if not res:
            return False
        else:
            open = res[0]
            closed = res[1]
            filtered = res[2]
        
        return {'open':open, 'closed':closed, 'filtered':filtered}
        
    def scan(self,  ip,  ports ):
        toscan = Queue.Queue()
        scanned = Queue.Queue()
        closed = []
        open = []
        filtered = []
        hostports = []
        scanners = []
        
        if len(ports) == 0:
            return False
        
        for i in range(len(ports)):
            hostports.append((ip, ports[i]))

        for hostport in hostports:
            toscan.put(hostport)

        scanners = [Scanner(toscan, scanned, timeout=self._timeout, stop_event=self._stopScan) for i in range(self._maxThreads)]

        for scanner in scanners:
            scanner.start()
        
        results = {}
        for host, port in hostports:
            while (host, port) not in results:
                if self._stopScan.isSet():
                    return False
                nhost, nport, nstatus = scanned.get()
                results[(nhost, nport)] = nstatus
            status = results[(host, port)]
            if status == 'CLOSED':
                closed.append(port)
            elif status == 'OPEN':
                open.append(port)
            else:
                filtered.append(port)

        open.sort()
        closed.sort()
        filtered.sort()

        toscan.join()

        self._stopScan.clear()

        return open, closed, filtered
    
    def stopScanner(self):
        self._stopScan.set()

    def setPortState(self, state, port):
        portDict = self.getPortInfo(port)
        if state == 'open':
            self._openPorts[port] = portDict
        elif state == 'filtered':
            self._filteredPorts[port] = portDict
        else:
            self._closedPorts[port] = portDict
    
    def createPortList(self, mode):
        ports = []
        if mode == 'sap':
            ports = self._getSapPorts()
        elif mode == 'normal':
            ports = self._getNormalPorts()
        elif mode == 'full':
            ports = self._getFullPorts()
        else:
            ports = self._createPortRange(mode)

        return ports

    def pingTCP(self):
        '''
        Do a TCP ping to the target host.
        '''
        ports = [21, 22, 80, 443, 3200, 3300, 3600,50000]
        open, closed, filtered = self.scan(self._targetIP, ports)

        if len(open) or len(closed):
            return True

        return False
    
    
    def _getNNPorts(self, port, exc=[]):
        '''
        Returns a list of numerical ports, based on the SAP port format.
        Can exclude (exc) some ports. 
        TODO: Avoid excluding, based on fingerprinting.
        E.g:
        32XX: 3200-3299
        5NN01: 50001-59901.
        '''
        res = []
        if not 'NN' in port:
            return []
        else:
            port = port.split('NN')
            for i in range(0, 99):
                num = "%.2i" % (i,)
                resPort = int(port[0] + num + port[1])
                if resPort not in exc:
                    res.append(resPort)

        return res
    
    def getPortInfo(self, port):
        if port in self._portDbSAP.keys():
            return self._portDbSAP[port]
        elif port in self._portDbNormal.keys():
            return self._portDbNormal[port]
        else:
            return {'connectors':[], 'name':'', 'desc':''}

    def _clearPorts(self):
        self._openPorts = {}
        self._closedPorts = {}
    
    def _createPortsDB(self):
        '''
        Creates the ports database for the scanning process
        '''

        # SAP PORTS DB

        # Just for reverse proxies and different port mappings
        self._addSapPortDB(80, [], 'HTTP', '')
        self._addSapPortDB(443, [], 'HTTPS', '')

        # Netweaver ABAP + ICM
        for i in self._getNNPorts('32NN', exc=[3299]):  self._addSapPortDB(i, [], 'SAP Dispatcher', 'SAP Dispatcher, used by SAPGUI.')
        for i in self._getNNPorts('33NN', exc=[3389]): self._addSapPortDB(i, ['SAPRFC', 'SAPGATEWAY'], 'SAP Gateway', 'SAP Gateway, used for CPIC and RFC communications.')
        for i in self._getNNPorts('48NN'):  self._addSapPortDB(i, [], 'SAP Secure Gateway', 'Secure SAP Gateway, used for CPIC/RFC over SNC.')
        for i in self._getNNPorts('80NN'):  self._addSapPortDB(i, ['SAPICM'], 'SAP ICM HTTP', '')
        for i in self._getNNPorts('443NN'):  self._addSapPortDB(i, ['SAPICM'], 'SAP ICM HTTPS', '')
        for i in self._getNNPorts('36NN'): self._addSapPortDB(i, [], 'SAP Message Server', '')
        for i in self._getNNPorts('81NN'): self._addSapPortDB(i, [], 'SAP Message Server HTTP', '')
        for i in self._getNNPorts('444NN'): self._addSapPortDB(i, [], 'SAP Message Server HTTPS', '')

        # Netweaver JAVA
        for i in self._getNNPorts('5NN00'): self._addSapPortDB(i, ['SAPPORTAL'], 'SAP J2EE Dispatcher - HTTP', '')
        for i in self._getNNPorts('5NN01'): self._addSapPortDB(i, ['SAPPORTAL'], 'SAP J2EE Dispatcher - HTTPS', '')
        for i in self._getNNPorts('5NN02'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - IIOP Initial Context', '')
        for i in self._getNNPorts('5NN03'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - IIOP Initial Context (SSL)', '')
        for i in self._getNNPorts('5NN04'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - P4', '')
        for i in self._getNNPorts('5NN05'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - P4 over HTTP', '')
        for i in self._getNNPorts('5NN06'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - P4 over HTTPS', '')
        for i in self._getNNPorts('5NN07'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - IIOP', '')
        for i in self._getNNPorts('5NN08'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - Telnet', '')
        for i in self._getNNPorts('5NN10'): self._addSapPortDB(i, [], 'SAP J2EE Dispatcher - JMS', '')

        # SAP Netweaver AS Administrative Services
        self._addSapPortDB(1128, ['SAPHOSTCONTROL'], 'SAPHostControl', '')
        self._addSapPortDB(1129, ['SAPHOSTCONTROL'], 'SAPHostControlS', '')
        for i in self._getNNPorts('5NN13'): self._addSapPortDB(i, ['SAPMC'], 'SAP Start Service', '')
        for i in self._getNNPorts('5NN14'): self._addSapPortDB(i, ['SAPMC'], 'SAP Start Service', '')

        # SAP IGS
        for i in self._getNNPorts('4NN00'): self._addSapPortDB(i, [], 'SAP IGS - Multiplexer', '')
        for i in self._getNNPorts('4NN01'): self._addSapPortDB(i, [], 'SAP IGS - Portwatcher', '')
        for i in self._getNNPorts('4NN02'): self._addSapPortDB(i, [], 'SAP IGS - Portwatcher', '')
        for i in self._getNNPorts('4NN80'): self._addSapPortDB(i, [], 'SAP IGS - HTTP Administration', '')

        # Installation & Upgrade Tools
        for i in self._getNNPorts('5NN17'): self._addSapPortDB(i, [], 'SAP SDM or SL controller(Administration)', '')
        for i in self._getNNPorts('5NN18'): self._addSapPortDB(i, [], 'SAP SDM or SL controller(GUI)', '')
        for i in self._getNNPorts('5NN19'): self._addSapPortDB(i, [], 'SAP SDM or SL controller(HTTP)', '')
        self._addSapPortDB(21212, [], 'SAPinst', '')
        self._addSapPortDB(21213, [], 'SAPinst', '')
        self._addSapPortDB(59975, [], 'SAPinst on IBM AS400 iSeries', '')

        self._addSapPortDB(59976, [], 'SAPinst on IBM AS400 iSeries', '')
        self._addSapPortDB(4238, [], 'SAP Upgrade - Monitoring', '')
        self._addSapPortDB(4239, [], 'SAP Upgrade - UA-server (HTTP)', '')
        self._addSapPortDB(4240, [], 'SAP Upgrade - R3up process', '')
        self._addSapPortDB(4241, [], 'SAP Upgrade - UA-server', '')

        # Utilities
        self._addSapPortDB(3299, ['SAPROUTER'], 'SAProuter', '')
        self._addSapPortDB(3298, [], 'SAP niping test program', '')
        self._addSapPortDB(515, [], 'SAPlpd', '')


        # ITS - AGate - IACOR -...
        self._addSapPortDB(3950, [], 'SAP ITS - IACOR', '')
        self._addSapPortDB(3951, [], 'SAP ITS - IACOR', '')
        self._addSapPortDB(3954, [], 'SAP ITS - AGate', '')
        self._addSapPortDB(3964, [], 'SAP ITS - AGate', '')

        # Databases
        self._addSapPortDB(1433, [], 'Microsoft SQL Server', '')
        self._addSapPortDB(1527, [], 'Oracle', '')
        self._addSapPortDB(50000, [], 'IBM DB6 (AIX)', '')
        self._addSapPortDB(4402, [], 'IBM DB2 (OS/400)', '')
        self._addSapPortDB(7200, [], 'MaxDB', '')
        self._addSapPortDB(7210, [], 'MaxDB', '')
        self._addSapPortDB(7269, [], 'MaxDB', '')
        self._addSapPortDB(7270, [], 'MaxDB', '')
        self._addSapPortDB(7275, [], 'MaxDB', '')

        # NORMAL  PORTS DB
        self._addNormalPortDB(21, [], 'FTP', '')
        self._addNormalPortDB(22, [], 'SSH', '')
        self._addNormalPortDB(23, [], 'Telnet', '')
        self._addNormalPortDB(25, [], 'SMTP', '')
        self._addNormalPortDB(80, [], 'HTTP', '')
        self._addNormalPortDB(443, [], 'HTTPS', '')
        self._addNormalPortDB(110, [], 'POP', '')
        self._addNormalPortDB(3389, [], 'Terminal Services', '')
            
        
    def _addSapPortDB(self, port, connectors, name, desc):
        '''
        Adds a new port definitions to the SAP Ports Database.
        '''
        if not self._portDbSAP.has_key(port):
            self._portDbSAP[port] = {'connectors':connectors, 'name':name, 'desc':desc}

    def _addNormalPortDB(self, port, connectors, name, desc):
        '''
        Adds a new port definitions to the Normal Ports Database.
        '''
        if not self._portDbNormal.has_key(port):
            self._portDbNormal[port] = {'connectors':connectors, 'name':name, 'desc':desc}

    def _getSapPorts(self):
        return [p for p in self._portDbSAP.keys()]

    def _getNormalPorts(self):
        ports = []
        ports = self._getSapPorts()
        ports.extend(self._portDbNormal.keys())
        return ports

    def _getFullPorts(self):
        ports = []
        for p in range(1, 65535):
            ports.append(p)
        return ports

    def _createPortRange(self, portRange):
        '''
        Creates port definitions from port ranges. 
        e.g: 3200,3300-3310,80,25,110
        '''
        range = []
        ports = []
        try:
            range = misc.getPortRange(portRange)
        except:
            raise bizploitException('Invalid port range.')
        else:
            for x in range:
                for p in x:
                    ports.append(p)

        return ports

class Scanner(threading.Thread):
    def __init__(self, inq, outq, timeout=1, stop_event=None):
        threading.Thread.__init__(self)
        # queues for (host, port)
        self.setName("Scanner")
        self.inq = inq
        self.outq = outq
        self._timeout = timeout
        self._stopScan = stop_event

    def run(self):
        while not self.inq.empty():
            if self._stopScan.isSet():
                break
            try:
                host, port = self.inq.get(False)
            except Exception, e:
                break
            sd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sd.settimeout(self._timeout)
            try:
                #ACA Para debuggear
                sd.connect((host, port))
                sd.close()
            except socket.timeout:
                sd.close()
                self.outq.put((host, port, 'FILTERED'))
            except socket.error, e:
                code, msg = e
                if code == 113:
                    # No route to host
                    sd.close()
                    self.outq.put((host, port, 'FILTERED'))
                else:
                    self.outq.put((host, port, 'CLOSED'))
            except Exception:
                sd.close()
                # Weird exception, add as filtered
                self.outq.put((host, port, 'FILTERED'))
            else:
                self.outq.put((host, port, 'OPEN'))
            self.inq.task_done()