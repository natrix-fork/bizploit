# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import core.output.outputManager as om
import threading
import socket

class httpserver(threading.Thread):
	'''
	HTTP Server for many uses.
	'''

	def __init__( self, ip, port,  handler):
		threading.Thread.__init__(self)
		self._ip = ip
		self._port = port
		self._handler = handler
		self._server = None
		self._go = True
		self._running = False
	
	def isRunning( self ):
		return self._running
		
	def stop(self):
		om.out.debug(self, 'Trying to stop the webserver.')
		if self._running:
			self._server.server_close()
			self._go = False
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			try:
				s.connect((self._ip, self._port))
				s.send('GET / HTTP/1.0\n\n')
				s.close()
			except Exception, e:
				om.out.debug(self, 'The webserver was already closed when tried to be closed.')
			self._running = False
		
	def run(self):
		'''
		Starts the http server.
		'''
		try:
			om.out.debug(self, 'Starting httpserver on ' + self._ip +':' + str(self._port) + ' ...')
			
			self._server = bizploitHTTPServer((self._ip, self._port), self._handler )
		except Exception, e:
			om.out.error(self, self, self,'Failed to start webserver, error: ' + str(e) )
		else:
			message = 'Web server listening on '+ self._ip + ':'+ str(self._port)
			om.out.debug(self,  message )
			self._running = True
			
			while self._go:
				try:
					self._server.handle_request()
				except KeyboardInterrupt, k:
					raise k
				except:
					self._server.server_close()
				
class bizploitHTTPServer( HTTPServer ):
	def server_bind(self):
		self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		HTTPServer.server_bind( self )
	
