# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import os,sys
from core.lib.misc import factory
from core.exceptions.bizploitException import bizploitException

class outputManager:
	'''
	This class manages output. 
	It has a list of output plugins and sends the events to every plugin on that list.
	
	@author: Andres Riancho ( andres.riancho@gmail.com )
	'''
	
	def __init__(self):
		self._outputPluginList = []
		self._pluginsOptions = {}
		self._levels = ['info',]
		self._cache = {}
		self._kb = None
		self._timestampEcho = False

	
	def setLevels(self, levels):
		'''
			Sets levels of output verbosity.
			
			@parameter levels: List containing levels of output verbosity.
				'info' = information messages
				'debug' = debug messages
				'error' = error messages
				'vuln' = vulnerability
		'''
		self._levels = levels

	def getLevels(self):
		'''
			Gets levels of output verbosity.
		'''
		return self._levels

	def quiet(self):
		''' 
		Stop outputing data.
		'''
		self._tmp = self._levels
		self._levels = []
		
	def talk(self):
		''' 
		Restarts outputing data.
		'''
		self._levels = self._tmp
	
	def getOutputPlugins(self):
		return self._outputPluginList
	
	def _addOutputPlugin(self, OutputPluginName ):
		'''
		Takes a string with the OutputPluginName, creates the object and adds it to the OutputPluginName
		
		@parameter OutputPluginName: The name of the plugin to add to the list.
		@return: No value is returned.
		'''
		if OutputPluginName == 'all':
			fileList = [ f for f in os.listdir('plugins' +os.path.sep +'output'+os.path.sep) ]    
			strReqPlugins = [ os.path.splitext(f)[0] for f in fileList if os.path.splitext(f)[1] == '.py']
			strReqPlugins.remove ( '__init__' )
			
			for pluginName in strReqPlugins:
				plugin = factory( 'plugins.output.' + pluginName )
				
				if pluginName in self._pluginsOptions.keys():
					plugin.setOptions( self._pluginsOptions[pluginName] )
				
				# Append the plugin to the list
				plugin.setKB(self._kb)
				plugin.initialize()
				self._outputPluginList.append( plugin )
		
		else:
				plugin = factory( 'plugins.output.' + OutputPluginName )
				if OutputPluginName in self._pluginsOptions.keys():
					plugin.setOptions( self._pluginsOptions[OutputPluginName] )
				
				try:
					plugin.checkSanity()
				except bizploitException,  e:
					print "There is a problem with output plugins: " + str(e)					
				else:
					# Append the plugin to the list
					plugin.setKB(self._kb)
					plugin.initialize()
					self._outputPluginList.append( plugin )
				
	def debug(self, sender,  message, context='', newLine = True, timeStampEcho=False ):
		'''
		Sends a debug message to every output plugin on the list.
		
		@parameter message: Message that is sent.
		'''
		if 'debug' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.debug(sender,  message, context, newLine,timeStampEcho)
	
	def information(self, sender,  message, context='', newLine = True, timeStampEcho=False  ):
		'''
		Sends a informational message to every output plugin on the list.
		
		@parameter message: Message that is sent.
		'''
		if 'info' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.information(sender,  message, context, newLine,timeStampEcho)
			
	def error(self, sender,  message, context='', newLine = True, timeStampEcho=False  ):
		'''
		Sends an error message to every output plugin on the list.
		
		@parameter message: Message that is sent.
		'''
		if 'error' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.error(sender, message, context, newLine, self._timestampEcho )

			
	def vulnerability(self, sender,  message, context, newLine = True, timeStampEcho=False ):
		'''
		Sends a vulnerability message to every output plugin on the list.
		
		@parameter message: Message that is sent.
		'''
		if 'vuln' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.vulnerability(sender,  message, context, newLine,timeStampEcho)

	def warning(self, sender,  message, context, newLine = True, timeStampEcho=False ):
		'''
		Sends a warning message to every output plugin on the list.
		
		@parameter message: Message that is sent.
		'''
		if 'warning' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.warning(sender,  message, context, newLine,timeStampEcho)

	def console( self, sender,  message, context='', newLine = True, timeStampEcho=False ):
		'''
		This method is used by the bizploit console to print messages to the outside.
		'''
		for oPlugin in self._outputPluginList:
			oPlugin.console(sender,  message, context, newLine,timeStampEcho)
	
	def log( self, sender,  message, context='', newLine = True, timeStampEcho=False ):
		'''
		This method is used by the bizploit console to log executed commands.
		'''
		if 'log' in self._levels:
			for oPlugin in self._outputPluginList:
				oPlugin.log(sender, message, context, newLine, timeStampEcho)
	
	def setOutputPlugins( self, OutputPlugins ):
		'''
		@parameter OutputPlugins: A list with the names of Output Plugins that will be used.
		@return: No value is returned.
		''' 	
		self._outputPluginList = []
		self._outputPlugins = OutputPlugins
		
		for pluginName in self._outputPlugins:
			self._addOutputPlugin( pluginName )	
		
		
	def setPluginOptions(self, pluginName, PluginsOptions ):
		'''
		@parameter PluginsOptions: A tuple with a string and a dictionary with the options for a plugin. For example:\
		{ console:{'verbosity':7} }
			
		@return: No value is returned.
		''' 		
		self._pluginsOptions[pluginName] = PluginsOptions

	def getMessageCache(self):
		'''
		@return: returns a list containing messages in plugins caches, only if defined.
		'''
		res = []
		for oPlugin in self._outputPluginList:
			plugCache = oPlugin.getMessageCache()
			if plugCache: 
				# Use only defined levels
				for level in self._levels:
					# All information is printed in the same way, independently of its level.
					if plugCache[level]:
						res.extend(plugCache[level])				
		return res
	
	def clean(self):
		for oPlugin in self._outputPluginList:
			oPlugin.clean()

	def getKB(self):
	     return self._kb	
	
	def setKB(self, value):
	     self._kb = value
	
	def enableTimeStamp(self):
		self._timestampEcho = True

	def disableTimeStamp(self):
		self._timestampEcho = False
			
out = outputManager()
