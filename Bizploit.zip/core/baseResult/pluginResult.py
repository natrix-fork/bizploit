# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException

RISK_HIGH = 5
RISK_MEDIUM = 4
RISK_LOW = 3
RISK_NO = 2
RISK_INFO = 1

class pluginResult:
	'''
	Class for handling results from plugins executions.
	'''
	def __init__( self,  plugin):
		self._id = -1
		self._plugin = plugin
		self._results = []
		
		self._vulnID = -1
		self._risk = -1
		self._name = ''
		self._desc = ''
		self._solution = ''
		self._refs = []
		
		# Connection info
		self._target = None
		self._connector = None
		# The data is used to get raw info from other plugins/tools
		self._data = {}
	
	def isVulnerability(self):
		return self._risk >= RISK_LOW
	
	def addResult(self,  baseResult):
		self._results.append(baseResult)
	
	def getResults(self):
		return self._results
	
	def getResultByKey(self,  key):
		for res in self._results:
				if res.getKey() == key:
					return res
					
		return None
	
	def setRisk(self,  risk):
		self._risk = risk
	
	def getRisk(self):
		return self._risk
	
	def getRiskAsString(self):
		if self._risk == RISK_HIGH:
			return 'HIGH'
		elif self._risk == RISK_MEDIUM:
			return 'MEDIUM'
		elif self._risk == RISK_LOW:
			return 'LOW'
		elif self._risk == RISK_NO:
			return ''
		elif self._risk == RISK_INFO:
			return 'INFO'
			
		return '?'
	
	def setName(self,  name):
		self._name = name
	
	def getName(self):
		return self._name
		
	def setDesc(self,  desc):
		self._desc = desc
	
	def getDesc(self):
		return self._desc	
	
	def addRef(self, ref):
		self._refs.append(ref)

	def setRefs(self, refs):
		self._refs = refs

	def getRef(self):
		return self._refs
	
	def setVulnID(self, value):
		self._vulnID = value
	
	def getVulnID(self):
		return self._vulnID
	
	def setData(self, key,  value):
		self._data[key] = value
	
	def getData(self,  key):
		try:
			return self._data[key]
		except:
			raise bizploitException('No value in KB for key: ' + str(key))
	
	def setSolution(self,  solution):
		self._solution = solution
	
	def getSolution(self):
		return self._solution	
		
	def setID(self,  id):
		self._id = id
	
	def getID(self):
		return self._id
		
	def setConnectionInfo(self,  target,  connector):
		self._target = target
		self._connector = connector
	
	def getConnectionInfo(self):
		return self._target,  self._connector

	def __eq__(self, other):
		
		return isinstance(other, pluginResult) and self._vulnID == other.getVulnID() and \
	           self._risk == other.getRisk() and self._name == self.getName()