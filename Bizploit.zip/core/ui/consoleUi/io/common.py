# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Andres Riancho    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Andres Riancho

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

KEY_UP    = '\x1B[A'
KEY_DOWN  = '\x1B[B'
KEY_RIGHT = '\x1B[C'
KEY_LEFT  = '\x1B[D'

KEY_HOME  = '^A'
KEY_END   = '^E'

KEY_BACKSPACE = '\x7F'
