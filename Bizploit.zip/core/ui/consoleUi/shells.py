# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.ui.consoleUi.menu import *
from core.ui.consoleUi.interactiveExploit import *
from core.ui.consoleUi.util import *
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
from core.lib.misc import *

class shellsMenu(menu):
	'''
	Menu for managing shells.
	@author: Mariano Nu�ez Di Croce 

	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)
		self._shells = self._bizploit.getShells()

		self._loadHelp('shells')
	
	def _cmd_show(self, parameters):
		'''
		Show available shells 
		'''
		for shellObj in self._shells:
				om.out.console(self,'Shell ID: ' + str(shellObj.getID()) + ' [' + shellObj.getName() + ']')
				om.out.console(self,'\tTarget information (#' + str(shellObj.getTarget().getID()) + '): ')
				parsedConf = shellObj.getTarget().getConfiguration().split('\n')
				for line in parsedConf:
					om.out.console(self,'\t ' + line)
					
				om.out.console(self,'\t Connector: ' + shellObj.getConnector().getName() + ' (#' + str(shellObj.getConnector().getID()) + ')')
				parsedConf = shellObj.getConnector().getConfiguration().split('\n')
				for line in parsedConf:
					om.out.console(self,'\t ' + line)
		
				om.out.console(self,' ')
	
	def _cmd_kill(self, parameters):
		'''
		Kills a spawned shell
		'''
		if len(parameters) == 0:
			self._cmd_help(['kill'])
		else:
			ids = [s.getID() for s in self._shells]
			id = validateID(parameters[0], 'shell',  idList=ids)
			try:
				id = validateID(parameters[0], 'shell')
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
			
			for shellObj in self._shells:
				if shellObj.getID() == id:
					shellObj.stop()
					self._bizploit.delShell(shellObj)
					om.out.information(self,'Shell #' + str(id) + ' killed.')					
					return 
				
			om.out.information(self,'Shell ID not found.')			


	def _cmd_start(self, parameters):
		'''
		Starts a new shell
		'''
		if len(parameters) == 0:
			self._cmd_help(['start'])
		else:
			ids = [s.getID() for s in self._shells]
			try:
				id = validateID(parameters[0], 'shell',  idList=ids)
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
			
			# Create a menu for the shell and return it
			shellObj = self._bizploit.findShellByID(id)
			om.out.information(self,'Starting shell #' + str(id))
			return interactiveExploitMenu(str(id), self._console, self._bizploit, self,  shellObj)		
			
