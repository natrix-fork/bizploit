# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Andres Riancho    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Andres Riancho

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.ui.consoleUi.menu import *
from core.ui.consoleUi.util import *
from core.basePlugins.basePlugin import basePlugin
from core.basePlugins.baseOutputPlugin import baseOutputPlugin
from core.exceptions.bizploitException import bizploitException
from core.data.options.option import *
        
class configMenu(menu):
    '''
    Generic menu for configuring the configurable items.
    It is used to configure plugins and set url and misc settings.
    @author Alexander Berezhnoy (alexander.berezhnoy |at| gmail.com)
    '''

    def __init__(self, name, console, bizploit, parent, configurable):
        menu.__init__(self, 'config:' + name, console, bizploit, parent)
        self._configurable = configurable
        self._options = self._getOptions(self._configurable)
        self._optDict = {}
        self._memory = {}
        self._plainOptions = {}
        for o in self._options:
            k = o.getName()
            v = o.getDefaultValue()
            self._memory[k] = [v]
            self._plainOptions[k] = v
            self._optDict[k] = o
        self._groupOptionsByTabId()
        self._loadHelp('config')

    def _cmd_view(self, params):
        #col1Len = max([len(o) for o in self._options.keys()]) + 4
        #col2Len = 16
        table = [['Setting', 'Value', 'Description']]
        
        for tabid in self._tabbedOptions.keys():
            tabOpts = self._tabbedOptions[tabid]
            
            orderedKeys = tabOpts.keys()
            orderedKeys.sort(lambda x, y: cmp(tabOpts[x].getOrder(), tabOpts[y].getOrder()))
            
            table += [[o, tabOpts[o].getValueStr(), tabOpts[o].getDesc()] \
                for o in orderedKeys if tabOpts[o].getVisible() == True]           
            table.append([])
        if len(table) > 1:
            table.pop()
        self._console.drawTable(table, True)

    def _groupOptionsByTabId(self):      
        self._tabbedOptions = {}
        for opt in self._options:    
            if opt.getVisible():
                tabid = opt.getTabId()

                if tabid not in self._tabbedOptions:
                    target = {}
                    self._tabbedOptions[tabid] = target
                else:
                    target = self._tabbedOptions[tabid]
                
                target[opt.getName()] = opt

    def _cmd_set(self, params):
        if len(params) < 2:
            om.out.console(self, 'Invalid call to set, please see the help:')
            self._cmd_help(['set'])
        elif params[0] not in [v.getName() for v in self._options]:
            raise bizploitException('Unknown option: ' + params[0])
        else:
            name = params[0]
            value = ''.join(params[1:])

            self._options[name].setValue( value )
            self._plainOptions[name] = value
            mem = self._memory[name]
            if value not in mem:
                mem.append(value)
            
            # We have to translate back the options to the format used by bizploit.
            oldOptions = OptionListTranslateToOldOptionMap(self._options)
            if isinstance( self._configurable, basePlugin ):
                #self._bizploit.setPluginOptions( self._configurable.getType(), self._configurable.getName(), oldOptions )
                self._bizploit.setPluginOptions( self._configurable.getType(),  self._configurable.getName(), oldOptions )
            else:
                try:
                    self._configurable.setOptions( oldOptions )
                except bizploitException, w3:
                    om.out.error(self,  str(w3) )


    def _para_set(self, params, part):
        if len(params) == 0:
            result = suggest( [ i.getName() for i in self._options] , part)
            return result
        elif len(params) == 1:
            paramName = params[0]
            if paramName not in self._options:
                return []

            opt = self._options[paramName]
            paramType = opt.getType()
            if paramType == 'boolean':
                values = [ opt.getDefaultValue() == 'True' and 'False' or 'True']
            else:
                values = self._memory[paramName]


            return suggest(values, part)
        else:
            return []


    def _cmd_help(self, params):
        if len(params)==1:
            optName = params[0]
            if optName in self._optDict:
                opt = self._optDict[optName]
                om.out.console(self, opt.getDesc())
                om.out.console(self, "Type: %s" % opt.getType())
                om.out.console(self, "Current value is: %s" % opt.getDefaultValue())
                return

        menu._cmd_help(self, params)

    def _para_help(self, params, part):
        result = menu._para_help(self, params, part)
        result.extend(suggest(self._optDict, part))
        return result
