# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import core.output.outputManager as om
from core.ui.consoleUi.menu import *

class reportingMenu(menu):
	'''
	Menu for managing agents.
	
	@author: Mariano Nu�ez Di Croce 
	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)

		self._loadHelp('reporting')
	
	def _cmd_save(self, parameters):
		'''
		Save current report to a file
		'''
		if len(parameters) < 2:
			self._cmd_help(['save'])
			return
		
		format = parameters[0].lower()
		file = parameters[1]		
		# Create the report from the core
		self._bizploit.createReport('vulnerability', format, file=file, mode='w' )
		