# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.ui.consoleUi.menu import *
from core.ui.consoleUi.interactiveExploit import *
from core.ui.consoleUi.util import *
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
from core.lib.misc import *
import platform

class toolsMenu(menu):
	'''
	Menu for managing tools.
	@author: Mariano Nu�ez Di Croce 

	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)

		self._loadHelp('tools')
	
	def _cmd_show(self , parameters):
		'''
		Lists all available tools.
		'''
		om.out.console(self,'bizploit available tools:')
		fileList = [ f for f in os.listdir('tools' + os.path.sep) if not f.startswith('.')]
		for file in fileList:
			om.out.console(self,'\t' + file )

	def _cmd_run( self, parameters ):
		'''
		Run an external tool.
		'''
		if len( parameters ) == 0:
			self._cmd_help(['run'])
		else:
			if not parameters[0].count('..'):
				if platform.system() == 'Windows':
					os.system( 'runPython.bat tools' + os.path.sep + parameters[0] + ' '+' '.join( parameters[1:] ))
				else:
					os.system( 'python tools' + os.path.sep + parameters[0] + ' '+' '.join( parameters[1:] ) )
			else:
				om.out.information(self,'bizploit has no path trasversal bugs :)')
	
	def _para_run(self, params, part):
		l = len(params)
		if l==0:
			pos = [ f for f in os.listdir('tools' + os.path.sep) if not f.startswith('.')]			
			return suggest(pos, part)
		return []
	
