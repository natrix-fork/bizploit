# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import copy
from core.ui.consoleUi.menu import *
from core.ui.consoleUi.config import *
from core.ui.consoleUi.util import *
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
from core.data.parseOptions import parseXML
from fwk.connectors.baseTarget import baseTarget
from core.lib.misc import *
import sys

class targetsMenu(menu):
	'''
	Menu for the target configuration.
	@author: Mariano Nu�ez Di Croce 

	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)
		self._tmpTarget = None
		self._tmpDisc = None
		self._tmpConn = None
		
		self._loadHelp('targets')
	
	def _cmd_showAvailableConnectors(self, parameters):
		om.out.console(self, 'Available connectors: ' + ', '.join(self._bizploit.getAvailableConnectors()))	
	
	def _cmd_addTarget(self, parameters):
		'''
		Configure a new target.
		'''
		self._tmpTarget = baseTarget()
		config = configMenu('target', self._console, self._bizploit, self, self._tmpTarget)
		config._setOnExitHandler(self._onCreateTarget)
			
		return config
	
	def _onCreateTarget(self):
		'''
		Callback for target creation
		'''
		aTarget = self._tmpTarget
		
		# Check if the target is an iprange, if so, add each target object
		try:
			targets = [t for t in iprange(aTarget.getHost())]
		except:
			om.out.information(self, 'There is at least one invalid entry in target information \'' + aTarget.getHost() + '\'. Please verify.')
			return 
		
		if len(targets) > 1:
			# Loop Targets and add to Core.
			for t in targets:
				newTarget = baseTarget()
				newTarget.setHost(t)
				self._addToCore(newTarget)				
		else:
			self._addToCore(aTarget)
			
		om.out.information(self,'')

	
	def _cmd_delTarget(self, parameters):
		'''
		Deletes a target.
		'''
		if len(parameters) == 0:
			self._cmd_help(['delTarget'])
			return 
		
		if parameters[0] != 'all':
			# Check for the target id
			ids = [t.getID() for t in self._bizploit.getTargets()]
			try:
				id = validateID(parameters[0], 'target',  idList=ids)
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
			
			targets = [self._bizploit.findTargetByID(id)]
		else:
			# Copy the original list, otherwise works over it concurrently.
			targets = self._bizploit.getTargets()[:]
			if len(targets) == 0:
				om.out.console(self,'There is no target to delete.')		
				return
			
		for target in targets:
			self._bizploit.delTarget(target)
			
		om.out.console(self,'The target(s) has been deleted.')		
	
	def _para_delTarget(self, params, part):
		l = len(params)
		if l==0:
			pos = ['all']
			pos.extend(t.getID() for t in self._bizploit.getTargets())
			return suggest(pos, part)
		return []
	
	def _cmd_show(self, parameters):
		'''
		Shows configured targets.
		'''
		if len(self._bizploit.getTargets()) == 0:
			om.out.information(self,'There are no defined targets.')
			return
			
		om.out.information(self,'')
		for target in self._bizploit.getTargets():
			om.out.information(self,'Target ID: ' + str(target.getID()) )
			om.out.information(self,target.getConfiguration() )
			for connector in target.getConnectors():
				om.out.information(self,'\t[' + connector.getName() + '] (ID=' + str(connector.getID()) + ')')
				for line in connector.getConfiguration().splitlines():
					om.out.information(self,'\t' + line )
				om.out.information(self,'')
	
	def _cmd_addConnector(self, parameters):
		'''
		Add a new target system by connector
		'''
		if len(parameters) < 2:
			self._cmd_help(['addConnector'])
			return 
			
		# Check for the target id
		ids = [t.getID() for t in self._bizploit.getTargets()]
		try:
			id = validateID(parameters[0], 'target',  idList=ids)
		except bizploitException,  e:
			om.out.console(self, str(e))
			return
		
		# Check for the connector
		if parameters[1] not in self._bizploit.getAvailableConnectors():
			om.out.information(self,'Error: Connector ' + parameters[1] + ' is not available.')
			om.out.information(self,'Available connectors: ' + ','.join(self._bizploit.getAvailableConnectors()))
			return
		else:
			# Get the target
			self._tmpTarget = self._bizploit.findTargetByID(id)
			
			self._tmpConn = factory('fwk.connectors.conn' + parameters[1])
			self._tmpConn.preconfig(self._tmpTarget)
			config = configMenu('connector', self._console, self._bizploit, self, self._tmpConn)
			config._setOnExitHandler(self._onAddConnector)
			
		return config
	
	def _para_addConnector(self, params, part):
		l = len(params)
		if l==0:
			pos = [t.getID() for t in self._bizploit.getTargets()]
			return suggest(pos, part)
		elif l==1:
			pos = self._bizploit.getAvailableConnectors()
			return suggest(pos, part)
			
		return []

	def _cmd_editConnector(self, parameters):
		'''
		Edit a Connector
		'''
		if len(parameters) < 2:
			self._cmd_help(['editConnector'])
			return 
			
		# Check for the target id
		ids = [t.getID() for t in self._bizploit.getTargets()]
		try:
			id = validateID(parameters[0], 'target',  idList=ids)
		except bizploitException,  e:
			om.out.console(self, str(e))
			return
		
		# Get the target
		self._tmpTarget = self._bizploit.findTargetByID(id)

		# Check for the connector
		if parameters[1] not in [c.getName() for c in self._tmpTarget.getConnectors()]:
			om.out.information(self,'Error: Connector ' + parameters[1] + ' doesn\'t exist.')
			om.out.information(self,'Available connectors: ' + ','.join([c.getName() for c in self._tmpTarget.getConnectors()]))
			return
		else:
			# Get the connector
			connID = None
			if len(parameters) == 3:
				connID = parameters[2]
			if not connID: 
				for c in self._tmpTarget.getConnectors():
					if parameters[1] == c.getName():
						self._tmpConn = c
						break
			else:
				self._tmpConn = self._tmpTarget.getConnectorByID(connID)

			config = configMenu('connector', self._console, self._bizploit, self, self._tmpConn)
			config._setOnExitHandler(self._onEditConnector)
			
		return config
	
	def _para_editConnector(self, params, part):
		l = len(params)
		if l==0:
			pos = [t.getID() for t in self._bizploit.getTargets()]
			return suggest(pos, part)
		elif l==1:
			self._tmpTarget = self._bizploit.findTargetByID(int(params[0]))
			pos = [c.getName() for c in self._tmpTarget.getConnectors()]
			return suggest(pos, part)
		elif l==2:
			if len(self._tmpTarget.getConnectorsByName(params[1])) > 1: 
				self._tmpTarget = self._bizploit.findTargetByID(int(params[0]))
				pos = [c.getID() for c in self._tmpTarget.getConnectorsByName(params[1])]
				return suggest(pos, part)
		return []
		
	def _onAddConnector(self):
		'''
		Callback for adding connectors to targets
		'''		
		try:
			self._bizploit.addConnectorToTarget(self._tmpTarget,  self._tmpConn)
			om.out.console(self,'Added connector ' + self._tmpConn.getName() + '(' + str(self._tmpConn.getID()) +') to target ' + self._tmpTarget.getHost() + '(' + str(self._tmpTarget.getID()) + ').')	
			om.out.information(self,'')
		except bizploitException:
			om.out.console(self,'Connector with the same configuration already exists. Not adding.')

	def _onEditConnector(self):
		'''
		Callback for editing connectors to targets
		'''		
		try:
			self._bizploit.editConnectorToTarget(self._tmpTarget,  self._tmpConn)
			om.out.console(self,'Edited connector ' + self._tmpConn.getName() + '(' + str(self._tmpConn.getID()) +') to target ' + self._tmpTarget.getHost() + '(' + str(self._tmpTarget.getID()) + ').')
			om.out.information(self,'')
		except bizploitException: 
			om.out.console(self,'Connector could not be edited.')	
		
	def _cmd_delConnector(self, parameters):
		'''
		Deletes a connector from a defined target
		'''
		if len(parameters) < 1:
			self._cmd_help(['delConnector'])
			return
		
		# Check for the connector
		connIDs = [conn.getID() for conn in self._bizploit.getConnectors()]
		try:
			id = validateID(parameters[0], 'connector', idList=connIDs)
		except bizploitException,  e:
			om.out.console(self, str(e))
			return
		
		# Delete the connector
		conn = self._bizploit.findConnectorByID(id)		
		self._bizploit.delConnector(conn)
		om.out.console(self,'The connector has been deleted.')
	
	def _para_delConnector(self, params, part):
		l = len(params)
		if l==0:
			pos = [c.getID() for c in self._bizploit.getConnectors()]
			return suggest(pos, part)
		return []
	
	def _cmd_discoverConnectors(self, parameters):
		'''
		Discover associated connectors of defined targets.
		'''
		if len(parameters) < 1:
			self._cmd_help(['discoverConnectors'])
			return 
			
		# Check for the target id
		ids = [t.getID() for t in self._bizploit.getTargets()]
		id = parameters[0]
		if id != 'all':
			try:
				id = validateID(parameters[0], 'target',  idList=ids)
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
		
		self._tmpID = id
		self._tmpDisc = factory('core.ui.consoleUi.discover')
		config = configMenu('connector', self._console, self._bizploit, self, self._tmpDisc)
		config._setOnExitHandler(self._onDiscoverConnectors)
		
		return config 
	
	def _para_discoverConnectors(self, params, part):
		l = len(params)
		if l==0:
			pos = [t.getID() for t in self._bizploit.getTargets()]
			return suggest(pos, part)		
			
		return []
	
	def _onDiscoverConnectors(self):
		'''
		Callback for discovering connectors.
		'''		
		om.out.information(self,'Connector discovery correctly configured.')
		
		if self._tmpID != 'all':
			targets = [self._bizploit.findTargetByID(self._tmpID)]
		else:
			targets = self._bizploit.getTargets()
		
		for target in targets:
			self._bizploit.runConnectorDiscovery(target,  self._tmpDisc.getMode(),   self._tmpDisc.getPingFirst() )		
		
	def _addToCore(self, aTarget):
		'''
		Adds target to the bizploitCore
		'''
		try:
			self._bizploit.addTarget(aTarget)
			om.out.console(self,'Added target with ID ' + str(aTarget.getID()) + '.')	
		except bizploitException:
			om.out.console(self,'Target with the same configuration already exists. Not adding.')	
	
