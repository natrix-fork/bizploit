# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.reporting.baseReport import baseReport


class baseHTMLReport(baseReport):
    '''
    Base class for the creation of bizploit HTML reports
    
    @author: Mariano Nu�ez Di Croce 
    '''
    def __init__(self, bizploit):
        baseReport.__init__(self, bizploit)
        self._cssStyles = self._defineCSSs()
        
    
    def start(self):
        self._content += '<html>'
    
    def close(self):
        self._content += '</html>'
    
    def addHeader(self, text):
        self._content += '<header>' + text + '</header>'
        
    def setTitle(self, text):
        self.addHeader('<title>' + text + '</title>')
    
    def setCSSStyle(self, style):
        try:
            self._content += '<STYLE TYPE="text/css"><!--' + self._cssStyles[style] + '!--></STYLE>'
        except:
            raise bizploitException('Style \'' + style + '\' not implemented.')
        
    def startBody(self):
        self._content += '<body class=bodStyle>'
    
    def closeBody(self):
        self._content += '</body>'
    
    def startTable(self, style='tabStyle'):
        self._content += '<table class=' + style + '>'
    
    def closeTable(self):
        self._content += '</table>'
    
    def startRow(self, style='rowStyle'):
        self._content += '<tr class=' + style + '>'
    
    def closeRow(self):
        self._content += '</tr>'
        
    def addRowWithColumns(self, columns, rowStyle='rowStyle', fieldStyle='fieldStyle', textStyle='textStyle'):
        self.startRow(style=rowStyle)
        for field in columns:
            self.startField(style=fieldStyle)
            self.addText(field, style=textStyle)
            self.closeField()
        self.closeRow()
            
    
    def startField(self, style='fieldStyle'):
        self._content += '<td class=' + style + '>'
    
    def closeField(self):
        self._content += '</td>'
    
    def addText(self, text, style='textStyle'):
        self._content += '<font class=' + style + '>' + text + '</font>'
    
    def addParagraph(self, text='', style='parStyle'):
        self._content += '<p><font class=' + style + '>' + text + '</font></p>'
    
    def addBR(self, count=1):
        for i in range(0, count):            
            self._content += '<br>'
    
    def _defineCSSs(self):
        styles = {}
        
        styles['style1'] = '<!-- \
                    body.bodStyle {BACKGROUND-COLOR: #FFFFFF; text-align:center; } \
                    A { TEXT-DECORATION: none } \
                    A {COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif } \
                                 A:link {COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif; TEXT-DECORATION:underline } \
                                 A:active {COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif; TEXT-DECORATION:underline } \
                    P {COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif;  FONT-SIZE:8pt} \
                    TD {    COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif; FONT-SIZE:8pt } \
                    TR {    COLOR: #333333; FONT-FAMILY: tahoma,helvetica,sans-serif; FONT-SIZE:8pt } \
                    table.tabSyle { border: 0;} \
                    !-->'
                    
        return styles

