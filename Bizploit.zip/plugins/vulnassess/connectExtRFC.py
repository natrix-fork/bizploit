# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin
import core.baseResult.pluginResult as pluginResult
from core.exceptions.bizploitException import bizploitException

class connectExtRFC(baseVulnAssessPlugin):
	'''
	Detects if it is possible to connect to an External RFC Server.
	
	@author: Mariano Nu�ez Di Croce
	'''
	def __init__(self):
		baseVulnAssessPlugin.__init__( self )
		self._desc = 'Detects if it is possible to connect to an External RFC Server.'
	
	def _run_SAPRFC_EXT( self ):
		
		# Just connect and send an RFC_PING
		call = self._connector.lib.iface('RFC_PING')				
		
		# Connect and send call
		try:
			self._connector.connect()
			self._connector.call_receive(call)
			self._connector.disconnect()
		except bizploitException,  e:
			self.outVulnerability('The RFC Server is not reachable. Check debug information for more detail.')
			self.outDebug(str(e))
		else:
			
			self.outVulnerability('External RFC Server reachable through RFC')
			
			# Create the result object
			resPlugin = pluginResult.pluginResult(self)
			resPlugin.setVulnID(5)
			resPlugin.setName('External RFC Server reachable through RFC')
			resPlugin.setDesc('Is is possible to connect to the remote external RFC server. This situation would allow an attacker to send arbitrary RFC calls to these programs, possibly affecting the security of the related business processes.')
			resPlugin.setRisk(pluginResult.RISK_MEDIUM)
			resPlugin.setData('ExtRFCReachable',  True)
			resPlugin.setConnectionInfo(self._target,  self._connector)
			resPlugin.setSolution('Restrict RFC communications through proper configuration of SAP Gateway security parameters.\n \
								   Use the Netweaver RFC SDK to develop RFC servers, as it provides security improvements over the classical RFC SDK for protecting against different attacks.')
			resPlugin.addRef('http://www.blackhat.com/presentations/bh-europe-07/Nunez-Di-Croce/Whitepaper/bh-eu-07-nunez_di_croce-WP-apr19.pdf')
		
			self.saveToKB('ExtRFCReachable', resPlugin)		
		
			
		
		
