# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult

import xml.dom.minidom as xmllib

class icmInfo(baseVulnAssessPlugin):
    '''
	Checks if the ICM Info service is enabled.
	
	
	@author: Mariano Nu�ez Di Croce
	'''
    def __init__(self):
        baseVulnAssessPlugin.__init__( self )        
        self._service = '/sap/public/info'
        self._desc = 'Checks if the ICM Info service is enabled.'
    
    def _run_SAPICM( self ):
        
        resCode = self._connector.checkURI(self._service)        
        if resCode != 0:
            resAvail = [200, 301, 302, 400, 500]
            
            self.outInformation('Checking if the service is available...')
            
            if resCode in resAvail:
                
                self.outVulnerability('The SAP ICM Info service is enabled at \'%s\'' % self._service)
                    
                resXML = self._connector.getURI(self._service).read()
                rawData,  parsed = self._formatOutput(xmllib.parseString(resXML))
                
                self.outInformation('Remote system information:')                
                for l in parsed.splitlines():
                    self.outInformation(l)
                
                resModule = pluginResult.pluginResult(self)
                resModule.setVulnID(13)
                resModule.setName('SAP ICM Info service is enabled')
                resModule.setDesc('The Info service is enabled in the SAP ICM server. \
                                   This information is highly useful in order to perform further analysis of the target system.')
                resModule.setRisk(pluginResult.RISK_MEDIUM)
                resModule.setData('service',  self._service)
                resModule.setData('systeminfo',  rawData)
                resModule.setConnectionInfo(self._target,  self._connector)
                resModule.setSolution('Verify the need of providing remote access to this service. If there are \
                                      no specific business or technical requirements, it is advisable to disable this service through transaction SICF.')
                resModule.setRefs(['SAP Note 517484', 'SAP Note 1088717'])
                
                tab = tableResult('systeminfo')    
                resModule.addResult(tab)
                tab.setTitle('System information')
                tab.setHeader(('Field','Value'))        
                for c in rawData.keys():
                    tab.addRow((c, rawData[c]))
                          
                
                self.saveToKB('icmservices_dangerous_info', resModule)
                
            else:
                self.outInformation('The service is NOT enabled')
    
    def _formatOutput(self, data):
        '''
        Formats output for sapinfo module.
        '''
        res = {}
        res['RFC Destination'] = data.getElementsByTagName('RFCDEST')[0].childNodes[0].nodeValue
        res['System ID'] = data.getElementsByTagName('RFCSYSID')[0].childNodes[0].nodeValue
        res['Hostname'] = data.getElementsByTagName('RFCHOST2')[0].childNodes[0].nodeValue
        res['IP Address'] = data.getElementsByTagName('RFCIPADDR')[0].childNodes[0].nodeValue
        res['Kernel Release'] = data.getElementsByTagName('RFCKERNRL')[0].childNodes[0].nodeValue
        res['Operating System'] = data.getElementsByTagName('RFCOPSYS')[0].childNodes[0].nodeValue
        res['Release Status of SAP System'] = data.getElementsByTagName('RFCSAPRL')[0].childNodes[0].nodeValue
        res['Central Database System'] = data.getElementsByTagName('RFCDBSYS')[0].childNodes[0].nodeValue
        res['Database Host'] = data.getElementsByTagName('RFCDBHOST')[0].childNodes[0].nodeValue
        res['Machine ID'] = data.getElementsByTagName('RFCMACH')[0].childNodes[0].nodeValue
        res['Character Set'] = data.getElementsByTagName('RFCCHARTYP')[0].childNodes[0].nodeValue
        res['Timezone'] = data.getElementsByTagName('RFCTZONE')[0].childNodes[0].nodeValue + ' (diff from UTC in seconds)'
        #res['Daylight Saving Time'] = data.getElementsByTagName('RFCDAYST')[0].childNodes[0].nodeValue # Not available in SAP ICM Info service
        if data.getElementsByTagName('RFCINTTYP')[0].childNodes[0].nodeValue  == 'LIT':
            res['Integer Format'] = 'Little Endian'
        else:
            res['Integer Format'] = 'Big Endian'
        if data.getElementsByTagName('RFCFLOTYP')[0].childNodes[0].nodeValue  == 'IE3':
            res['Float Type Format'] = 'IEEE'
        else:
            res['Float Type Format'] = 'IBM/370'
        res['RFC Log Version'] = data.getElementsByTagName('RFCPROTO')[0].childNodes[0].nodeValue
        
        ret = ''
        for key in res.keys():
            ret += '\t' + key + ': ' + res[key] + '\n' 
        return (res, ret)
   
