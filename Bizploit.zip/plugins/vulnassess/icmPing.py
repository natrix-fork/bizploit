# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
import core.baseResult.pluginResult as pluginResult 
from core.baseResult.msgResult import msgResult #@UnresolvedImport

class icmPing(baseVulnAssessPlugin):
    '''
	Checks if the ICM Ping service is enabled.
	
	
	@author: Mariano Nu�ez Di Croce
	'''
    def __init__(self):
        baseVulnAssessPlugin.__init__( self )
        self._service = '/sap/public/ping'
        self._desc = 'Checks if the ICM Ping service is enabled.'
    
    def _run_SAPICM( self ):
        
        resCode = self._connector.checkURI(self._service)
        if resCode != 0:
            resAvail = [200, 301, 302, 400, 500]
            
            self.outInformation('Checking if the service is available...')
            
            if resCode in resAvail:
                
                self.outVulnerability('The SAP ICM Ping service is enabled at \'%s\'' % self._service)
                
                resModule = pluginResult.pluginResult(self)
                resModule.setVulnID(14)
                resModule.setName('SAP ICM Ping service is enabled')
                resModule.setDesc('The Ping service is enabled in the SAP ICM server. This service can be used to verify if the backend SAP Application Server is available.')
                resModule.setRisk(pluginResult.RISK_LOW)
                resModule.setData('service',  self._service)
                resModule.setConnectionInfo(self._target,  self._connector)
                resModule.setSolution('Verify the need of providing remote access to this service. If there are no specific business or technical requirements, it is advisable to disable this service through transaction SICF.')
                resModule.setRefs(['SAP Note 517484', 'SAP Note 1088717'])
           
                msg = msgResult('service')
                msg.setData(True)
                msg.setResult('The service is enabled in the remote SAP ICM server')
                resModule.addResult(msg)                                
                
                self.saveToKB('icmservices_dangerous_ping', resModule)
                
            else:
                self.outInformation('The service is NOT enabled')

