# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri <jsantarsieri@onapsis.com>    
    
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
from core.baseResult.tableResult import tableResult
import core.baseResult.pluginResult as pluginResult
from core.baseResult.msgResult import msgResult

class checkAnonKM(baseVulnAssessPlugin):
    '''
    Checks anonymous access to the SAP KM.
    
    
	@author: Jordan Santarsieri <jsantarsieri@onapsis.com>
    '''

    def __init__( self ):            	
        baseVulnAssessPlugin.__init__( self )
        self._desc = 'Checks anonymous access to the SAP KM.'
        
        
    def _run_SAPPORTAL(self):
        self._connector.connect()
        self.outInformation('Trying to access to SAP KM without any credentials... ')
        
        try:                 
            result = self._connector.anonAccessKM()
            if result:   
                             
                self.outVulnerability('It\'s possible to connect to the SAP KM without proper credentials')
               
                resModule = pluginResult.pluginResult(self)
                resModule.setVulnID(64)
                resModule.setName('It\'s possible to Connect with SAP KM Without credentials')
                resModule.setDesc('It\'s possible to Connect with SAP KM Without credentials, at this scenario an attacker could steal private documents from the organization')
                resModule.setRisk(pluginResult.RISK_HIGH)
                resModule.setData('sapkmNOCred',  True)    
                resModule.setConnectionInfo(self._target,  self._connector)
                resModule.setSolution('')
                resModule.setRefs([''])          
                
                tab = tableResult('sapkmNOCred')            
                tab.setTitle('Information:')
                tab.setHeader(('KM Share Name','Access URL'))
                resModule.addResult((tab))           
                listado = []           
                del result[0]
                del result[0]
                for item in result:
                    list = item.split('>')
                    listado.append(list[1])
            
            for item in listado:
                if self._checkValidDate(item.split()[0]) or item.split()[0]=='' or item.split()[0]=='No':
                    pass
                else:
                    tab.addRow((item.split()[0],self._connector._getWebSecurity()+self._connector.getHost()+"/irj/go/km/navigation/"+item.split()[0].strip()))                

            msg = msgResult('sapkmNOCred')
            msg.setResult('To find out more resources, go to '+self._connector._getWebSecurity()+self._connector.getHost()+"/irj/go/km/navigation/")
            resModule.addResult(msg) 
            
            self.saveToKB('sapkmNOCred', resModule)
        except:                         
            self.outInformation('It was not possible to connect to the SAPKM without credentials.')
            return

    ''''
        This method is the responsible of validate the dates given by 
        the different formats addopted by SAP        
    '''
    def _checkValidDate(self,posDate):
        if '/' in posDate: #Si o si es una fecha, las carpetas no admiten ese caracter
            return True
        elif '-' in posDate and len(posDate) == 10 and posDate.find('-') == 2:
            return True
        else:
            return False