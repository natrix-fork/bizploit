# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult

import re

class icmErrorInfodisc(baseVulnAssessPlugin):
    '''
	Checks if the ICM discloses configuration information in error messages.
	
	
	@author: Mariano Nu�ez Di Croce
	'''
    def __init__(self):
        baseVulnAssessPlugin.__init__(self)
        self._desc = 'Checks if the ICM discloses configuration information in error messages.'

    def _run_SAPICM(self):

        self._connector.connect()

        # Get an URL that does not exist to get the error information
        self.outInformation('Sending invalid request to trigger error message...')
        resp = self._connector.getURI('/%00', okCodes=[400])

        data = re.search('Server:</td><td>(.*?)_(.*?)_(.*?)</td>', resp.read())
        if data:

            resInfo = {}
            resInfo['Hostname'] = data.group(1)
            resInfo['SID'] = data.group(2)
            resInfo['SYSNR'] = int(data.group(3))

            self.outVulnerability('Error messages disclose sensitive information')

            # Create the result object
            resModule = pluginResult.pluginResult(self)
            resModule.setVulnID(12)
            resModule.setName('Error messages disclose sensitive information')
            resModule.setDesc('Default error pages from the SAP ICM display some information about the SAP system that can be useful for an attacker in order to perform further attacks to the platform.')
            resModule.setRisk(pluginResult.RISK_LOW)
            resModule.setData('sysinfo', resInfo)
            resModule.setConnectionInfo(self._target, self._connector)
            resModule.setSolution('In order to avoid information disclosure in error messages, the profile parameter \'is/HTTP/show_detailed_errors\' should be set to \'false\'')

            tab = tableResult('info')
            tab.setTitle('Information disclosed in error messages:')
            tab.setHeader(('Name', 'Value'))
            resModule.addResult(tab)

            self.outInformation('Information disclosed in error messages:')
            for c in resInfo.keys():
                self.outInformation(c + ': ' + str(resInfo[c]) + '.')
                tab.addRow((c, str(resInfo[c])))


            self.saveToKB('sysinfo', resModule)

        else:
            self.outInformation('The server does not return descriptive error messages.')
