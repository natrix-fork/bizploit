# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>	
	
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
import core.baseResult.pluginResult as pluginResult
import copy

class icmAdmin(baseVulnAssessPlugin):
	'''
	Checks if the ICM Administration interface is enabled.
	
	
	@author: Mariano Nu�ez Di Croce
	'''
	
	def __init__(self):
		baseVulnAssessPlugin.__init__( self )	   
		self._adminURL = '/sap/admin'
		self._desc = 'Checks if the ICM Administration interface is enabled.'
	
	def _run_SAPICM( self ):
		
		# Clean credentials, to make sure we get a 401
		tmpConn = copy.copy(self._connector)
		tmpConn.setUser('')
		tmpConn.setPassword('')
		tmpConn.setAuthType('')
		
		self.outInformation('Trying to access the administration interface...')
		
		resp = tmpConn.checkURI(self._adminURL)
		
		if resp == 401:	
				
			self.outVulnerability('The SAP ICM Web Administration interface is enabled')
				
			resModule = pluginResult.pluginResult(self)
			resModule.setVulnID(43)
			resModule.setName('The SAP ICM Web Administration interface is enabled')
			resModule.setDesc('The SAP ICM Web Administration interface is available on the target SAP server. \
							   While this interface requires user authentication, it is not advisable to provide \
							   access to administration interfaces to unauthorized systems.')
			resModule.setRisk(pluginResult.RISK_MEDIUM)
			resModule.setData('url',  self._adminURL)
			resModule.setConnectionInfo(self._target,  self._connector)
			resModule.setSolution('Verify the need of providing remote access to this administration interface. \
								   If there are no specific business or technical requirements, it is advisable to \
								   disable this component through transaction RZ10, configuring the value of the  \
								   \'icm/HTTP/admin_<xx>\' profile parameter.')
			resModule.setRefs(['http://help.sap.com/saphelp_nwes70/helpdata/EN/1d/9e0f1737354064b174ac2a39fb7d46/frameset.htm'])
	   
			self.saveToKB('url', resModule)
		
		else:
			self.outInformation('The ICM Web Administration interface is not enabled')

	def validateOptions(self,OptionList):
		'''
		This method will validate the options of the module
		'''
		camposInvalidos = []
		
		if 'adminURL' in OptionList.keys():
			
			if OptionList['adminURL'] == None or len(OptionList['adminURL'].strip()) == 0:
				camposInvalidos.append({ "name": "adminURL", "error": "The Admin URL cannot be empty"})
				return camposInvalidos
	
	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the module has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the module options.
		'''	
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="adminURL">\
				<default>' + self._adminURL +'</default>\
				<desc>URL of the administration interface</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'
