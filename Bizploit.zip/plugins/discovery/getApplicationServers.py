# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin
from core.exceptions.bizploitException import bizploitException
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
from fwk.connectors.lib.repository import *
from fwk.connectors.baseTarget import baseTarget
from core.lib.misc import *
import socket

class getApplicationServers(baseDiscoveryPlugin):
	'''
	Discovers Application Servers associated with a Central Instance.

	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseDiscoveryPlugin.__init__( self )
		self._desc = 'Discovers Application Servers associated with a Central Instance.'
		
	def _run_SAPRFC(self):
		newTargets = []
		
		call = self._connector.lib.iface('RFC_GET_LOCAL_SERVERS')
		hostsTab = self._connector.lib.parm("HOSTS",  "",  self._connector.lib.RFCTABLE, self._connector.lib.RFCTYPE_CHAR, structLen(RFC_STRUCT_MSXXLIST))
		call.addParm(hostsTab)
		
		self._connector.connect()
		try:	
			self._connector.call_receive(call)
		except bizploitException, e:
			msg = str(e)
			self.outDebug(msg)
		
		# Parse the result table and craft the output data
		data = []
		for res in hostsTab.value:
			pos = 0
			dict = {}
			for field in RFC_STRUCT_MSXXLIST:			
				dict[field['NAME']] = res[pos:pos+field['LEN']] .strip()
				pos += field['LEN']
			data.append(dict)
		
		self._connector.disconnect()
		
		# Output the information in a nice way
		if data:
			self.outInformation('SAP Application Servers discovered:')
			for res in data:
				if res['HOST'] == 'localhost':
					res['HOST'] = self._connector.getAshost()
					
				self.outInformation('Host: ' + res['HOST'] + ' (' + self._parseIP(res['HOSTADR']) + ')')
				self.outInformation('SID: ' + self._parseSID(res['MSNAME']) + ' - SYSNR: ' + self._parseSYSNR(res['MSNAME']) )
				self.outInformation('Services: ' + self._parseServices(res['MSGTYPES']))
				self.outInformation('Status: ' + self._parseStatus(res['STATE']))
				self.outConsole('')
		
		# Craft the plugin result object
		resPlugin = pluginResult.pluginResult(self)
		resPlugin.setName('SAP Application Servers discovered')
		resPlugin.setDesc('The SAP Application Servers related to the current server were discovered.')
		resPlugin.setData('otherSAPASs',  data)
		resPlugin.setConnectionInfo(self._target,  self._connector)
		resPlugin.setRisk(pluginResult.RISK_INFO)
		
		tab = tableResult('hostTab')		
		resPlugin.addResult(tab)
		tab.setTitle('SAP Application Servers information')	
		tab.setHeader(('Host','IP', 'SID', 'SYSNR', 'Services', 'Status' ))		
		for res in data:
			tab.addRow((res['HOST'], self._parseIP(res['HOSTADR']), self._parseSID(res['MSNAME']), self._parseSYSNR(res['MSNAME']),self._parseServices(res['MSGTYPES']), self._parseStatus(res['STATE'])))
			
		self.saveToKB('otherSAPASs', resPlugin)
		
		# Shall we create new Targets?
		for res in data:
			aTarget = baseTarget()
			aTarget.setHost(res['HOST'])
			aTarget.setDesc('Application Server of system ' + self._parseSID(res['MSNAME']))
			
			# TODO: Here we should parse services and add specific connectors.
			# At this moment, we are only going to add a new SAPRFC connector :)
			aConn = factory('fwk.connectors.connSAPRFC')
			aConn.preconfig(aTarget)
			aConn.setSysnr(int(self._parseSYSNR(res['MSNAME'])))
			aTarget.addConnector(aConn)
			
			newTargets.append(aTarget)
			
		return newTargets
	
	def _parseIP(self, host):
		try:
			return socket.inet_ntoa(host)
		except:
			return ''
		
	def _parseSID(self,  msname):
		try:
			return msname.split('_')[1]
		except:
			return ''
	
	def _parseSYSNR(self,  msname):
		try:
			return msname.split('_')[2]
		except:
			return ''
	
	def _parseStatus(self,  status):
		
		try:
			status = ord(status)
		except:
			return ''
		
		if status == RFC_STRUCT_MSXXLIST_STATUS_ACTIVE['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_ACTIVE['TXT']
		elif status == RFC_STRUCT_MSXXLIST_STATUS_PASSIVE['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_PASSIVE['TXT']
		elif status == RFC_STRUCT_MSXXLIST_STATUS_SHUTDOWN['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_SHUTDOWN['TXT']
		elif status == RFC_STRUCT_MSXXLIST_STATUS_STOP['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_STOP['TXT']
		elif status == RFC_STRUCT_MSXXLIST_STATUS_STARTING['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_STARTING['TXT']
		elif status == RFC_STRUCT_MSXXLIST_STATUS_INITIAL['VALUE']:
			return RFC_STRUCT_MSXXLIST_STATUS_INITIAL['TXT']
		else:
			return RFC_STRUCT_MSXXLIST_STATUS_OTHER['TXT']
	
	
	
	def _parseServices(self,  serv):
		'''
		Parses services information to a printable format
		'''
		res = []
		
		try:
			serv = ord(serv)
		except:
			return ''
		
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_DIA['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_DIA['TXT'])		
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_VB['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_VB['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_ENQ['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_ENQ['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_BTC['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_BTC['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_SPO['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_SPO['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_VB2['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_VB2['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_ATP['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_ATP['TXT'])
		if serv & RFC_STRUCT_MSXXLIST_SERVICES_MS_ICMAN['VALUE']:
			res.append(RFC_STRUCT_MSXXLIST_SERVICES_MS_ICMAN['TXT'])
		
		if res:		
			return ', '.join(res)
		
		return ''
		
