# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin
from core.exceptions.bizploitException import bizploitException
from fwk.connectors.baseTarget import baseTarget
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
from core.lib.misc import *

import core.lib.portScanner as portScanner

class saprouterSpy(baseDiscoveryPlugin):
	'''
	Perform internal hosts port scan through SAProuter.
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseDiscoveryPlugin.__init__(self)
		self._targets = '192.168.3.1'
		self._type = 'iprange'
		self._mode = 'sap'
		self._scanTargets = []
		self._createTargets = False
		self._desc = 'Perform internal hosts port scan through SAProuter.'

	def _run_SAPROUTER(self):
		'''
		Perform a port scan through SAP router and try to find new targets.
		'''
		newTargets = []
		reachable = {}
		if self._processOptions():
			# Scan each host/port through saprouter

			# First check that we can connect with the SAPRouter
			self.outInformation('Trying to connect with remote SAProuter...')
			self._connector.connect()
			self._connector.disconnect()
			self.outInformation('Connection established.')

			for host in self._scanTargets:
				# Get the port list from the port scanner
				ps = portScanner.portScanner(host, self._mode)
				ports = ps.createPortList(self._mode)

				self.outInformation('\n\tScanning ' + str(len(ports)) + ' ports in host ' + host)
				openPorts = []
				for port in ports:
					# Connect with SAProuter
					try:
						self._connector.connect()
						self._connector.send_receive(type='NI_ROUT_IO', route=[self._connector.getThisHop(), {host:port}])

						openPorts.append(port)
						self.outDebug('Port ' + str(port) + ' is available.')
					except bizploitException:
						# self.outDebug('Port ' + str(port) + ' is NOT available.')
						pass

					self._connector.disconnect()

				if openPorts != []:

					self.outInformation('Open & reachable ports on target ' + host + ':')
					openPorts.sort()
					reachable[host] = openPorts
					for port in openPorts:
						self.outInformation('- ' + str(port) + '/tcp\t' + ps.getPortInfo(port)['name'])

				else:
					self.outInformation('No open & reachable ports on target ' + host)


				if openPorts and self._createTargets:
					self.outInformation('\n\tAnalyzing new targets...')

					for port in openPorts:
						# Check if the service has a connector associated, and it is available for us
						portInfo = ps.getPortInfo(port)
						for connector in portInfo['connectors']:
							target = baseTarget()
							connObj = factory('fwk.connectors.conn' + connector)
							compatible = connObj.confByDiscover(host, port, saprouter=[self._connector.getThisHop()])
							if compatible:
								self.outInformation('Port ' + str(port) + ' has connector ' + connObj.getName() + ' associated. New target created.')
								target.setHost(host)
								target.addConnector(connObj)
								newTargets.append(target)

					if not newTargets:
						self.outInformation('No compatible targets discovered.')

			if len(reachable):
				# Create the result object
				resPlugin = pluginResult.pluginResult(self)
				resPlugin.setName('Detected systems and services through SAProuter')
				resPlugin.setDesc('Remote systems and open ports were detected through the SAProuter.')
				resPlugin.setRisk(pluginResult.RISK_INFO)
				resPlugin.setData('reachablePoints', reachable)
				resPlugin.setConnectionInfo(self._target, self._connector)

				tab = tableResult('reachable')
				resPlugin.addResult(tab)
				tab.setHeader(('System', 'Port', 'Description'))

				for host in reachable.keys():
					for port in reachable[host]:
						tab.addRow((host, str(port), ps.getPortInfo(port)['name']))

				self.saveToKB('reachablePoints', resPlugin)

		return newTargets

	def _processOptions(self):
		'''
		Process plugin options
		'''
		iprangeColl = []
		targets = []

		if self._type == 'iprange':
			iprangeColl.append(iprange(self._targets))
		elif self._type == 'file':
			try:
				fd = open(self._targets)
				for line in fd:
					line = line.strip()
					if line != '' and line[0] != '#':	# if not a comment..
						iprangeColl.append(iprange(line))
				fd.close()
			except:
				self.outInformation('Failed to open file : ' + self._targets)
				return False
		else:
			self.outInformation('Discovery target type "' + self._type + '" not supported.')

		# Parse IPs
		for ipr in iprangeColl:
			for ip in ipr:
				targets.append(ip)

		self.outDebug('Targets for port-scanning: ')
		self.outDebug('\n'.join(targets))

		if self._mode != 'sap' and self._mode != 'normal' and self._mode != 'full' and not self._mode[0].isdigit():
			self.outInformation('Discovery target mode ' + self._mode + '" not supported.')
			return False
		else:
			self._scanTargets = targets

		return True

	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the plugin options.
		'''
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="targets">\
				<default>' + self._targets + '</default>\
				<desc>Target(s) specification, according to type..</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="type">\
				<default>' + self._type + '</default>\
				<desc>The target type [file|iprange].</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="mode">\
				<default>' + self._mode + '</default>\
				<desc>Discovery mode [fast|normal|full|portrange] </desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="createTargets">\
				<default>' + str(self._createTargets) + '</default>\
				<desc>Specifies if plugin automatically creates new targets.</desc>\
				<type>Boolean</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def setOptions(self, OptionList):
		'''
		This method sets all the options that are configured using the user interface 
		generated by the framework using the result of getOptionsXML().
		
		@parameter OptionList: A dictionary with the options for the plugin.
		@return: No value is returned.
		'''
		if 'targets' in OptionList.keys():
			self._targets = OptionList['targets']
		if 'type' in OptionList.keys():
			self._type = OptionList['type']
		if 'mode' in OptionList.keys():
			self._mode = OptionList['mode']
		if 'createTargets' in OptionList.keys():
			self._createTargets = OptionList['createTargets']

