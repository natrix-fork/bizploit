# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri - jsantarsieri@onapsis.com    
    
Portions Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import core.baseResult.pluginResult as pluginResult

from core.baseResult.msgResult import msgResult
from core.exceptions.bizploitException import bizploitException
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin

class icmURLScan(baseDiscoveryPlugin):
	'''
	Checks if some ICM urls are present or not in the remote SAP system.
	
	@author: Jordan Santarsieri
	'''
	def __init__(self):
		baseDiscoveryPlugin.__init__( self )
		self._icm_urls = []
		self._desc = 'Checks for several ICM services.'
		
	def _run_SAPICM(self):
		self._load_icm_urls()
		resAvail = [200, 301, 302, 400, 401, 403, 500]
		self.outInformation('Checking if the services are available...')
		alarm = False
		
		for url in self._icm_urls:
			resCode = self._connector.checkURI(url)
			if resCode != 0 and resCode in resAvail:
				self.outInformation('The SAP ICM Info service is enabled at \'%s\'' % url)
				alarm = True                

		if alarm:                
			resPlugin = pluginResult.pluginResult(self)
			resPlugin.setName('SAP ICM URLs')
			resPlugin.setDesc('At least one ICM URL was discovered in the target server')
			resPlugin.setConnectionInfo(self._target,  self._connector)
			resPlugin.setRisk(pluginResult.RISK_INFO)				
			self.saveToKB('SAPICMUrlsScan', resPlugin)

		else:
			self.outInformation('All the ICM urls were NOT found on the remote SAP system')
		
		return []
			
	def _load_icm_urls(self):
		temp_url = ["/sap/bc/bsp/sap",
"/sap/bc/bsp/sap/alertinbox",
"/sap/bc/bsp/sap/bsp_dlc_frcmp",
"/sap/bc/bsp/sap/bsp_veri",
"/sap/bc/bsp/sap/bsp_verificatio",
"/sap/bc/bsp/sap/bsp_wd_base",
"/sap/bc/bsp/sap/bspwd_basics",
"/sap/bc/bsp/sap/certmap",
"/sap/bc/bsp/sap/certreq",
"/sap/bc/bsp/sap/crm_bsp_frame",
"/sap/bc/bsp/sap/crmcmp_bpident",
"/sap/bc/bsp/sap/crmcmp_brfcase",
"/sap/bc/bsp/sap/crmcmp_hdr",
"/sap/bc/bsp/sap/crmcmp_hdr_std",
"/sap/bc/bsp/sap/crmcmp_ic_frame",
"/sap/bc/bsp/sap/crm_thtmlb_util",
"/sap/bc/bsp/sap/crm_ui_frame",
"/sap/bc/bsp/sap/crm_ui_start",
"/sap/bc/bsp/sap/esh_sapgui_exe",
"/sap/bc/bsp/sap/esh_sap_link",
"/sap/bc/bsp/sap/graph_bsp_test",
"/sap/bc/bsp/sap/graph_bsp_test/Mimes",
"/sap/bc/bsp/sap/gsbirp",
"/sap/bc/bsp/sap/htmlb_samples",
"/sap/bc/bsp/sap/iccmp_bp_cnfirm",
"/sap/bc/bsp/sap/iccmp_hdr_cntnr",
"/sap/bc/bsp/sap/iccmp_hdr_cntnt",
"/sap/bc/bsp/sap/iccmp_header",
"/sap/bc/bsp/sap/iccmp_ssc_ll",
"/sap/bc/bsp/sap/ic_frw_notify",
"/sap/bc/bsp/sap/it00",
"/sap/bc/bsp/sap/public/bc",
"/sap/bc/bsp/sap/public/graphics",
"/sap/bc/bsp/sap/sam_demo",
"/sap/bc/bsp/sap/sam_notifying",
"/sap/bc/bsp/sap/sam_sess_queue",
"/sap/bc/bsp/sap/sbspext_htmlb",
"/sap/bc/bsp/sap/sbspext_xhtmlb",
"/sap/bc/bsp/sap/spi_admin",
"/sap/bc/bsp/sap/spi_monitor",
"/sap/bc/bsp/sap/sxms_alertrules",
"/sap/bc/bsp/sap/system",
"/sap/bc/bsp/sap/thtmlb_scripts",
"/sap/bc/bsp/sap/thtmlb_styles",
"/sap/bc/bsp/sap/uicmp_ltx",
"/sap/bc/bsp/sap/xmb_bsp_log",
"/sap/bc/contentserver",
"/sap/bc/echo",
"/sap/bc/error",
"/sap/bc/FormToRfc",
"/sap/bc/graphics/net",
"/sap/bc/gui/sap/its/CERTREQ",
"/sap/bc/gui/sap/its/designs",
"/sap/bc/gui/sap/its/webgui",
"/sap/bc/IDoc_XML",
"/sap/bc/ping",
"/sap/bc/report",
"/sap/bc/soap/ici",
"/sap/bc/soap/rfc",
"/sap/bc/srt/IDoc",
"/sap/bc/wdvd",
"/sap/bc/webdynpro/sap/apb_launchpad",
"/sap/bc/webdynpro/sap/apb_launchpad_nwbc",
"/sap/bc/webdynpro/sap/apb_lpd_light_start",
"/sap/bc/webdynpro/sap/apb_lpd_start_url",
"/sap/bc/webdynpro/sap/application_exit",
"/sap/bc/webdynpro/sap/appl_log_trc_viewer",
"/sap/bc/webdynpro/sap/appl_soap_management",
"/sap/bc/webdynpro/sap/ccmsbi_wast_extr_testenv",
"/sap/bc/webdynpro/sap/cnp_light_test",
"/sap/bc/webdynpro/sap/configure_application",
"/sap/bc/webdynpro/sap/configure_component",
"/sap/bc/webdynpro/sap/esh_admin_ui_component",
"/sap/bc/webdynpro/sap/esh_adm_smoketest_ui",
"/sap/bc/webdynpro/sap/esh_eng_modelling",
"/sap/bc/webdynpro/sap/esh_search_results.ui",
"/sap/bc/webdynpro/sap/sh_adm_smoketest_files",
"/sap/bc/webdynpro/sap/wd_analyze_config_appl",
"/sap/bc/webdynpro/sap/wd_analyze_config_comp",
"/sap/bc/webdynpro/sap/wd_analyze_config_user",
"/sap/bc/webdynpro/sap/wdhc_application",
"/sap/bc/webdynpro/sap/WDR_TEST_ADOBE",
"/sap/bc/webdynpro/sap/WDR_TEST_EVENTS",
"/sap/bc/webdynpro/sap/wdr_test_popups_rt",
"/sap/bc/webdynpro/sap/WDR_TEST_TABLE",
"/sap/bc/webdynpro/sap/wdr_test_ui_elements",
"/sap/bc/webdynpro/sap/WDR_TEST_WINDOW_ERROR",
"/sap/bc/webrfc",
"/sap/bc/xrfc",
"/sap/bc/xrfc_test",
"/sap/crm",
"/sap/es/cockpit",
"/sap/es/getdocument",
"/sap/es/opensearch",
"/sap/es/opensearch/description",
"/sap/es/opensearch/list",
"/sap/es/opensearch/search",
"/sap/es/redirect",
"/sap/es/saplink",
"/sap/es/search",
"/sap/public/bc",
"/sap/public/bc",
"/sap/public/bc/icons",
"/sap/public/bc/icons_rtl",
"/sap/public/bc/its/mimes",
"/sap/public/bc/its/mimes/system/SL/page/hourglass.html",
"/sap/public/bc/its/mobile/itsmobile00",
"/sap/public/bc/its/mobile/itsmobile01",
"/sap/public/bc/its/mobile/rfid",
"/sap/public/bc/its/mobile/start",
"/sap/public/bc/its/mobile/test",
"/sap/public/bc/NWDEMO_MODEL",
"/sap/public/bc/NW_ESH_TST_AUTO",
"/sap/public/bc/pictograms",
"/sap/public/bc/sicf_login_run",
"/sap/public/bc/trex",
"/sap/public/bc/ur",
"/sap/public/bc/wdtracetool",
"/sap/public/bc/webdynpro/adobechallenge",
"/sap/public/bc/webdynpro/mimes",
"/sap/public/bc/webdynpro/ssr",
"/sap/public/bc/webdynpro/viewdesigner",
"/sap/public/bc/webicons",
"/sap/public/bc/workflow",
"/sap/public/bc/workflow/shortcut",
"/sap/public/bsp/sap",
"/sap/public/bsp/sap/htmlb",
"/sap/public/bsp/sap/public",
"/sap/public/bsp/sap/public/bc",
"/sap/public/bsp/sap/public/faa",
"/sap/public/bsp/sap/public/graphics",
"/sap/public/bsp/sap/public/graphics/jnet_handler",
"/sap/public/bsp/sap/public/graphics/mimes",
"/sap/public/bsp/sap/system",
"/sap/public/bsp/sap/system_public",
"/sap/public/icf_check",
"/sap/public/icf_info",
"/sap/public/icf_info/icr_groups",
"/sap/public/icf_info/icr_urlprefix",
"/sap/public/icf_info/logon_groups",
"/sap/public/icf_info/urlprefix",
"/sap/public/icman",
"/sap/public/info",
"/sap/public/myssocntl",
"/sap/public/ping",
"/sap/wdvd",
"/sap/webcuif",
"/sap/webdynpro/sap/hap_main_document",
"/sap/webdynpro/sap/hap_start_page_powl_ui_ess",
"/sap/webdynpro/sap/hap_store_page_powl_ui_mss",
"/sap/webdynpro/sap/hrtmc_employee_profile",
"/sap/webdynpro/sap/hrtmc_rm_maintenance",
"/sap/webdynpro/sap/hrtmc_ta_assessment",
"/sap/webdynpro/sap/hrtmc_ta_dashboard",
"/sap/webdynpro/sap/wd_analyze_config_user"]
		self._icm_urls = temp_url