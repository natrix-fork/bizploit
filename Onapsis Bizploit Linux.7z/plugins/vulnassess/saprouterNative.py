# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author: Mariano Nunez Di Croce <mnunez@onapsis.com> 
	
Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nunez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin
from core.exceptions.bizploitException import bizploitException
from fwk.connectors.baseTarget import baseTarget
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
from core.lib.misc import *

import core.lib.portScanner as portScanner

class saprouterNative(baseVulnAssessPlugin):
    '''
    Check if it is possible to route native traffic through the SAProuter
    
    '''
    def __init__(self):
        baseVulnAssessPlugin.__init__(self)
        self._targets = '127.0.0.1'
        self._type = 'iprange'
        self._mode = '21,22,23,25,80,135,445,3389,1503,5631,1433,1527,7210,3299'
        self._scanTargets = []
        self._desc = 'Checks if it is possible Route native protocols through the SAPRouter'

    def _run_SAPROUTER(self):
        '''
        Perform a port scan through SAP router and try to find new targets.
        '''
        reachable = {}

        if self._processOptions():
            # Scan each host/port through saprouter

            # First check that we can connect with the SAPRouter
            self.outInformation('Trying to connect with remote SAProuter...')
            self._connector.connect()
            self._connector.disconnect()
            self.outInformation('Connection established.')

            for host in self._scanTargets:
                # Get the port list from the port scanner
                ps = portScanner.portScanner(host, self._mode)
                ports = ps.createPortList(self._mode)

                self.outInformation('Scanning ' + str(len(ports)) + ' ports in host ' + host)
                openPorts = []
                for port in ports:
                    # Connect with SAProuter
                    try:
                        self._connector.connect()
                        self._connector.send_receive(type='NI_RAW_IO', route=[self._connector.getThisHop(), {host:port}])

                        openPorts.append(port)
                        self.outDebug('Port ' + str(port) + ' is available.')
                    except bizploitException:
                        self.outDebug('Port ' + str(port) + ' is NOT available.')

                    self._connector.disconnect()

                if openPorts != []:

                    self.outVulnerability('The SAProuter allows routing of Native protocols')

                    self.outInformation('Native ports allowed to target ' + host + ':')
                    openPorts.sort()
                    reachable[host] = openPorts
                    for port in openPorts:
                        self.outInformation('- ' + str(port) + '/tcp\t' + ps.getPortInfo(port)['name'])

                else:
                    self.outInformation('No Native ports on target ' + host + ' are allowed.')

            if len(reachable):
                # Create the result object
                resPlugin = pluginResult.pluginResult(self)
                resPlugin.setVulnID(9)
                resPlugin.setName('SAProuter allows routing of Native protocols')
                resPlugin.setDesc('It is possible to route \'native\' protocols through the SAProuter. This situation would allow an attacker to connect to non-SAP services (e.g. SSH, HTTP, RDP) in systems reachable by the affected SAProuter. ')
                resPlugin.setRisk(pluginResult.RISK_HIGH)
                resPlugin.setData('reachablePointsNative', reachable)
                resPlugin.setConnectionInfo(self._target, self._connector)

                tab = tableResult('reachablePointsNative')
                resPlugin.addResult(tab)
                tab.setHeader(('System', 'Port', 'Description'))

                for host in reachable.keys():
                    for port in reachable[host]:
                        tab.addRow((host, str(port), ps.getPortInfo(port)['name']))

                self.saveToKB('reachablePointsNative', resPlugin)

        return True

    def _processOptions(self):
        '''
        Process plugin options
        '''
        iprangeColl = []
        targets = []

        if self._type == 'iprange':
            iprangeColl.append(iprange(self._targets))
        elif self._type == 'file':
            try:
                fd = open(self._targets)
                for line in fd:
                    line = line.strip()
                    if line != '' and line[0] != '#':    # if not a comment..
                        iprangeColl.append(iprange(line))
                fd.close()
            except:
                self.outInformation('Failed to open file : ' + self._targets)
                return False
        else:
            self.outInformation('Discovery target type "' + self._type + '" not supported.')

        # Parse IPs
        for ipr in iprangeColl:
            for ip in ipr:
                targets.append(ip)

        self.outDebug('Targets for port-scanning: ')
        self.outDebug('\n'.join(targets))

        ranges = self._mode.split(',')
        for port in ranges:
            if len(port) and not port.strip().isdigit():
                self.outInformation('Please specify a numeric port-range (e.g. 21,22,25,80)')
                return False
        else:
            self._scanTargets = targets

        return True

    def getOptionsXML(self):
        '''
        This method returns a XML containing the Options that the plugin has.
        Using this XML the framework will build a window, a menu, or some other input method to retrieve
        the info from the user. The XML has to validate against the xml schema file located at :
        bizploit/core/ui/userInterface.dtd
        
        @return: XML with the plugin options.
        '''
        return    '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="targets">\
                <default>' + self._targets + '</default>\
                <desc>Target(s) specification, according to type..</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="type">\
                <default>' + self._type + '</default>\
                <desc>The target type [file|iprange].</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="mode">\
                <default>' + self._mode + '</default>\
                <desc>Ports to scan</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '

    def setOptions(self, OptionList):
        '''
        This method sets all the options that are configured using the user interface 
        generated by the framework using the result of getOptionsXML().
        
        @parameter OptionList: A dictionary with the options for the plugin.
        @return: No value is returned.
        '''
        if 'targets' in OptionList.keys():
            self._targets = OptionList['targets']
        if 'type' in OptionList.keys():
            self._type = OptionList['type']
        if 'mode' in OptionList.keys():
            self._mode = OptionList['mode']

