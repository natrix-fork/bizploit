# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Sergio ABraham <sabraham@onapsis.com>	
	
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin #@UnresolvedImport
from core.baseResult.tableResult import tableResult
import core.baseResult.pluginResult as pluginResult
from core.baseResult.msgResult import msgResult

class checkCtc(baseVulnAssessPlugin):
	'''
	Checks for verb tampering issues in the ctc runtime
	
	@author: Sergio Abraham <sabraham@onapsis.com>
	'''

	def __init__( self ):				
		baseVulnAssessPlugin.__init__( self )
		self._desc = 'Checks for verb tampering issues in the ctc runtime.'	
		
	def _run_SAPPORTAL(self):
		self._check_bypass(self._connector)
		
	def _check_bypass(self,connector):
		self.outInformation('Checking for verb tampering issues in the ctc runtime ...')
		head_response = connector.checkURI("/ctc/ConfigServlet",timeout=15)
		try:
			if head_response == 200:
				self.outVulnerability('Ctc runtime is vulnerable to verb tampering attacks.')
				# Create the result object
				resPlugin = pluginResult.pluginResult(self)
				resPlugin.setName('Ctc runtime is vulnerable to verb tampering attacks.')
				resPlugin.setDesc('It is possible to execute arbitrary commands on the affected SAP Server')
				resPlugin.setData('ctcAvailable',  True)
				resPlugin.setRisk(pluginResult.RISK_HIGH)
				
				msg = msgResult('vulnerable')
				msg.setData(True)
				msg.setResult('The CTC runtime is vulnerable')
				resPlugin.addResult(msg)
				resPlugin.setConnectionInfo(self._target,  self._connector)
				
				self.saveToKB('ctcAvailable', resPlugin)
			else:
				self.outInformation('Ctc runtime is not vulnerable to verb tampering attacks.')
		except Exception, e:
				self.outInformation("Error checking Ctc runtime: "+str(e))
		return
	