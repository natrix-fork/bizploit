# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author: Jordan Santarsieri <jsantarsieri@onapsis.com>	
	
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin   
import core.baseResult.pluginResult as pluginResult

class mcInterface(baseVulnAssessPlugin):
	'''
	Checks if it is possible to access to the SAP MC Web Service interface.
	  
	@author: Jordan Santarsieri <jsantarsieri@onapsis.com>
	
	'''
	def __init__( self):
		baseVulnAssessPlugin.__init__( self )	
		self._desc = 'Checks if it is possible to access to the SAP MC Web Service interface.'
				
	def _run_SAPMC(self):
		
		self.outInformation('Trying to reach the web service interface... ')
		# We must check if we can get the WSDL Definition
		self._connector.connect()
		try:
			result = self._connector.prepareMessage()
			if result:
				# We find the WSDL
				self.outVulnerability('The SAP MC Web Service Interface is accessible.')
				resModule = pluginResult.pluginResult(self)
				resModule.setVulnID(16)
				resModule.setName('SAP MC Web Service Interface is accessible.')
				resModule.setDesc('It is possible to interact with the Web Service interface remotely. \
				Under this circumstances, an attacker will be able execute dangerous methods to compromise the availability and integrity of the SAP system.')
				resModule.setRisk(pluginResult.RISK_MEDIUM)
				resModule.setData('sapmcWSAvailable',  True)	
				resModule.setConnectionInfo(self._target,  self._connector)
				resModule.setSolution('It is recommended to configure the Start Profile parameter "service/hostname" to a value specifying the IP address or host name to which the Web service port should be bound (default: all / 0.0.0.0), in order to restrict access to specific administrative networks.')
				resModule.setRefs(['SAP Note 927637'])
							
				self.saveToKB('sapmcWSAvailable', resModule)
			else:
				self.outInformation('It was not possible to locate the Web Service Interface')
		except:
			self.outInformation('It was not possible to locate the Web Service Interface')
			return