# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseVulnAssessPlugin import baseVulnAssessPlugin
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult

class sapinfo(baseVulnAssessPlugin):
	'''
	Obtains information from remote RFC Server.
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseVulnAssessPlugin.__init__( self )
		self._usedConnector = ''
		self._desc = 'Obtains information from remote RFC Server.'
		
	def _run_SAPRFC(self):
		data = {}
		self._usedConnector = 'SAPRFC'
		
		# Craft function call
		call = self._connector.lib.iface("RFC_SYSTEM_INFO")		
		rfcsi = self._connector.lib.parm("RFCSI_EXPORT", "", self._connector.lib.RFCIMPORT, self._connector.lib.RFCTYPE_CHAR, 200)
		call.addParm(rfcsi)
		
		# Connect and send call
		self._connector.connect()
		self._connector.call_receive(call)
		self._connector.disconnect()
		
		# Parse response
		pos = 0
		for field in self._connector.lib.SYSINFO:
			data[field['NAME']] = rfcsi.value[pos:pos+field['LEN']] .strip()
			pos += field['LEN']
			
		self.outVulnerability('Remote system information disclosure')
		self.outInformation('Remote system information:')
		rawData,  parsed = self._formatOutput(data)
		for l in parsed.splitlines():
			self.outInformation(l)
		
		# Create the result object
		resPlugin = pluginResult.pluginResult(self)
		resPlugin.setVulnID(8)
		resPlugin.setName('Remote system information disclosure')
		resPlugin.setDesc('It is possible to obtain remote system information using default RFC functions, without providing authentication information.')
		resPlugin.setRisk(pluginResult.RISK_MEDIUM)
		resPlugin.setData('systeminfo',  data)
		resPlugin.setConnectionInfo(self._target,  self._connector)
		
		if self._usedConnector == 'SAPRFC':
			resPlugin.setSolution('Configure the auth/rfc_authority_check parameter in order to protect the system from anonymous RFC calls.')
		else:
			resPlugin.setSolution('Restrict RFC communications through proper configuration of SAP Gateway security parameters.\n \
										Use the Netweaver RFC SDK to develop RFC servers, as it provides security improvements over the classical RFC SDK for protecting against different attacks.')
		resPlugin.addRef('http://www.blackhat.com/presentations/bh-europe-07/Nunez-Di-Croce/Whitepaper/bh-eu-07-nunez_di_croce-WP-apr19.pdf')
		
		tab = tableResult('systeminfo')	
		resPlugin.addResult(tab)
		tab.setTitle('System information')
		tab.setHeader(('Field','Value'))		
		for c in rawData.keys():
			tab.addRow((c, rawData[c]))

		self.saveToKB('systeminfo', resPlugin)
		
		return True

	def _run_SAPRFC_EXT(self):
		'''
		It's the same as for SAP Application Servers
		'''
		self._usedConnector = 'SAPRFC_EXT'
		return self._run_SAPRFC()

		
	def _formatOutput(self, data):
		'''
		Formats output for sapinfo plugin.
		'''
		res = {}
		res['RFC Destination'] = data['RFCDEST']
		res['System ID'] = data['RFCSYSID']
		res['Hostname'] = data['RFCHOST2']
		res['IP Address'] = data['RFCIPADDR']
		res['Kernel Release'] = data['RFCKERNRL']
		res['Operating System'] = data['RFCOPSYS']
		res['Release Status of SAP System'] = data['RFCSAPRL']
		res['Central Database System'] = data['RFCDBSYS']
		res['Database Host'] = data['RFCDBHOST']
		res['Machine ID'] = data['RFCMACH']
		res['Character Set'] = data['RFCCHARTYP']
		res['Timezone'] = data['RFCTZONE'] + ' (diff from UTC in seconds)'
		res['Daylight Saving Time'] = data['RFCDAYST']
		if data['RFCINTTYP']  == 'LIT':
			res['Integer Format'] = 'Little Endian'
		else:
			res['Integer Format'] = 'Big Endian'
		if data['RFCFLOTYP']  == 'IE3':
			res['Float Type Format'] = 'IEEE'
		else:
			res['Float Type Format'] = 'IBM/370'
		res['RFC Log Version'] = data['RFCPROTO']
		
		ret = ''
		for key in res.keys():
			ret += '\t' + key + ': ' + res[key] + '\n' 
		return (res, ret)

	
