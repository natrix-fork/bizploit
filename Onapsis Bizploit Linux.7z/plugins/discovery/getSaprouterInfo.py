# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Nahuel D. Sanchez - nsanchez@onapsis.com    
    
Portions Copyright 2012 ONAPSIS S.R.L.
This module is based on the MSF module developed by Dave Hartley (nmonkee) 

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import struct
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin
from core.exceptions.bizploitException import bizploitException
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
import core.ui.consoleUi.tables as tables
from core.lib.misc import *


class getSaprouterInfo(baseDiscoveryPlugin):
	'''
	This module retrieves a list with the clients connected to SAProuter.
	
	@author: Nahuel D. Sanchez
	'''
	
	def __init__(self):
		baseDiscoveryPlugin.__init__(self)
		self._targets = '192.168.3.*'
		self._type = 'iprange'
		self._mode = 'sap'
		self._scanTargets = []
		self._createTargets = False
		self._desc = 'This module retrieves a list with the clients connected to SAProuter.'

	def _parseData(self, dBlock):
		data = ''
		for i in dBlock:
			if i == '\x00':
				return data
			else:
				data += i
		return data

	def _blockProcess(self, block):
		'''
		This function process a Block of data
		and returns ConnID, ClientIP and partner IP.
		'''
		connID = struct.unpack('!L', block[:4])
		#unkFld0 = struct.unpack('L', block[4:8])
		#unkFld1 = struct.unpack('B', block[8:9])
		#unkFld2 = struct.unpack('B', block[9:10])
		#unkFld3 = struct.unpack('B', block[10:11])
		#unkFld4 = struct.unpack('B', block[11:12])
		#unkFld5 = struct.unpack('B', block[12:13])
		ipClient = self._parseData(block[13:59])	#Fixed length 46 Bytes
		ipPartner = self._parseData(block[59:105])	#Fixed length 46 Bytes
		service = self._parseData(block[105:135])	#Fixed length 30 Bytes
		return connID[0], ipClient, ipPartner, service

	def _run_SAPROUTER(self):
		'''
		This module retrieves a list with the clients connected to SAProuter.
		'''
		stablishedConn = []
		if self._processOptions():
			self.outInformation('Trying to connect with remote SAProuter...')
			try:
				self._connector.connect()
				self.outInformation('Connection established.')
				self.outInformation('Sending SAProuter administrative packet...')
				dataBlock = self._connector.send_receive(type='NI_ROUTER_ADM')
				infLen = 137
				self.outInformation('Retrieving information...')
				self.outInformation('\n')
				# 137 is the length of the information "field"
				x = infLen
				stablishedConn.append(['Connection ID', 'Client IP', 'Partner IP', 'Service'])

				resPlugin = pluginResult.pluginResult(self)
				resPlugin.setName('Remote SAProuter connections table')
				resPlugin.setDesc('Established connections on the remote SAProuter.')
				resPlugin.setRisk(pluginResult.RISK_INFO)
				resPlugin.setConnectionInfo(self._target, self._connector)

				for i in range(2, (len(dataBlock) / infLen) + 1):
					z = infLen * i
					(connID, ipClient, ipPartner, service) = self._blockProcess(dataBlock[x:z])
					x = z
					stablishedConn.append([str(connID), str(ipClient), str(ipPartner), str(service)])

				if len(stablishedConn) == 1: # Only added the table header...
					self.outInformation('No clients connected to SAProuter...')
				else:
					resPlugin.setData('Connections', stablishedConn)
					tab = tableResult('SAProuterClients')
					resPlugin.addResult(tab)
					table = tables.table(stablishedConn)
					table.draw(self.term_width(), True)
					self.saveToKB('clients', resPlugin)

				return []

			except Exception, e:
				self.outInformation("Error retrieving SAProuter information...")
				raise bizploitException(str(e))

	def _processOptions(self):
		'''
		Process plugin options
		'''
		iprangeColl = []
		targets = []

		if self._type == 'iprange':
			iprangeColl.append(iprange(self._targets))
		elif self._type == 'file':
			try:
				fd = open(self._targets)
				for line in fd:
					line = line.strip()
					if line != '' and line[0] != '#':	# if not a comment..
						iprangeColl.append(iprange(line))
				fd.close()
			except:
				self.outInformation('Failed to open file : ' + self._targets)
				return False
		else:
			self.outInformation('Discovery target type "' + self._type + '" not supported.')

		# Parse IPs
		for ipr in iprangeColl:
			for ip in ipr:
				targets.append(ip)

		return True

	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the plugin options.
		'''
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="targets">\
				<default>' + self._targets + '</default>\
				<desc>Target(s) specification, according to type..</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="type">\
				<default>' + self._type + '</default>\
				<desc>The target type [file|iprange].</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def setOptions(self, OptionList):
		'''
		This method sets all the options that are configured using the user interface 
		generated by the framework using the result of getOptionsXML().
		
		@parameter OptionList: A dictionary with the options for the plugin.
		@return: No value is returned.
		'''
		if 'targets' in OptionList.keys():
			self._targets = OptionList['targets']
		if 'type' in OptionList.keys():
			self._type = OptionList['type']
