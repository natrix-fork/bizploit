# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin
from core.exceptions.bizploitException import bizploitException
import core.baseResult.pluginResult as pluginResult
from core.baseResult.msgResult import msgResult

class ping(baseDiscoveryPlugin):
	'''
	Checks if remote RFC server is alive through RFC_PING.
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__(self):
		baseDiscoveryPlugin.__init__( self )
		self._desc = 'Checks if remote RFC server is alive through RFC_PING.'
		
	def _run_SAPRFC(self):
		# Craft function call
		call = self._connector.lib.iface("RFC_PING")		

		# Connect and send call
		try:
			self._connector.connect()
			self._connector.call_receive(call)
			self._connector.disconnect()
			self.outVulnerability('Remote system can be discovered through RFC.')
		except bizploitException:
			self.outInformation('Remote system can NOT be discovered through RFC.')
			return []
		
		# Create the result object
		resPlugin = pluginResult.pluginResult(self)
		resPlugin.setName('Remote system can be discovered through RFC')
		resPlugin.setDesc('It is possible to analyze if the remote system is available through RFC.')
		resPlugin.setData('AvailableRFCPING',  True)
		resPlugin.setRisk(pluginResult.RISK_INFO)
		
		msg = msgResult('available')
		msg.setData(True)
		msg.setResult('The remote system is available.')
		resPlugin.addResult(msg)
		resPlugin.setConnectionInfo(self._target,  self._connector)
		
		self.saveToKB('AvailableRFCPING', resPlugin)
		
		return []

	def _run_SAPRFC_EXT(self):
		'''
		Its the same as for SAP Application Servers
		'''
		return self._run_SAPRFC()
