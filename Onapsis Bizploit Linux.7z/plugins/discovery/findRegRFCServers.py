# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.baseDiscoveryPlugin import baseDiscoveryPlugin
import core.exceptions.bizploitException as bizploitException
from fwk.connectors.baseTarget import baseTarget
import core.baseResult.pluginResult as pluginResult
from core.baseResult.tableResult import tableResult
from core.lib.misc import *

class findRegRFCServers(baseDiscoveryPlugin):
	'''
	Try to discover common registered RFC servers at an SAP Gateway.
	
	@author: Mariano Nu�ez Di Croce 
	'''
	def __init__( self):
		baseDiscoveryPlugin.__init__( self )	
		self._regTpnames = self._getCommonServers()
		self._sid = ''
		self._desc = 'Try to discover common registered RFC servers at an SAP Gateway.'
		
	def _run_SAPGATEWAY(self):	
		found = []
		newTargets = []
		
		# Prepend hostname
		# Append SID
		res = []
		for tpname in self._regTpnames:
			res.append(tpname)
			res.append(self._connector.getGwHost() + '.' + tpname)
			if self._sid != '':
				res.append(tpname + '.' + self._sid)
		
		# Main loop
		for tp in res:
			self.outInformation('Trying tpname: ' + tp , newLine=False)
			try:
				self._connector.connectRFC('R', tpname= tp)
				# We have to send an RFC_PING otherwise RFC server may die when disconnecting !
				call = self._connector.lib.iface("RFC_PING")
				self._connector.call_receiveRFC(call)
				self._connector.disconnectRFC()	
				self.outInformation(' [SUCCESS]')
				found.append(tp)
			except bizploitException,  e:
				self.outDebug('\nException Debug Information: ' + str(e))
				self.outInformation('') # New Line
				pass
				
		if len(found) == 0:
			self.outInformation('Registered servers were NOT found.')	
		else:
			self.outConsole('')
			self.outVulnerability('Registered servers were found.')
			
			# Create the result object
			resPlugin = pluginResult.pluginResult(self)
			resPlugin.setName('Detected Registered RFC Servers reachable through SAP Gateway')
			resPlugin.setDesc('It was possible to detect external RFC servers working in registered mode. This situation would allow an attacker to send arbitrary RFC calls to these programs, possibly affecting the security of the related business processes.')
			resPlugin.setRisk(pluginResult.RISK_INFO)
			resPlugin.setData('regRFCServers',  found)
			resPlugin.setConnectionInfo(self._target,  self._connector)
			
			tab = tableResult('tpnames')			
			resPlugin.addResult(tab)
			tab.setTitle('Discovered RFC servers')		
			tab.setHeader(('Tpname', ))		
			for tp in found:
				tab.addRow((tp, ))
				
			self.saveToKB('regRFCServers', resPlugin)
			
			self.outInformation('\n\tCreating new targets...')			
			# We have to create connSAPRFC_EXT targets.
			aTarget =  baseTarget()
			aTarget.setHost(self._connector.getGwHost())
			
			for tp in found:				
				aConn = factory('fwk.connectors.connSAPRFC_EXT')
				aConn.setGwHost(self._connector.getGwHost())
				aConn.setGwServ(self._connector.getGwServ())
				aConn.setTpname(tp)
				try:
					aTarget.addConnector(aConn)
				except bizploitException:
					pass
				
			return [aTarget]
			
		return []

	def _getCommonServers(self):
		'''
		@return: List with commonly used tpnames for registered RFC servers.
		'''
		list = []
		# rfcexec 
		list.extend(['rfcexec', 'execute', 'exec', 'run'])
		# IGS
		list.append('IGS')
		
		return list

	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/ui/userInterface.dtd
		
		@return: XML with the plugin options.
		'''	
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="regTpnames">\
				<default>' + ','.join(self._regTpnames)+'</default>\
				<desc>List of tpnames to try.</desc>\
				<type>List</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="SID">\
				<default>' + self._sid + '</default>\
				<desc>SAP System ID of remote system.</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def setOptions( self, OptionList ):
		'''
		This method sets all the options that are configured using the user interface 
		generated by the framework using the result of getOptionsXML().
		
		@parameter OptionList: A dictionary with the options for the plugin.
		@return: No value is returned.
		'''	
		if 'regTpnames' in OptionList.keys(): 
			self._regTpnames = OptionList['regTpnames']
		if 'SID' in OptionList.keys(): 
			self._sid = OptionList['SID']
