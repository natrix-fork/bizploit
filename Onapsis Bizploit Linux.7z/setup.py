#!/usr/bin/env python
# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

import sys
from distutils.core import setup, Extension
from distutils import file_util, filelist
from distutils import util
from distutils import ccompiler
import sys,  platform

if platform.system() == 'Linux' and sys.version < '2.5':
	print "\nYou must have python version >= 2.5 to run bizploit.\n\n"
	sys.exit(1)

# In Windows we need exactly v2.5.x (the module was "precompiled" with that version)
major,  minor,  rev,  foo,  foo2 = sys.version_info
if platform.system() == 'Windows' and not (major == 2 and minor == 5 ):
	print "\nYou must have python version = 2.5.X to run bizploit.\n\n"
	sys.exit(1)

extmodules = []
pymodules = []

if platform.system() == 'Windows':
	pymodules = ['saprfcutil']
else:
	incdirs = ['/usr/sap/rfcsdk/include']
	libdirs = ['/usr/sap/rfcsdk/lib']
	libs = ['rfccm', 'pthread', 'dl', 'm', 'c']

	extmodules =  [Extension('saprfcutil',
					include_dirs = incdirs,
					library_dirs = libdirs,
					libraries = libs,
					sources = ['src/saprfcutil.c']                   
					)]
	
	
setup(name = "bizploit", version = "1.00",
	  description="Bizploit - The Opensource ERP Penetration Testing Framework",
	  author="Mariano Nunez Di Croce <mnunez@onapsis.com>",
	  author_email="mnunez@onapsis.com",
	  url="http://www.onapsis.com/bizploit",
	  ext_modules = extmodules,
	  py_modules = pymodules
	  )

list = filelist.findall('build')
file_util.copy_file(list[0],'extlib/')