# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri - jsantarsieri@onapsis.com    
    
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import os
import string
import tempfile
import urllib2 as ulib

from suds.client import Client
from suds import MethodNotFound
from core.lib.misc import resolveHostList
from fwk.connectors.connSOAP import connSOAP
from suds.transport.http import HttpAuthenticated
from core.exceptions.bizploitException import bizploitException
from core.exceptions.couldNotConnectException import couldNotConnectException

'''
    SAPHOSTCONTROL Connector    
    :author: Jordan Santarsieri - jsantarsieri@onapsis.com 
'''
    
class connSAPHOSTCONTROL(connSOAP):    
    
    def __init__( self):
        connSOAP.__init__(self)
        self._connName = 'SAPHOSTCONTROL'
        self._host = '127.0.0.1'
        self._port = 1128
        self._isHTTPS = False
        self._vhost = ''
        self._httpUser = ''
        self._httpPassword = ''
        self._authType = 'BASIC'
        self._path = '/SAPHostControl/'        
        self._userAgents = self._loadUserAgents()
        self._currentUA = 'bizploit'
        self._reqHeaders = {}       
        self.setReqHeader('User-Agent', self._userAgents['bizploit'])        
        self._localFileName = os.path.join(tempfile.gettempdir(), 'connSAPHOSTCONTROL.wsdl')        

    def _getTypeHttp(self):
        if self.getIsHTTPS() == False:
            return 'http://'
        else:
            return 'https://'   

    def _checkAuth(self,url):        
        if self._httpUser and self._httpPassword:
            if self._authType.upper() == 'BASIC':
                t = HttpAuthenticated(username=self._httpUser, password=self._httpPassword)                                
                return Client(url, transport=t)            
            else:                
				return Client(url,cache=None)
        else:                
			return Client(url,cache=None) 

    def connect(self):                        
        url = self._getTypeHttp() + self.getHost()+':'+str(self.getPort())+self.getPath()+'?wsdl'            
        
        try:
            f = ulib.urlopen(url)                
            data = f.read()
            data = data.replace('namespace="http://schemas.xmlsoap.org/soap/encoding/"','namespace="http://schemas.xmlsoap.org/soap/encoding/" schemaLocation="file://' + os.getcwd() + '/data/xmlsoap.schema"')

            # Open our local file for writing
            local_file = open(self._localFileName, "w")
            #Write to our local file
            local_file.write(data)
            local_file.close()
            url = 'file://' + tempfile.gettempdir() + '/connSAPHOSTCONTROL.wsdl'
            self._checkAuth(url)    

        except ulib.HTTPError, cause:
            if hasattr(cause, 'code'):               
                raise couldNotConnectException(str(cause))
        except ulib.URLError, cause:
            if hasattr(cause, 'code'):               
                raise couldNotConnectException(str(cause))
        except IOError, cause:
            print str(cause)
            raise bizploitException('Could not open temporary file %s for SAPHOSTCONTROL connector.' % self._localFileName)

    def sendMessage(self):        
        try:           
            url = self._getTypeHttp() + self.getHost()+':'+str(self.getPort())+self.getPath()+'?wsdl'                
            client = self._checkAuth(url)                               
            client.set_options(soapheaders=self._reqHeaders)      
            return client                                                               
        except ulib.URLError, cause:            
            raise bizploitException(str(cause))
        
    def prepareMessage(self):
        client = self.sendMessage()                
        client.set_options(soapheaders=self._reqHeaders)        
        client.set_options(location=self._getTypeHttp() + self.getHost()+':'+str(self.getPort())+self.getPath()+'?wsdl')
        return client              
                   
    def _loadUserAgents(self):
        map = {}
        map['bizploit'] = 'bizploit v1.00 HTTP Connector'
        map['IE5.5'] = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
        return map    
    
    def preconfig(self, target):
        self._host = target.getHost()
    
    def confByDiscover(self, system, port,  saprouter=None):
        if saprouter:
                return False
                
        self._host = system
        self._port = port
        return True
    
    def __eq__(self,  aConn):                
        if not isinstance(aConn, connSAPHOSTCONTROL):
            return False
        
        myIP = ''
        otherIP = ''
        try:
            myIP, otherIP = resolveHostList([self._host, aConn.getHost()])
        except bizploitException, e:            
            self._om.debug(self,  'Error: ' + str(e)) 
        
        if self._connID == -1:
            return myIP == otherIP and self._port == aConn.getPort()
        else:
            return self._connID == aConn.getID()

    
    def getConfiguration(self):
        return    'SAPHOSTCONTROL Host: ' + self._host + '\n'  \
                    'SAPHOSTCONTROL Port: ' + str(self._port)

    def gotCredentials(self):
        if self.getAuthType() != None:
            if self._httpUser and self._httpPassword:
                return True
            else:
                return False
        return False
            
    def getOptionsXML(self):
        return '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="host">\
                <default>'+self._host+'</default>\
                <desc>SAProuter host</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>False</visible>\
            </Option>\
            <Option name="port">\
                <default>'+str(self._port)+'</default>\
                <desc>HTTP(S) port</desc>\
                <type>Integer</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="isHTTPS">\
                <default>'+str(self._isHTTPS)+'</default>\
                <desc>Use HTTPS?</desc>\
                <type>Boolean</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="vhost">\
                <default>'+self._vhost+'</default>\
                <desc>Virtual Host</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpUser">\
                <default>'+self._httpUser+'</default>\
                <desc>HTTP User</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpPassword">\
                <default>'+self._httpPassword+'</default>\
                <desc>HTTP Password</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="authType">\
                <default>' + self._authType +'</default>\
                <desc>Authentication Type</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '

    def getHost(self):
        return self._host
    
    def getPath(self):
        return self._path
    
    def setPath(self,path):
        self._path = path

    def getPort(self):
        return self._port

    def getIsHTTPS(self):
        return self._isHTTPS

    def setHost(self, value):
        self._host = value

    def setPort(self, value):
        self._port = value

    def setIsHTTPS(self, value):
        self._isHTTPS = value        
        
    def getAuthType(self):
        return self._authType
    
    def setAuthType(self,auth):
        self._authType = auth
        
    def getHttpUser(self):
        return self._httpUser

    def setHttpUser(self,user):
        self._httpUser = user
        
    def getHttpPassword(self):
        return self._httpPassword
    
    def setHttpPassword(self,pswd):
        self._httpPassword = pswd
    
    def setReqHeader(self, name, value):
        self._reqHeaders[name] = value
        
    def setCookie(self, value, appendValue='&'):
        if 'Cookie' in self._reqHeaders.keys():
            self._reqHeaders['Cookie'].append(appendValue + value)
        else:
            self._reqHeaders['Cookie'] = value