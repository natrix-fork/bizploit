# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
# exceptions
from core.exceptions.bizploitException import bizploitException

import core.output.outputManager as om

import socket
import struct 

NI_ROUT_IO_S = 'NI_ROUTE'
NI_ROUTER_ADM_S = 'ROUTER_ADM'
NI_ROUT_IO_I = 2
NI_RAW_IO_I = 1
NI_MSG_IO_I = 0

# TODO: Add support for passwords. 

class niPacket:
	'''
	SAP Protocol (NI) library Packet
	@author: Mariano Nu�ez  Di Croce 
	'''
	def __init__(self):
		self._type = '' # 9 bytes
		self._routeVersion = 2 # 1 byte
		self._niVersion = 39 # 1 byte
		self._num = 2 # 1 byte
		self._mode = 0 # 1 byte 
		self._foo1 = 0 # 2 bytes
		self._remHosts = 1
		self._rLen = 0	# 4 bytes - net order - dynamic
		self._curPos = 0 #4 bytes - net order - dynamic
		
		self._route = []
		self._passwords = []
		self._data = ''
	
	def setRoute(self, route):
		'''
		Specify the route string
		'''
		self._route = route
	
	def setData(self, data):
		self._data = data
	
	def setPasswords(self,  passwords):
		self._passwords = passwords

	def processErrors(self, data):
		'''
		Analyze the data and raise exceptions if errors are found
		'''
		# Let's keep it simple, just raise base errors.
		if data.find('NI_RTERR') != -1:
			raise bizploitException('NI error has occurred.')

	def setRemHosts(self,  rem):
		self._remHosts = rem
	
	def setNum(self, num):
		self._num = num
		
	def setType(self, type):
		self._type = type
	
	def setMode(self, mode):
		self._mode = mode
	
	def serialize(self):
		'''
		Returns the packet serialized.
		Specific packets should override this method if needed.
		'''

		tookFirst = False
		paq = self._type + '\x00' + \
				struct.pack('b', self._routeVersion) + \
				struct.pack('b', self._niVersion) + \
				struct.pack('b', self._num) + \
				struct.pack('b', self._mode) + \
				struct.pack('h', self._foo1) + \
				struct.pack('b', self._remHosts) 
				
		routeData = ''		
		for hop in self._route:
			host = hop.keys()[0]
			routeItem = host + '\x00' + str(hop[host]) + '\x00\x00'
			if not tookFirst:
				# We get the first one, as it is the SAProuter entry and needs an index field
				routeData += struct.pack('!L', len(routeItem)) + routeItem
				tookFirst = True
			else:
				routeData += routeItem
		
		# The route length does not count the 4 bytes of the saprouter entry length
		paq += struct.pack('!L', len(routeData) - 4)  + routeData + self._data
		
		# Add the main length
		paq = struct.pack('!L', len(paq)) + paq
		
		return str(paq)


class niPacket_NI_ROUTE_IO(niPacket):
	'''
	This class implements an NI_ROUTE_IO packet.
	'''
	
	def __init__(self):
		niPacket.__init__(self)
		self.setType(NI_ROUT_IO_S)
		self.setMode(NI_MSG_IO_I)

class niPacket_NI_RAW_IO(niPacket):
	'''
	This class implements an NI_RAW_IO packet.
	'''
	
	def __init__(self):
		niPacket.__init__(self)
		self.setType(NI_ROUT_IO_S)
		self.setMode(NI_RAW_IO_I)
		
		
class niPacket_NI_ROUTER_ADM(niPacket):
	'''
	This class implements an SAP Router Administration packet.
	'''
	
	def __init__(self):
		niPacket.__init__(self)
		self.setType(NI_ROUTER_ADM_S)
		
		self._version = 0x26
		self._cmd = 0x2
		self._foo3 = 0
		self._foo4 = 0 
		
	def serialize(self):
		'''
		Returns the packet serialized.
		'''
		paq = self._type + '\x00' + \
				struct.pack('b', self._version) + \
				struct.pack('b', self._cmd) + \
				struct.pack('b', self._foo3) + \
				struct.pack('b', self._foo4) 		
		
		# Add the main length
		paq = struct.pack('!L', len(paq)) + paq
		
		return str(paq)

	def setCmd(self,  val):
		self._cmd = val

