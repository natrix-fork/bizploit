# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri <jsantarsieri@onapsis.com>    
    
Copyright 2010 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.exceptions.couldNotConnectException import couldNotConnectException
from core.exceptions.bizploitException import bizploitException #@UnresolvedImport
from fwk.connectors.baseConnector import baseConnector
from suds.transport.http import HttpAuthenticated
from suds.client import Client
import urllib2 as ulib


class connSOAP(baseConnector):
	"""
    SOAP Connector connSOAP.py 
    :author: Jordan Santarsieri <jsantarsieri@onapsis.com> 
    :version: 0.1
    """
	def __init__(self):
		baseConnector.__init__(self)
		self._host = '127.0.0.1'
		self._port = 50013
		self._isHTTPS = False
		self._vhost = ''
		self._httpUser = ''
		self._httpPassword = ''
		self._authType = ''
		self._path = '/SAPControl'

		self._userAgents = self._loadUserAgents()
		self._currentUA = 'bizploit'
		self._reqHeaders = {}

		self.setReqHeader('User-Agent', self._userAgents['bizploit'])


	"""
	Check if we are using http or https
	:author: jsantarsieri	
	"""
	def _getTypeHttp(self):
		if self.getIsHTTPS() == False:
			return 'http://'
		else:
			return 'https://'


	"""
	This method will check if we need to use basic http authentication
	or not
	:url: URL To send the messages
	:author: jsantarsieri	
	"""
	def _checkAuth(self, url):
		if self._httpUser and self._httpPassword:
			if self._authType.upper() == 'BASIC':
				t = HttpAuthenticated(username=self._httpUser, password=self._httpPassword)
				return Client(url, transport=t)
			else:
				return Client(url, cache=None)
		else:
				return Client(url, cache=None)

	"""
	 Returns the WSDL object with the definition from the given server 
	:type: Type name of the desired object.
	:author: jsantarsieri
	"""
	def getDefinitionFromURL(self):

		try:
			url = self._getTypeHttp() + self.getHost() + ':' + str(self.getPort()) + self.getPath() + '?wsdl'
			client = self._checkAuth(url)
			client.set_options(soapheaders=self._reqHeaders)
			return client
		except ulib.URLError, cause:
			if hasattr(cause, 'code'):
				raise bizploitException(str(cause))


	'''
	Only checks the connection with the remote server.
	'''
	def connect(self):
		try:
			url = self._getTypeHttp() + self.getHost() + ':' + str(self.getPort()) + self.getPath() + '?wsdl'
			self._checkAuth(url)
		except ulib.URLError, cause:
			if hasattr(cause, 'code'):
				raise couldNotConnectException(str(cause))


	"""
	 Sends a POST request via SOAP		
	:author: jsantarsieri 
	"""
	def sendMessage(self):
		try:
			url = self._getTypeHttp() + self.getHost() + ':' + str(self.getPort()) + self.getPath() + '?wsdl'
			client = self._checkAuth(url)
			client.set_options(soapheaders=self._reqHeaders)
			return client
		except ulib.URLError, cause:
			raise bizploitException(str(cause))


	"""
	 Create's an object type, based on a given type 
	:type: Type name of the desired object.	
	:author: jsantarsieri 
	"""
	def createType(self, type):
			return self.getDefinitionFromURL().factory.create(type)

	def _loadUserAgents(self):
		map = {}
		map['bizploit'] = 'bizploit v1.00 HTTP Connector'
		map['IE5.5'] = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
		return map

	def getOptionsXML(self):
		return '<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="host">\
				<default>' + self._host + '</default>\
				<desc>SAProuter host</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>False</visible>\
			</Option>\
			<Option name="port">\
				<default>' + str(self._port) + '</default>\
				<desc>HTTP(S) port</desc>\
				<type>Integer</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="isHTTPS">\
				<default>' + str(self._isHTTPS) + '</default>\
				<desc>Use HTTPS?</desc>\
				<type>Boolean</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="vhost">\
				<default>' + self._vhost + '</default>\
				<desc>Virtual Host</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="httpUser">\
				<default>' + self._httpUser + '</default>\
				<desc>HTTP User</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="httpPassword">\
				<default>' + self._httpPassword + '</default>\
				<desc>HTTP Password</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
			<Option name="authType">\
				<default>' + self._authType + '</default>\
				<desc>Authentication Type</desc>\
				<type>String</type>\
				<required>False</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def getHost(self):
		return self._host

	def getPath(self):
		return self._path

	def setPath(self, path):
		self._path = path

	def getPort(self):
		return self._port

	def getIsHTTPS(self):
		return self._isHTTPS

	def setHost(self, value):
		self._host = value

	def setPort(self, value):
		self._port = value

	def setIsHTTPS(self, value):
		self._isHTTPS = value

	def getAuthType(self):
		return self._authType

	def setAuthType(self, auth):
		self._authType = auth

	def setReqHeader(self, name, value):
		self._reqHeaders[name] = value

	def setCookie(self, value, appendValue='&'):
		if 'Cookie' in self._reqHeaders.keys():
			self._reqHeaders['Cookie'].append(appendValue + value)
		else:
			self._reqHeaders['Cookie'] = value
