# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from fwk.connectors.baseHTTPConnector import baseHTTPConnector
from core.exceptions.bizploitException import bizploitException
from core.lib.misc import *
import urllib2 as ulib
import httplib



class connSAPICM(baseHTTPConnector):
    '''
    Connector for the SAP ICM (Internet Communication Framework)
    
    '''
    def __init__(self):
        baseHTTPConnector.__init__(self)
        self._connName = 'SAPICM'
        self._port = 8000
        self._basePath = ''

        # Force the english language for content parsing
        self.setCookie('sap-usercontext=sap-language=DE')

    def checkURIBPath(self, uri, headers={}):
        '''
        Esta clase es un metodo alternativo al checkURI del baseHTTPConnector
        este metodo siempre apendeara el base path!
        '''
        # We remove the / in case it's there
        if uri[0] == '/':
            uri = uri[1:]

        # Configure request headers
        if not headers:
            headers = self.getDefaultHeaders()

        conn = None
        if self._isHTTPS:
            conn = httplib.HTTPSConnection(self.getHost(), self.getPort())
        else:
            conn = httplib.HTTPConnection(self.getHost(), self.getPort())

        try:
            if len(self.getBasePath().strip()) > 0:
                #Tengo algo en el basepath
                if str(uri).startswith('/'):
                    conn.request("HEAD", self.getBasePath() + uri)
                else:
                    conn.request("HEAD", self.getBasePath() + '/' + uri)

            else:
                #No tengo nada en el basepath
                if str(uri).startswith('/'):
                    conn.request("HEAD", uri)
                else:
                    conn.request("HEAD", '/' + uri)

            res = conn.getresponse()
            return res.status
        except Exception, e:
            raise bizploitException('Error in communication with SAP ICM: ' + str(e))


    def confByDiscover(self, system, port):
        self._host = system
        self._port = port

        # We have to figure out if it is HTTP or HTTPS. If HTTPS and HTTP, use HTTPS for increased security.
        self.setIsHTTPS(True)
        try:
            self.checkConnect()
            return True
        except bizploitException:
            pass

        self.setIsHTTPS(False)
        try:
            self.checkConnect()
        except bizploitException:
            pass

        return True

    def checkConnect(self):
        self.setCookie('')
        self.connect()

    def getFriendlyName(self):
        return '%s TCP / %s' % (str(self._port), self.getName())

    def __eq__(self, aConn):
        '''
        Redefinition of the equals method to compare against other connectors directly in python.
        @param aConn: connector to compare to.
        '''
        # We check if we are comparing against a new connector or an already existing one.
        # We have to do this, otherwise the comparison will always say true if we don't care about IDs.
        if not isinstance(aConn, connSAPICM):
            return False

        myIP = ''
        otherIP = ''
        try:
            myIP, otherIP = resolveHostList([self._host, aConn.getHost()])
        except bizploitException, e:
            self._om.debug(self, 'Error: ' + str(e))

        if self._connID == -1:
            return myIP == otherIP and self._port == aConn.getPort()
        else:
            return self._connID == aConn.getID() and \
                        myIP == otherIP and self._port == aConn.getPort()


    def getConfiguration(self):
        return  'SAP ICM Host: ' + self._host + '\n'  \
                'SAP ICM Port: ' + str(self._port) + '\n'  \
                'HTTPS / HTTPS: ' + ('HTTPS' if self.getIsHTTPS() else 'HTTP')

    def preconfig(self, target):
        '''
        Preconfigures the connector according to the parent target configuration
        '''
        self._host = target.getHost()

    def getOptionsXML(self):
        return '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="host">\
                <default>' + self._host + '</default>\
                <desc>SAProuter host</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>False</visible>\
            </Option>\
            <Option name="port">\
                <default>' + str(self._port) + '</default>\
                <desc>HTTP(S) port</desc>\
                <type>Integer</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="isHTTPS">\
                <default>' + str(self._isHTTPS) + '</default>\
                <desc>Use HTTPS?</desc>\
                <type>Boolean</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="vhost">\
                <default>' + self._vhost + '</default>\
                <desc>Virtual Host</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="client">\
                <default>' + self._client + '</default>\
                <desc>Client</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpUser">\
                <default>' + self._httpUser + '</default>\
                <desc>HTTP User</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="httpPassword">\
                <default>' + self._httpPassword + '</default>\
                <desc>HTTP Password</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="authType">\
                <default>' + self._authType + '</default>\
                <desc>Authentication Type</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '

    def getBasePath(self):
        return self._basePath

    def setBasePath(self, path):
        self._basePath = path

    def getClient(self):
        return self._client