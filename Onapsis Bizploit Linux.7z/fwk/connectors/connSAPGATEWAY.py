# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from fwk.connectors.baseConnector import baseConnector
from core.data.parseOptions import parseOptions
import fwk.connectors.lib.libSAPRFC as libSAPRFC
import fwk.connectors.lib.libMon_SAPGATEWAY as libMon_SAPGATEWAY
from core.exceptions.bizploitException import bizploitException
from core.exceptions.couldNotConnectException import couldNotConnectException
from core.exceptions.rfcErrorException import rfcErrorException
import core.kb.knowledgeBase as kb
from core.lib.misc import *


# RFC libraries
if kb.globalKB.getGlobal('RFCLibraryAvailable'):
	import saprfcutil
	

# exceptions

class connSAPGATEWAY(baseConnector):
	'''
	SAPGATEWAY Connector.
	Connects with SAP Gateways.
	
	@author: Mariano Nu�ez  Di Croce 
	'''
	def __init__( self):
		baseConnector.__init__(self)
		self._connName = 'SAPGATEWAY'
		self._lib = libSAPRFC
		self._libMon = libMon_SAPGATEWAY
		self._gwhost = '127.0.0.1'
		self._gwserv = '3300'
	
	# RFC Connection Methods
	def connectRFC(self, mode, tphost = '', tpname = ''):
		'''
		Connects with the target SAP Gateway.
		'''
		self._conn = self._lib.conn(type='E', gwhost = self._gwhost, gwserv = self._gwserv, tpname = tpname)
		try:
			self._conn.connect()
		except bizploitException,  e:
			raise couldNotConnectException(str(e))
		
		return self._conn
		
	def disconnectRFC(self):
		'''
		Disconnects from current server.
		'''
		try:
			saprfcutil.close(self._conn.connection)
		except:
			# Connection could not be closed, just ignore
			om.out.debug(self,'Could not close connection with target #' + str(self._connID))
	
	def call_receiveRFC(self, callObj):
		'''
		Sends an RFC call to the target and receives the result.
		
		@parameters callObj: RFC Call object
		'''
		try:
			if saprfcutil.call_receive(self._conn, callObj) == 0:
				raise rfcErrorException('RFC call failed.')
		except TypeError, e:
			raise bizploitException(str(e))
			
	def tryRegister(self, tpname):
		'''
		Tries to register an external RFC server.
		'''
		conn = libSAPRFC.conn(gwhost = self._gwhost, gwserv = self._gwserv, tpname = tpname)
		conn.connstr = "-a " + tpname + " -g " + self._gwhost + " -x " + self._gwserv + " -t 0"
		saprfcutil.tryRegister(conn)
		
	# Standard Methods
	def getOptionsXML(self):
		return '<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="gwhost">\
				<default>'+self._gwhost+'</default>\
				<desc>Gateway host</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>False</visible>\
			</Option>\
			<Option name="gwserv">\
				<default>'+self._gwserv+'</default>\
				<desc>Gateway service</desc>\
				<type>String</type>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'
		
	def getConfiguration(self):
		return	'SAP Gateway Host: ' + self._gwhost + '\n'  \
					'SAP Gateway Service: ' + self._gwserv

	def confByDiscover(self, system, port,  saprouter=None):
		if saprouter:
				return False
				
		self._gwhost = system
		self._gwserv = '33' + str(port)[-2:]
		return True
	
	def preconfig(self,  target):
		'''
		Preconfigures the connector according to the parent target configuration
		'''
		self._gwhost = target.getHost()
	
	def getGwHost(self):
		return self._gwhost

	def getGwServ(self):
		return self._gwserv

	def __eq__(self,  aConn):
		'''
		Redefinition of the equals method to compare against other connectors directly in python.
		@param aConn: connector to compare to.
		'''
		# We check if we are comparing against a new connector or an already existing one.
		# We have to do this, otherwise the comparison will always say true if we don't care about IDs.
		
		if not isinstance(aConn, connSAPGATEWAY):
			return False
		
		myIP = ''
		otherIP = ''
		try:
			myIP, otherIP = resolveHostList([self._gwhost, aConn.getGwHost()])
		except bizploitException, e:			
			self._om.debug(self,  'Error: ' + str(e)) 
			
		if self._connID == -1:
			return myIP == otherIP and self._gwserv == aConn.getGwServ()
		else:
			return self._connID == aConn.getID() and \
				    myIP == otherIP and self._gwserv == aConn.getGwServ()
