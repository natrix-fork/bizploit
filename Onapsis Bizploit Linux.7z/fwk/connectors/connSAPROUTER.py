# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from fwk.connectors.baseConnector import baseConnector
from core.data.parseOptions import parseOptions
import core.output.outputManager as om
from core.lib.misc import *
import fwk.connectors.lib.libNI as libNI
import socket
from core.exceptions.bizploitException import bizploitException
from core.exceptions.couldNotConnectException import couldNotConnectException

# libraries

# exceptions

class connSAPROUTER(baseConnector):
	'''
	SAPROUTER Connector.
	Connects with SAProuters.
	
	@author: Mariano Nu�ez  Di Croce 
	'''
	def __init__(self):
		baseConnector.__init__(self)
		self._connName = 'SAPROUTER'
		self._lib = libNI
		self._libMon = None
		self._host = '127.0.0.1'
		self._port = 3299
		self._socket = None
		self._tmout = 10
		self._connected = False
		self._chainedRouters = []

	def connect(self, sock=None):
		'''
		Connects with the remote SAProuter.
		@parameter sock: If specified, use this socket (used for tunnels)
		'''
		if sock:
			self._socket = sock
		else:
			self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self._socket.settimeout(self._tmout)

		intPort = resolveService(self._port)

		try:
			self._socket.connect((self._host, intPort))
			self._connected = True
		except socket.error, msg:
			raise couldNotConnectException(str(msg))

		return True


	def send(self, type="", route=[], data=None, paq=None):
		'''
		Sends a packet through the SAProuter.
		
		@parameter type: packet type 
		@parameter route: List of maps [{'saprouter1':3299},{'sapserv':3200}]
		@parameter data: Data to send.
		@parameter paq: Paquet to send explicitly defined.
		
		'''
		if not paq:
			# If packet not defined, create a new one
			if type == 'NI_ROUT_IO':
				paqToSend = self._lib.niPacket_NI_ROUTE_IO()
			elif type == 'NI_MSG_IO':
				paqToSend = self._lib.niPacket_NI_MSG_IO()
			elif type == 'NI_RAW_IO':
				paqToSend = self._lib.niPacket_NI_RAW_IO()
			else:
				raise bizploitException('Packet type not valid.')

			# Define packet route
			if route:
				paqToSend.setRoute(route)

			if data:
				paqToSend.setData(data)

		else:
			paqToSend = paq

		try:
			self._socket.send(paqToSend.serialize())
		except socket.error:
			raise bizploitException('Could not send data to the remote SAP router')

		return True

	def send_receive(self, type="", route=[], paq=None, data=None, processNiErrors=True):
		'''
		Send information through the SAProuter and receives the response.
		
		@parameter type: packet type 
		@parameter route: List of maps [{'saprouter1':3299},{'sapserv':3200}]
		@parameter data: Data to send.
		@parameter paq: Paquet to send explicitly defined.
		@parameter processNiErrors: Defines if NI errors are processed and reported as exceptions.
		@returns: data of the NI response.
		
		'''
		if not paq:
			# If packet not defined, create a new one
			if type == 'NI_ROUT_IO':
				paqToSend = self._lib.niPacket_NI_ROUTE_IO()
			elif type == 'NI_MSG_IO':
				paqToSend = self._lib.niPacket_NI_MSG_IO()
			elif type == 'NI_RAW_IO':
				paqToSend = self._lib.niPacket_NI_RAW_IO()
			elif type == 'NI_ROUTER_ADM':
				paqToSend = self._lib.niPacket_NI_ROUTER_ADM()
			else:
				raise bizploitException('Packet type not valid.')

			# Define paquet route
			if route:
				paqToSend.setRoute(route)

			if data:
				paqToSend.setData(data)

		else:
			paqToSend = paq

		dataRecv = ''
		try:
			self._socket.send(paqToSend.serialize())
			size = self._socket.recv(4)
			size = struct.unpack('!L', size)[0]
			# Receive the rest
			if size != 0:
				dataRecv = self._socket.recv(size)
		except socket.error, e:
			raise bizploitException(str(e))
		except:
			raise bizploitException('Could not send data to the remote SAProuter')

		# Error processing
		if processNiErrors:
			paqToSend.processErrors(dataRecv)

		return dataRecv

	def disconnect(self):
		self._socket.close()

	def craftRoute(self, host, port, chainedRouters):
		'''
		Returns a list of maps containing the route to the last hop of the chainedRouters list
		'''
		alst = [{host:port}]
		for hop in chainedRouters:
			try:
				hophost, hopport = hop.split(':')
				alst.append({hophost:hopport})
			except:
				raise bizploitException('Bad formed route of chainedRouters.')

		return alst

	def getThisHop(self):
		'''
		Returns this SAProuter as a hop for the route
		'''
		return {self._host:self._port}

	# Standard Methods
	def getOptionsXML(self):
		return '<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="host">\
				<default>' + self._host + '</default>\
				<desc>SAProuter host</desc>\
				<type>String</type>\
				<required>True</required>\
				<visible>False</visible>\
			</Option>\
			<Option name="port">\
				<default>' + str(self._port) + '</default>\
				<desc>SAProuter port</desc>\
				<type>Integer</type>\
				<required>True</required>\
				<visible>True</visible>\
			</Option>\
		</OptionList>\
		'

	def getConfiguration(self):
		return	'SAP Router Host: ' + self._host + '\n'  \
					'SAP Router Port: ' + str(self._port)

	def confByDiscover(self, system, port, saprouter=None):
		self._host = system
		self._port = port
		return True

	def preconfig(self, target):
		'''
		Preconfigures the connector according to the parent target configuration
		'''
		self._host = target.getHost()

	def getHost(self):
		return self._host

	def getPort(self):
		return self._port

	def __eq__(self, aConn):
		'''
		Redefinition of the equals method to compare against other connectors directly in python.
		@param aConn: connector to compare to.
		'''
		# We check if we are comparing against a new connector or an already existing one.
		# We have to do this, otherwise the comparison will always say true if we don't care about IDs.
		if not isinstance(aConn, connSAPROUTER):
			return False

		myIP = ''
		otherIP = ''
		try:
			myIP, otherIP = resolveHostList([self._host, aConn.getHost()])
		except bizploitException, e:
			self._om.debug(self, 'Error: ' + str(e))

		if self._connID == -1:
			return myIP == otherIP and self._port == aConn.getPort()
		else:
			return self._connID == aConn.getID() and \
						myIP == otherIP and self._port == aConn.getPort()
