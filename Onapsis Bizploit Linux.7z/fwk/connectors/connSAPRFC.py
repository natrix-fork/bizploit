# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import fwk.connectors.lib.libSAPRFC as libSAPRFC
from core.data.parseOptions import parseOptions
from core.exceptions.couldNotConnectException import couldNotConnectException
from core.exceptions.rfcErrorException import rfcErrorException
from core.exceptions.bizploitException import bizploitException
from fwk.connectors.baseConnector import baseConnector
import core.kb.knowledgeBase as kb
from core.lib.misc import *

# RFC libraries
if kb.globalKB.getGlobal('RFCLibraryAvailable'):
    import saprfcutil

class connSAPRFC(baseConnector):
    '''
    SAPRFC Connector.
    Connects to SAP Application Servers.    
    @author: Mariano Nu�ez  Di Croce 
    '''
    def __init__( self):
        baseConnector.__init__(self)
        self._connName = 'SAPRFC'
        self._lib = libSAPRFC        
        self._ashost = '127.0.0.1'
        self._lang = 'EN'
        self._sysnr = 00
        self._client = 000
        self._user = 'bizploit'
        self._passwd = 'bizploitPASS'
        self._gwhost = ''
        self._gwserv = ''
    
    # RFC Connection Methods
    def connect(self, lcheck=0):
        '''
        Connects with the target SAP Application Server
        '''
        if not self._conn:
            self._conn = self._lib.conn(type='3', ashost = self._ashost, sysnr = '%02d' % self._sysnr, client = '%03d' % self._client, user= self._user, passwd=self._passwd, lang = self._lang, lcheck=lcheck)
            try:
                self._conn.connect()
            except Exception, e:
                self._conn = None
                raise couldNotConnectException(str(e))
    
    def disconnect(self):
        '''
        Disconnects from current server.
        '''
        if self._conn:
            try:
                saprfcutil.close(self._conn.connection)            
            except Exception,  e:
                # Connection could not be closed, just ignore
                om.out.debug(self,str(e))
            self._conn = None
    
    def isConnected(self):
        return (self._conn != None)
    
    def call_receive(self, callObj):
        '''
        Sends an RFC call to the target and receives the result.
        
        @parameters callObj: RFC Call object
        '''
        try:            
            if saprfcutil.call_receive(self._conn, callObj) == 0:
                self.disconnect()
                raise bizploitException('RFC call failed.')
        except TypeError, e:
            self.disconnect()
            raise bizploitException(str(e))
    
    def call(self, callObj):
        '''
        Sends an RFC call to the target without waiting for a result.
        
        @parameters callObj: RFC Call object
        '''
        try:            
            if saprfcutil.call(self._conn, callObj) == 0:
                self.disconnect()
                raise rfcErrorException('RFC call failed.')
        except TypeError, e:
            self.disconnect()
            raise bizploitException(str(e))
    
    # Standard Methods
    def getOptionsXML(self):
        return '<?xml version="1.0" encoding="ISO-8859-1"?>\
        <OptionList>\
            <Option name="ashost">\
                <default>'+self._ashost+'</default>\
                <desc>SAP Application Server host</desc>\
                <type>String</type>\
                <required>True</required>\
                <visible>False</visible>\
            </Option>\
            <Option name="sysnr">\
                <default>'+'%02d' % self._sysnr+'</default>\
                <desc>System Number</desc>\
                <type>Integer</type>\
                <required>True</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="client">\
                <default>'+'%03d' % self._client+'</default>\
                <desc>Client</desc>\
                <type>Integer</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="lang">\
                <default>'+self._lang+'</default>\
                <desc>Language</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="user">\
                <default>'+self._user+'</default>\
                <desc>Username</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="passwd">\
                <default>'+self._passwd+'</default>\
                <desc>Password</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="gwhost">\
                <default>'+self._gwhost+'</default>\
                <desc>Gateway host</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
            <Option name="gwserv">\
                <default>'+self._gwserv+'</default>\
                <desc>Gateway service</desc>\
                <type>String</type>\
                <required>False</required>\
                <visible>True</visible>\
            </Option>\
        </OptionList>\
        '
    
        
    def getConfiguration(self):
        if self._conn:
            return 'No information available.'
        else:    
            return    'SAP Application Server: ' + self._ashost + '\n'  \
                        'System Number: ' + '%02d' %  self._sysnr + '\n' \
                        'Client: ' +  '%03d' % self._client + '\n' \
                        'Language: ' + self._lang + '\n' \
                        'Username: ' + self._user + '\n' \
                        'Password: ' + '********' #self._passwd 
        
    def confByDiscover(self, system, port,  saprouter=None):
        if not saprouter:
            self._ashost = system
        else:
            self._ashost = self._craftSAProuterRoute(saprouter) + '/H/' + system
        self._sysnr = int(str(port)[-2:])
            
        return True
    
    def preconfig(self,  target):
        '''
        Preconfigures the connector according to the parent target configuration
        '''
        self._ashost = target.getHost()
    
    def _craftSAProuterRoute(self,  routeList):
        res = ''
        for route in routeList:
            host = route.keys()[0]
            res += '/H/' + host + '/S/' + str(route[host])
        
        return res
    
    # Getters
    def getAshost(self):
        return self._ashost
    
    def getUser(self):
        return self._user
        
    def getPasswd(self):
        return self._passwd
    
    def getClient(self):
        return self._client
    
    def getSysnr(self):
        return self._sysnr
    
    def getGwhost(self):
        return self._gwhost
    
    def getGwserv(self):
        return self._gwserv

    # Setters
    def setAsHost(self, ashost):
        self._ashost = ashost
    
    def setSysnr(self, sysnr):
        self._sysnr = sysnr
    
    def setGwHost(self, gwhost):
        self._gwhost = gwhost
        
    def setGwServ(self, gwserv):
        self._gwserv = gwserv
        
    def setClient(self, client):
        self._client = client
    
    def setUser(self, user):
        self._user = user
    
    def setPasswd(self, passwd):
        self._passwd = passwd
    
    def setLang(self, lang):
        self._lang = lang

    def structure(self,strt):
        return self._conn.structure(strt)

    def discover(self,name):
        return self._conn.discover(name)

    def __eq__(self,  aConn):
        '''
        Redefinition of the equals method to compare against other connectors directly in python.
        @param aConn: connector to compare to.
        '''
        # We check if we are comparing against a new connector or an already existing one.
        # We have to do this, otherwise the comparison will always say true if we don't care about IDs.
        
        if not isinstance(aConn, connSAPRFC):
            return False
        
        myIP = ''
        otherIP = ''
        try:
            myIP, otherIP = resolveHostList([self._ashost, aConn.getAshost()])
        except bizploitException, e:            
            self._om.debug(self,  'Error: ' + str(e)) 
        
        if self._connID == -1:
            return     myIP == otherIP and self._sysnr == aConn.getSysnr() and self._client == aConn.getClient() \
                    and self._user == aConn.getUser() and self._passwd == aConn.getPasswd() 
        else:
            return  self._connID == aConn.getID() and \
                    myIP == otherIP and self._sysnr == aConn.getSysnr() and self._client == aConn.getClient() \
                    and self._user == aConn.getUser() and self._passwd == aConn.getPasswd() 
        
