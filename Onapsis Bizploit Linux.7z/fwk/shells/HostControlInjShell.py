# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Jordan Santarsieri - jsantarsieri@onapsis.com	
	
Copyright 2012 ONAPSIS S.R.L.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import core.output.outputManager as om

from fwk.shells.baseShell import baseShell
from core.exceptions.bizploitException import bizploitException

class HostControlInjShell(baseShell):
	'''
	Run operating system commands by injecting commands in the GetDatabaseSatus
	method of the SAP Host Control.
	'''
	def __init__(self):
		baseShell.__init__(self)
		self._cmd = ""
		self._menu = {'run':self._run}

	def _onStart(self):
		self._om.console(self, 'HostControlInjShell - OS Commanding through SAP Host Control')

	def _run_SAPHOSTCONTROL(self, parameters):
		
		if len(parameters) < 1:
			self._parent._cmd_help(['run'])
			return
		self._cmd = ' '.join(parameters)
		try:
			print ''
		except Exception, e:
			raise bizploitException(str(e))
		return