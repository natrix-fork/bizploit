# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author: Mariano Nunez Di Croce <mnunez@onapsis.com> 
	
Copyright 2012 ONAPSIS S.R.L.
Base Copyright Mariano Nunez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.lib.pysocks.PySocks import socks4Proxy
from fwk.agents.baseAgent import baseAgent
from core.exceptions.bizploitException import bizploitException
import fwk.connectors.lib.libNI as libNI
import socket
import thread
import select
# TODO: Add support for chained routers agents

class saprouterAgent(baseAgent):
    '''
    Agent to proxy Native / SAP traffic through SAProuters.
    '''
    def __init__(self, bindAddress, bindPort):
        baseAgent.__init__(self)
        self._menu = {'startProxying':self._startProxying}
        self._server = None
        self._bindAddress = bindAddress
        self._bindPort = bindPort
        self._isFatalError = False

    def _startProxying_SAPROUTER(self, parameters):
        self._isFatalError = False
        self._om.information(self, 'Starting local agent endpoint... ')
        self._server = socks4Proxy(bindAddress=self._bindAddress, bindPort=self._bindPort, connectHandler=self._connHandler, errHandler=self._errHandler)
        if not self._isFatalError:
            self._server.start()
            self._om.information(self, 'Done.')
            self._om.information(self, 'agent: Local saprouterAgent endpoint listening at (' + self._bindAddress + ':' + str(self._bindPort) + ')')


    def _errHandler(self, error):
        '''
        Process errors from underlying objects.
        '''
        self._om.debug(self, 'Error: ' + error)
        self._isFatalError = True

    def _connHandler(self, req, socksHandler, socksCliSocket):
        ''' This is the connect Handler for the saprouterAgent - Proxy module
        Receives the raw data to send from the SOCKS Server, encodes it and fowards it to the SAPRouter.
        '''
        routerSocket = None
        # We get the information of the ENDPOINT
        host, port = req['address']

        # Create the route
        route = [self._connector.getThisHop(), {host:port}]

        # Connect to the SAPRouter
        self._om.debug(self, 'agent: Got connection to (' + host + ':' + str(port) + '). Deploying "remote" agent... ', newLine=False)
        try:
            self._connector.connect()
            routerSocket = self._connector.getSocket()
            self._connector.send_receive(type='NI_RAW_IO', route=route)
            # Tell the client that connection is ok
            socksHandler.answer_granted()
        except socket.error:
            self._om.information(self, '\nError: Could not talk back with agent client.')
            return False
        except bizploitException:
            self._om.information(self, '\nError: Could not connect with remote SAPRouter.')
            return False

        # Start forwarding packets
        self._om.debug(self, 'Done.')
        socksHandler.forward(socksCliSocket, routerSocket)

    def stop(self):
        self._server.stop()

