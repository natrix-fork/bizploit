# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>	
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import os, sys
import time
import glob

import core.kb.knowledgeBase as kb
import core.lib.portScanner as portScanner
import core.output.outputManager as om
import core.baseResult.pluginResult as pluginResult
from core.reporting.reportFactory import reportFactory
from core.data.config import config
from core.data.parseOptions import parseOptions
from core.exceptions.couldNotConnectException import couldNotConnectException
from core.exceptions.bizploitException import bizploitException
from threading import Thread
from core.lib.misc import *
from fwk.agents.baseAgent import baseAgent
from fwk.shells.baseShell import baseShell

# Adds  external libraries path. 
sys.path.append('extlib')

class bizploitCore:
	'''
	This is the core of the framework, it calls all plugins, handles exceptions,
	coordinates all the work, etc.
	 
	@author: Mariano Nu�ez Di Croce 
	'''

	def __init__(self):
		self._bizploit_version = '1.50'
		self._fwkVersion = '1.5.0'

		# A map with plugin types as keys and a list of plugin names as values
		self._strPlugins = {'discovery':[], 'vulnassess':[], 'exploit':[], 'output':[]}
		# A map with plugin types as keys and a list of plugin instances as values
		self._plugins = {'discovery':[], 'vulnassess':[], 'exploit':[], 'output':[]}
		self._pluginsOptions = {}
		self._autoDependencies = True
		self._isRunning = False

		# Initialize KM and OM
		self._kb = kb.knowledgeBase()
		self._om = om.out
		self._om.setKB(self._kb)

		# Times
		self._startTime = None
		self._stopTime = None

		# Initialize collections and counters
		self._shells = []
		self._agents = []
		self._targets = []
		self._connectors = []
		self._shellIDCounter = 0
		self._targetIDCounter = 0
		self._connectorIDCounter = 0
		self._agentIDCounter = 0

		self._executedPlugins = {}

		self._targetCache = {}

		self._config = config()

		self._clearEnvironment()
		self.getAvailableConnectors()

	def startOnThread(self, perspectiveType):
		process = Thread(target=self.start, args=(perspectiveType,))
		process.start()

	def checkbizploitProcessDone(self, process):
		if process.is_alive():
			return True
		else:
			return False

	def start(self, commands):
		'''
		Starts the work.
		
		@return: No value is returned.
		'''
		self._om.information(self, '')
		self._om.information(self, 'Starting bizploit session execution', timeStampEcho=True)

		self._isRunning = True

		if self._startTime == None:
			self._startTime = timestamp(format=1)
			self._stopTime = None

		try:
			om.out.debug(self, 'Cleaning old trace files...')
			self._cleanTRCs()

			# Initialize plugins
			self._initPlugins()

			# Initialize targets
			self._initTargets()

			if len(self._targets) == 0:
				self._om.information(self, 'No targets defined. Please configure at least one target to run a session.')
			else:
				# Start all the session phases. We feed the commands list received by the consoleUI to automate some plugins' tasks.
				self._discovery(commands, targets=self._targets)
				self._vulnassess(commands)
				# Don't run exploits directly with a start phase anymore.
				# Exploit plugins are run independently.
				# self._exploit(commands)

		except bizploitException, e:
			raise e
		except KeyboardInterrupt, e:
			# I wont handle this. 
			# The user interface must know what to do with it
			raise e
		finally:
			self._isRunning = False

		self._om.information(self, 'Finishing bizploit session execution.', timeStampEcho=True)
		self.stop()

	def _discovery(self, commands, targets=[]):
		'''
		This phase runs the discovery plugins over configured targets/connectors.
		@param targets: Optional parameter used to make the discovery recursive and search for new targets.
		'''
		newTargets = []
		runDisc = False

		if len(self._plugins['discovery']) != 0:
			runDisc = True
			# Info to the console 
			self._om.console(self, 'Starting DISCOVERY plugins', timeStampEcho=True)
			self._om.console(self, '----------------------------')
			# Info to the log
			self._om.log(self, 'Starting DISCOVERY plugins', timeStampEcho=True)

		for target in targets:
			#self._checkTargetInCache(target)
			for connector in target.getConnectors():
				for plugin in self._plugins['discovery']:
					# Check if still running
					if not self._isRunning:
						return

					plugin.setTarget(target)
					plugin.setConnector(connector)
					plugin.setCommands(commands)
					plugin.setKB(self._kb)
					plugin.setOM(self._om)
					if plugin.isCompatible():
						if plugin.getRunOncePerTarget() and plugin in self._executedPlugins[target]:
							self._writePluginNO_RUN_AGAIN(plugin, target, connector)
							continue

						try:
							self._writePluginStart(plugin, target, connector)
							newTargets.extend(plugin.run())
							# Set that the connector was already 'discovered' so to avoid innecesary recursion
							#connector.setDiscovered(True)

							# Update map of status
							self._executedPlugins[target].append(plugin)

							self._writePluginEndOK(plugin, target, connector)
						except couldNotConnectException, e :
							self._writePluginEndEXCEPT_CONN(plugin, target, connector, e)
							continue
						except bizploitException, e :
							self._writePluginEndEXCEPT_GRAL(plugin, target, connector, e)
							continue
					else:
						self._writePluginNO_COMPAT(plugin, target, connector)


		# Check for new targets and run discovery plugins against them
		if runDisc:
			if len(newTargets) != 0:
				self._om.debug(self, 'Discovery plugins have discovered targets/connectors. Running checks to avoid duplicates.')
				newTargets = self._cleanUpAndAddNewTargets(newTargets)
				if len(newTargets) != 0:
					self._om.information(self, ' ')
					self._om.information(self, 'Discovery plugins have discovered new targets/connectors:')
				for target in newTargets:
					self._om.information(self, 'Target ID: ' + str(target.getID()))
					self._om.information(self, target.getConfiguration())
					for connector in target.getConnectors():
						self._om.information(self, '\t[' + connector.getName() + '] (ID=' + str(connector.getID()) + ')')
						for line in connector.getConfiguration().splitlines():
							self._om.information(self, '\t' + line)
						self._om.information(self, '')

				if self._config.getData('recursiveDiscovery'):
					self._om.console(self, '')
					self._om.information(self, 'Re-running discovery phase for new targets.')
					self._discovery(commands, targets=newTargets)
			else:
				self._om.information(self, 'No new targets/connectors discovered.')

	def _vulnassess(self, commands):

		if len(self._plugins['vulnassess']) != 0:
			self._om.console(self, '\nStarting VULNERABILITY ASSESSMENT plugins', timeStampEcho=True)
			self._om.console(self, '----------------------------')
			# Info to the log
			self._om.log(self, 'Starting VULNERABILITY ASSESSMENT plugins')

		for target in self._targets:
			for connector in target.getConnectors():
				for plugin in self._plugins['vulnassess']:

					# Check if still running
					if not self._isRunning:
						return

					plugin.setTarget(target)
					plugin.setConnector(connector)
					plugin.setCommands(commands)
					plugin.setKB(self._kb)
					plugin.setOM(self._om)
					if plugin.isCompatible():
						if plugin.getRunOncePerTarget() and plugin in self._executedPlugins[target]:
							 self._writePluginNO_RUN_AGAIN(plugin, target, connector)
							 continue

						try:
							self._writePluginStart(plugin, target, connector)
							plugin.run()
							# Update map of status
							self._executedPlugins[target].append(plugin)

							self._writePluginEndOK(plugin, target, connector)
						except couldNotConnectException, e :
							self._writePluginEndEXCEPT_CONN(plugin, target, connector, e)
							continue
						except bizploitException, e :
							self._writePluginEndEXCEPT_GRAL(plugin, target, connector, e)
							continue
					else:
						self._writePluginNO_COMPAT(plugin, target, connector)

	def _exploit(self, commands):

		if len(self._plugins['exploit']) != 0:
			self._om.information(self, '\nStarting EXPLOIT plugins')
			self._om.information(self, '--------------------------')

		for target in self._targets:
			for connector in target.getConnectors():
				for plugin in self._plugins['exploit']:
					plugin.setTarget(target)
					plugin.setConnector(connector)
					plugin.setCommands(commands)
					#plugin.setKB(self._kb)
					#plugin.setOM(self._om)
					if plugin.isCompatible():
						if plugin.getRunOncePerTarget() and plugin in self._executedPlugins[target]:
							 self._writePluginNO_RUN_AGAIN(plugin, target, connector)

						try:
							self._writePluginStart(plugin, target, connector)
							resObj = plugin.run()
							# Update map of status
							self._executedPlugins[target].append(plugin)

							self.processExploitResult(resObj)
							self._writePluginEndOK(plugin, target, connector)
						except couldNotConnectException, e :
							self._writePluginEndEXCEPT_CONN(plugin, target, connector, e)
							continue
						except bizploitException, e :
							self._writePluginEndEXCEPT_GRAL(plugin, target, connector, e)
							continue
					else:
						self._writePluginNO_COMPAT(plugin, target, connector)


	def isRunning(self):
		return self._isRunning

	def stop(self):
		self._isRunning = False
		self._stopTime = timestamp(format=1)

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	CONFIGURATION AND MANAGEMENT
	
	The following section contains the methods used to manage bizploit configuration and general operations.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''
	def getConfig(self):
		return self._config

	def _clearEnvironment(self):
		'''
		Init some internal variables; this method is called when the whole process starts, and when the user
		loads a new profile.
		'''
		# A dict with plugin types as keys and a list of plugin names as values
		self._strPlugins = {'vulnassess':[], 'discovery':[], 'exploit':[], 'output':[]}
		self._pluginsOptions = {'vulnassess':{}, 'discovery':{}, 'exploit':{}, 'output':{}}

	def quit(self):
		# Clean-up
		self._unloadRFCLibrary()
		# Clean the .trc files
		self._cleanTRCs()

	def getFullVersionInfo(self):
		return 'bizploit - ERP Penetration Testing Framework ' \
					'\nVersion: v' + self._bizploit_version + \
					'\nAuthor: Onapsis Research Labs.' \
					'\nFor more information check http://www.onapsis.com/bizploit'

	def getShortVersion(self):
		return self._bizploit_version

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	TARGET MANAGEMENT
	
	The following section contains the methods used to manage targets.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''

	def _initTargets(self):
		'''
		We set every connector to the initial state
		'''
		for target in self._targets:
			self._executedPlugins[target] = []
			for conn in target.getConnectors():
				conn.setDiscovered(False)

	def getTargets(self):
		return self._targets

	def addTarget(self, target):
		'''
		Adds a target to the target collection. 
		'''

		# Set OM
		target.setOM(self._om)

		# Check if it does not exist
		if target not in self._targets:
			target.setID(self._targetIDCounter)

			self._targets.append(target)
			self._targetIDCounter += 1
		else:
			raise bizploitException('Target already exists')

	def delTarget(self, target):
		'''
		Deletes a target from the collection
		'''
		# First remove connectors
		for conn in target.getConnectors():
			self._kb.removeEntry(conn)
			self._connectors.remove(conn)

		self._targets.remove(target)



	def findTargetByID(self, id):
		'''
		Finds a target by ID.
		@returns: Target if found. None if not found.
		'''
		for target in self._targets:
			if id == target.getID():
				return target

		return None

	def findTargetByHost(self, host):
		'''
		Find a target by host.
		@returns: Target if found. None if not found.
		'''
		hostIP = 'myIP'
		otherIP = 'otherIP'
		try:
			hostIP = socket.gethostbyname(host)
		except Exception, e:
			self._om.debug(self, 'It is impossible to resolve target hostname \'' + host + '\'. Check your DNS configuration.')
			self._om.debug(self, 'Error: ' + str(e))
			pass

		for target in self._targets:
			try:
				otherIP = socket.gethostbyname(target.getHost())
			except Exception, e:
				self._om.debug(self, 'It is impossible to resolve target hostname \'' + target.getHost() + '\'. Check your DNS configuration.')
				self._om.debug(self, 'Error: ' + str(e))
				pass

			if host == target.getHost() or hostIP == otherIP:
				return target

		return None

	def findTargetByConnector(self, conn):
		'''
		Finds a target by connector.
		@returns: Target if found. None if not found.
		'''
		for target in self._targets:
			if conn in target.getConnectors():
				return target

		return None

	def _cleanUpAndAddNewTargets(self, newTargets):
		'''
		Analyze newTargets returned by discovered plugins to avoid having duplicates in the target collection.
		If target is already present, connectors are also verified for newly discovered ones.
		
		@param newTargets: New targets returned by the discovery phase
		'''
		resTargets = []
		# We have redefined the __eq__ method of each target and connector, so we can safely use python search engine ;P
		for newTarget in newTargets:
			# Temp hack
			newTarget.setOM(self._om)
			if newTarget in self._targets:
				# We must not add it again, but check if it has any new connectors
				oldTarget = self.findTargetByHost(newTarget.getHost())
				connAdded = False
				if oldTarget != None:
					self._om.debug(self, 'Target ' + oldTarget.getHost() + ' already exists. Checking new connectors.')
					for newConn in newTarget.getConnectors():
						if not newConn in oldTarget.getConnectors():
							self._om.debug(self, 'New connector ' + newConn.getName() + ' found. Adding.')
							try:
								self.addConnectorToTarget(oldTarget, newConn)
							except bizploitException:
								self._om.debug(self, 'Connector ' + newConn.getName() + ' already exists in target ' + oldTarget.getHost() + '. Not adding')
							connAdded = True
						else:
							# We need to update connector ID
							try:
								self.addConnectorToTarget(oldTarget, newConn, onlyUpdate=True)
							except bizploitException:
								self._om.debug(self, 'Connector ' + newConn.getName() + ' already exists in target ' + oldTarget.getHost() + '. Not adding')
					if connAdded:
						resTargets.append(oldTarget)
				else:
					self._om.debug(self, 'Impossible to clean targets in discovery. Inconsistences detected.')
					return	[]
			else:
				self._om.debug(self, 'Target ' + newTarget.getHost() + ' does not exist. Adding.')
				self.addTarget(newTarget)
				for conn in newTarget.getConnectors():
					try:
						self.addConnectorToTarget(newTarget, conn, onlyUpdate=True)
					except bizploitException:
								self._om.debug(self, 'Connector ' + conn.getName() + ' already exists in target ' + newTarget.getHost() + '. Not adding')

				resTargets.append(newTarget)

		return resTargets

	def _checkTargetInCache(self, target):
		'''
		Checks if the target is saved in the target cache to avoid innecesary DNS resolutions.
		If it's not, and can be resolved, it's added. Otherwise, an exception is generated.
		'''
		if target not in self._targetCache.keys():
			try:
				self._targetCache[target] = socket.gethostbyname(target.getHost())
			except:
				raise bizploitException('Target ' + target.getHost() + ' could not be resolved')

		return self._targetCache[target]

	def clearTargetAndConnectorCounters(self):
		self._targetIDCounter = 0
		self._connectorIDCounter = 0

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	CONNECTOR MANAGEMENT
	
	The following section contains the methods used to manage connectors and their interaction with targets.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''

	def checkRFCLibrary(self):
		# We have to check if the RFC library was installed all right here to avoid multiple error boxes in Windows :S
		try:
			import saprfcutil
			kb.globalKB.saveGlobal('RFCLibraryAvailable', True)			
		except:
			#TODO: To be improved with more time
			print "\nWarning: It was not possible to load the RFC library, some connectors might not work."
			kb.globalKB.saveGlobal('RFCLibraryAvailable', False)

		# Update available connectors information
		self.getAvailableConnectors()


	def runConnectorDiscovery(self, target, mode, pingFirst):
		'''
		Runs the discovery of connectors of the currently selected target.
		@param target: a baseTarget.
		@param mode: a scanning mode [sap|normal|full|portrange].
		@param pingFirst: if the target is to be TCP pinged before starting scan.
		'''
		self._isRunning = True

		system = target.getHost()
		ps = portScanner.portScanner(system, mode)
		#cntPorts = str(len(ps.createPortList(mode)))
		#self._om.information(self,'Starting connector discovery on target ' + system + ' (' + cntPorts + ' ports).', timeStampEcho=True)

		# Check availability
		if pingFirst == True:
			self._om.information(self, 'TCP-Pinging remote system %s first. ' % system, newLine=False)
			if not ps.pingTCP():
				self._om.information(self, 'Target seems to be unavailable, skipping.')
				self._isRunning = False
				return True
			else:
				self._om.information(self, 'Available.')

		# Start the portscanning
		self._om.information(self, 'The port scanning is being performed. Please wait, it could take a while.')		
		res = ps.scanTCP()
		if not res:
			return

		if res['open']:
			self._om.information(self, 'OPEN ports on target ' + system + ':')
			self.mprint('Port', 'Default Service')
			self.mprint('----', '---------------')
			for port in res['open']:
				portInfo = ps.getPortInfo(port)
				self.mprint(str(port) + '/tcp', portInfo['name'])
		else:
			self._om.information(self, 'No OPEN ports on target ' + system)

		# Check if the service has a connector associated, and it is available for us
		for port in res['open']:
			portInfo = ps.getPortInfo(port)
			for connector in portInfo['connectors']:
				if connector in self._availableConnectors:
					connObj = factory('fwk.connectors.conn' + connector)
					compatible = connObj.confByDiscover(system, port)
					if compatible:
						try:
							self.addConnectorToTarget(target, connObj)
							self._om.information(self, 'Added ' + connector + ' connector to target ' + str(target.getID()) + '.')
						except bizploitException:
							self._om.debug(self, 'Not adding connector ' + connector + ' to target ' + target.getHost() + ' because there is already one with the same configuration.')

		self._om.information(self, 'Connector discovery completed.', timeStampEcho=True)
		self._isRunning = False
		return True

	def findConnectorByType(self, type):
		'''
		Finds a connector by type.
		@returns: List of connectors if found. Empty list if not.
		'''
		found = []
		for connector in self._connectors:
			try:
				conn = factory('fwk.connectors.conn' + type)
			except:
				return []
			if connector.getName() == conn.getName():
				found.append(connector)
		return found

	def findConnectorByID(self, id):
		'''
		Finds a connector by ID.
		@returns: connector if found. None if not found.
		'''
		for conn in self._connectors:
			if id == conn.getID():
				return conn

		return None

	def delConnector(self, conn):
		'''
		Deletes a connector.
		'''
		for target in self._targets:
			if conn in target.getConnectors():
				target.delConnector(conn)

		self._connectors.remove(conn)
		# We don't delete it from the KB, because maybe some results are already there

	def getConnectors(self):
		return self._connectors

	def addConnectorToTarget(self, aTarget, aConn, onlyUpdate=False):
		'''
		Adds a new connector to the target.
		'''
		if aConn in aTarget.getConnectors() and not onlyUpdate:
			raise bizploitException('Connector exists')

		aConn.setID(self._connectorIDCounter)
		self._connectors.append(aConn)
		self._connectorIDCounter += 1

		# Add to the KB
		self._kb.addNewEntry(aConn)
		# Set KB and OM (ugly coupling)
		aConn.setKB(self._kb)
		aConn.setOM(self._om)

		if not onlyUpdate:
			aTarget.addConnector(aConn)

	def editConnectorToTarget(self, aTarget, aConn, onlyUpdate=True):
		'''
		Adds a new connector to the target.
		'''
		if aConn not in aTarget.getConnectors() and onlyUpdate:
			raise bizploitException('Connector doesn\'t exist')

		#aConn.setID(self._connectorIDCounter)
		#self._connectors.append(aConn)
		#self._connectorIDCounter += 1

		# Add to the KB
		#self._kb.addNewEntry(aConn)
		# Set KB and OM (ugly coupling)
		#aConn.setKB(self._kb)
		#aConn.setOM(self._om)

		#if not onlyUpdate:
		#	aTarget.addConnector(aConn)

	def getAvailableConnectors(self, output=False):
		'''
		Returns a list with the connectors available.
		'''
		self._availableConnectors = []
		rfclibAvailable = True
		if kb.globalKB.getGlobal('RFCLibraryAvailable'):
			if output:
				self._om.debug(self, 'SAPRFC connector available.')
				self._om.debug(self, 'SAPRFC_EXT connector available.')
				self._om.debug(self, 'SAPGATEWAY connector available.')
			self._availableConnectors.append('SAPRFC')
			self._availableConnectors.append('SAPGATEWAY')
			self._availableConnectors.append('SAPRFC_EXT')
		else:
			if output:
				self._om.debug(self, 'SAPRFC connector NOT available.')
				self._om.debug(self, 'SAPRFC_EXT connector NOT available.')
				self._om.debug(self, 'SAPGATEWAY connector NOT available.')
				rfclibAvailable = False

		try:
			import croaklib
			if output:
				self._om.debug(self, 'CROAKlib connector available.')
			self._availableConnectors.append('CROAKlib')
		except:
			if output:
				self._om.debug(self, 'CROAKlib connector NOT available.')

		# Always available connectors
		self._availableConnectors.append('SAPROUTER')
		if output:
			self._om.debug(self, 'SAPROUTER connector available.')

		self._availableConnectors.append('SAPICM')
		if output:
			self._om.debug(self, 'SAPICM connector available.')

		self._availableConnectors.append('SAPMC')
		if output:
			self._om.debug(self, 'SAPMC connector available.')
			
		#self._availableConnectors.append('SAPHOSTCONTROL')
		#if output:
		#	self._om.debug(self, 'SAPHOSTCONTROL connector available.')

		self._availableConnectors.append('SAPPORTAL')
		if output:
			self._om.debug(self, 'SAPPORTAL connector available.')


		if not rfclibAvailable:
			self._om.debug(self, 'Warning: Could not load SAP RFC library. Check the Installation section in bizploit User Guide for more information.')

		return self._availableConnectors

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	VULNERABILITY MANAGEMENT
	
	The following section contains the methods used to manage vulnerabilities.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''

	def getPluginResults(self, connectors=None, onlyVulns=False, risks=[], orderByID=True):
		'''
		Gets pluginsResults according to the criteria specified
		'''
		resList = []
		
		if not connectors:
			connectors = []

		if len(connectors) == 0:
			for target in self.getTargets():
				connectors.extend(target.getConnectors())

		for connector in connectors:
			for plugin in self._kb.getPluginsForConnector(connector):
				for key in self._kb.getKeysForPlugin(connector, plugin):
					res = self._kb.getResultForKey(connector, plugin, key)
					if res and isinstance(res, pluginResult.pluginResult):
						if not onlyVulns or (onlyVulns and res.isVulnerability()):
							resList.append(res)

		if orderByID:
			resList.sort(lambda x, y: cmp(x.getID(), y.getID()))

		return resList


	def findVulnerabilityByID(self, id):

		for vuln in self.getPluginResults(onlyVulns=True):
			if vuln.getID() == id:
				return vuln

		return None

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SHELL MANAGEMENT
	
	The following section contains the methods used to manage shells.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''
	def getShells(self):
		return self._shells

	def addShell(self, shellObj):
		'''
		Adds a shell to the shells collection
		'''
		shellObj.setID(self._shellIDCounter)
		self._shells.append(shellObj)
		self._shellIDCounter += 1

		shellObj.setKB(self._kb)
		shellObj.setOM(self._om)

	def delShell(self, shellObj):
		self._shells.remove(shellObj)

	def findShellByID(self, id):
		'''
		Finds a shell by ID.
		@returns: shell if found. None if not found.
		'''
		for shell in self._shells:
			if id == shell.getID():
				return shell

		return None

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	AGENT MANAGEMENT
	
	The following section contains the methods used to manage agents.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''

	def getAgents(self):
		return self._agents

	def addAgent(self, agObj):
		'''
		Adds an agent to the agents collection
		'''
		agObj.setID(self._agentIDCounter)
		self._agents.append(agObj)
		self._agentIDCounter += 1

		agObj.setKB(self._kb)
		agObj.setOM(self._om)

	def delAgent(self, agObj):
		self._agents.remove(agObj)

	def findAgentByID(self, id):
		'''
		Finds a agent by ID.
		@returns: agent if found. None if not found.
		'''
		for agent in self._agents:
			if id == agent.getID():
				return agent

		return None

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	OUTPUT MANAGEMENT
	
	The following section contains the methods used to manage output from different bizploitCore methods.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''
	def _writePluginStart(self, plugin, target, connector):
		self._om.information(self, '')
		self._om.information(plugin, '')
		self._om.information(self, 'Running \'' + plugin.getName() + '\' against [' + target.getHost() + '(' + str(target.getID()) + ')-' + connector.getName() + '(' + str(connector.getID()) + ')]', timeStampEcho=True)
		self._om.log(plugin, 'Running \'' + plugin.getName() + '\' against [' + target.getHost() + '(' + str(target.getID()) + ')-' + connector.getName() + '(' + str(connector.getID()) + ')]', timeStampEcho=True)

	def _writePluginEndOK(self, plugin, target, connector):
		self._om.information(self, 'Execution finished with result code: OK', timeStampEcho=True)
		self._om.log(plugin, 'Execution finished with result code: OK', timeStampEcho=True)

	def _writePluginEndEXCEPT_CONN(self, plugin, target, connector, e):
		self._om.debug(self, 'Plugin could not connect with [' + target.getHost() + '(' + str(target.getID()) + ')-' + connector.getName() + '(' + str(connector.getID()) + ')].', timeStampEcho=True)
		self._om.debug(self, 'Error: ' + str(e))
		self._om.information(self, 'Execution finished with result code: ERROR', timeStampEcho=True)
		self._om.log(plugin, 'Execution finished with result code: ERROR', timeStampEcho=True)

	def _writePluginEndEXCEPT_GRAL(self, plugin, target, connector, e):
		self._om.information(self, "Plugin finished with errors. Check debug mode for more information.")
		self._om.debug(self, 'Error: ' + str(e))
		self._om.information(self, 'Execution finished with result code: ERROR', timeStampEcho=True)
		self._om.log(plugin, 'Execution finished with result code: ERROR', timeStampEcho=True)

	def _writePluginNO_COMPAT(self, plugin, target, connector):
		self._om.debug(self, 'Not running \'' + plugin.getName() + '\' against [' + target.getHost() + '(' + str(target.getID()) + ')-' + connector.getName() + '(' + str(connector.getID()) + ')] reason: The plugin is not compatible with the connector ' + connector.getName(), timeStampEcho=True)

	def _writePluginNO_RUN_AGAIN(self, plugin, target, connector):
		self._om.debug(self, 'Not running \'' + plugin.getName() + '\' against [' + target.getHost() + '] reason: The plugin has already been run against this target.', timeStampEcho=True)

	def mprint(self, col1, col2):
		'''
		Prints two columns to the console.
		'''
		spaces = 20
		spaces -= len(col1)
		self._om.information(self, col1, newLine=False)
		for i in range(spaces):
			self._om.information(self, ' ', newLine=False)
		self._om.information(self, col2)

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	REPORT MANAGEMENT
	
	The following section contains the methods used to create and load reports
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''

	def createReport(self, type, format, file='', mode='w'):
		try:
			reportFactory(self, type, format, file=file, mode=mode).create()
		except bizploitException, e:
			self._om.information(self, 'Error ocurred while saving report: ' + str(e))
		else:
			self._om.information(self, 'Report saved successfully.')

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	PLUGIN MANAGEMENT METHODS
	
	The following section contains the methods used to instantiate plugins, set their options, check dependencies, etc.
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''


	def getCompatiblePlugins(self, pluginType):
		'''
		Return compatible plugins with current targets/connectors
		'''
		res = []
		for strPlug in self.getPluginList(pluginType):
			plug = self.getPluginInstance(strPlug, pluginType)
			for target in self._targets:
				for conn in target.getConnectors():
					if plug.isCompatible(connector=conn):
						res.append(strPlug)

		return list(set(res))

	def setPluginOptions(self, pluginType, pluginName, pluginOptions):

		if pluginType.lower() == 'output':
			self._om.setPluginOptions(pluginName, pluginOptions)
			return

		# The following lines make sure that the plugin will accept the options
		# that the user is setting to it.
		pI = self.getPluginInstance(pluginName, pluginType)
		try:
			pluginName, parsedOptions = parseOptions(pluginName, pluginOptions)
			pI.setOptions(parsedOptions)
		except Exception, e:
			raise e
		else:
			# Now that we are sure that these options are valid, lets save them
			# so we can use them later!
			self._pluginsOptions[ pluginType ][ pluginName ] = parsedOptions

	def getPluginOptions(self, pluginType, pluginName):
		'''
		Get the options for a plugin.
		
		IMPORTANT NOTE: This method only returns the options for a plugin that was previously configured using setPluginOptions.
		If you wan't to get the default options for a plugin, get a plugin instance and perform a plugin.getOptions()
		
		@return: An optionList with the plugin options.
		'''
		if pluginType in self._pluginsOptions:
			if pluginName in self._pluginsOptions[pluginType]:
				return self._pluginsOptions[ pluginType ][ pluginName ]
		return None


	def addPlugin(self, pluginName, pluginType):
		'''
		This method adds plugins to the bizploitCore independently.
		
		@parameter pluginName: The name of plugin to add.
		@parameter pluginType: The type of the plugin.
		@return: None
		'''
		self._strPlugins[pluginType].append(pluginName)

	def removePlugin(self, pluginName, pluginType):
		'''
		This method removes plugins from the bizploitCore independently.
		
		@parameter pluginName: The name of plugin to remove.
		@parameter pluginType: The type of the plugin.
		@return: None
		'''
		self._strPlugins[pluginType].remove(pluginName)


	def setPlugins(self, pluginNames, pluginType):
		'''
		This method sets the plugins that bizploitCore is going to use. 
		
		@parameter pluginNames: A list with the names of the Plugins that will be runned.
		@parameter pluginType: The type of the plugin.
		@return: None
		'''
		setMap = {'discovery':self._setDiscoveryPlugins, 'vulnassess':self._setVulnAssessPlugins, 'output':self._setOutputPlugins, 'exploit': self._setExploitPlugins}

		func = setMap[ pluginType ]
		func(pluginNames)

	def getPluginTypes(self):
		'''
		@return: A list with all plugin types.
		'''
		pluginTypes = [ f for f in os.listdir('plugins/') if f.count('.py') == 0 and not f.startswith('.svn')]
		return pluginTypes

	def getPlugins(self):
		return self._strPlugins


	def _setOutputPlugins(self, outputPlugins):
		'''
		@parameter outputPlugins: A list with the names of output Plugins that will be runned.
		@return: No value is returned.
		'''
		self._strPlugins['output'] = outputPlugins
		self._om.setOutputPlugins(outputPlugins)


	def _setDiscoveryPlugins(self, DiscoveryPlugins):
		'''
		@parameter DiscoveryPlugins: A list with the names of DiscoveryPlugins that will be runned.
		@return: No value is returned.
		'''
		self._strPlugins['discovery'] = DiscoveryPlugins

	def _setVulnAssessPlugins(self, VulnAssessPlugins):
		'''
		@parameter VulnAssessPlugins: A list with the names of VulnAssess Plugins that will be runned.
		@return: No value is returned.
		'''
		self._strPlugins['vulnassess'] = VulnAssessPlugins

	def _setExploitPlugins(self, ExploitPlugins):
		'''
		@parameter ExploitPlugins: A list with the names of Exploit Plugins that will be used.
		@return: No value is returned.
		'''
		self._strPlugins['exploit'] = ExploitPlugins

	def getEnabledPlugins(self, pluginType):
		'''
		@parameter pluginType: Type of plugin
		Gets already enabled plugins of pluginType.
		'''
		return self._strPlugins[pluginType]

	def getPluginList(self, PluginType):
		'''
		@return: A string list of the names of all available exploit plugins.
		'''
		fileList = [ f for f in os.listdir('plugins/' + PluginType + '/') ]
		strReqPlugins = [ os.path.splitext(f)[0] for f in fileList if os.path.splitext(f)[1] == '.py' ]
		strReqPlugins.remove ('__init__')
		return strReqPlugins

	def getPluginInstance(self, pluginName, pluginType):
		'''
		@return: An instance of a plugin.
		'''
		pluginInst = None
		try:
			pluginInst = factory('plugins.' + pluginType + '.' + pluginName)
		except Exception, e:
			self._om.debug(self, 'Exception: ' + str(e))
			raise e

		if pluginName in self._pluginsOptions[ pluginType ].keys():
			pluginInst.setOptions(self._pluginsOptions[ pluginType ][pluginName])

		pluginInst.setKB(self._kb)
		pluginInst.setOM(self._om)

		return pluginInst

		raise bizploitException('Plugin not found')

	def setAutoDependencies(self, autodep):
		'''
		Set auto dependencies resolution.
		
		@parameter autodep: Boolean
		'''
		self._autoDependencies = autodep

	def getAutoDependencies(self): return self._autoDependencies

	def _getPluginsRecursive(self, dir):
		res = []
		fileList = [f for f in os.listdir(dir)]
		for d in fileList:
			if os.path.isdir(dir + os.path.sep + d):
				res.extend(self._getPluginsRecursive(dir + os.path.sep + d))
			else:
				if d != '__init__.py':
					res.append(dir + '.' + d)
		res = [f.replace(os.path.sep, '.').strip() for f in res]
		return res

	def _rPlugFactory(self, strReqPlugins, pluginType):
		'''
		This method creates the requested modules list.
		
		@parameter strReqPlugins: A string list with the requested plugins to be executed.
		@parameter PluginType: [vulnassess|discovery|grep]
		@return: A list with plugins to be executed, this list is ordered using the exec priority.
		
		Contributed by Andres Riancho 
		'''

		requestedPluginsList = []
		unwantedPlugins = []

		if 'all' in strReqPlugins:
			fileList = [ f for f in os.listdir('plugins' + os.path.sep + pluginType + os.path.sep) ]
			allPlugins = [ os.path.splitext(f)[0] for f in fileList if os.path.splitext(f)[1] == '.py' ]
			allPlugins.remove ('__init__')

			# Filter out excluded plugins
			if len (strReqPlugins) != 1:
				unwantedPlugins = [ x[1:] for x in strReqPlugins if x[0] == '!' ]
				strReqPlugins = list(set(allPlugins) - set(unwantedPlugins)) #bleh! v2
			else:
				strReqPlugins = allPlugins

			# Update the plugin list
			# This update is usefull for cases where the user selected "all" plugins,
			# the self._strPlugins[pluginType] is useless if it says 'all'.
			self._strPlugins[pluginType] = strReqPlugins

		for pluginName in strReqPlugins:
			plugin = factory('plugins.' + pluginType + '.' + pluginName)

			# Now we are going to check if the plugin dependencies are met
			for dep in plugin.getPluginDeps():
				try:
					depType, depPlugin = dep.split('.')
				except:
					raise bizploitException('Plugin dependencies must be indicated using pluginType.pluginName notation.\
					This is an error in ' + pluginName + '.getPluginDeps() .')
				if depType == pluginType:
					if  depPlugin in unwantedPlugins:
						self._om.information(self, 'The plugin ' + pluginType + '.' + depPlugin + ' is required by ' + pluginType + '.' + plugin.getName() + ', but was disabled by user. Check consistence.')
					elif depPlugin not in strReqPlugins:
						if self._config.getData('autoDependencies'):
							strReqPlugins.append(depPlugin)
							self._om.debug(self, 'Auto-enabling plugin: ' + pluginType + '.' + depPlugin)
							# nice recursive call, this solves the "dependency of dependency" problem =)
							return self._rPlugFactory(strReqPlugins, depType)
						else:
							raise bizploitException('Plugin ' + pluginName + ' depends on plugin ' + dep + ' and ' + dep + ' is not enabled. ')
				else:
					if  depPlugin in unwantedPlugins:
						self._om.information(self, 'The plugin ' + pluginType + '.' + depPlugin + ' is required by ' + pluginType + '.' + plugin.getName() + ', but was disabled by user. Check consistence.')
					elif depPlugin not in self._strPlugins[depType]:
						if self._config.getData('autoDependencies'):
							dependObj = factory('plugins.' + depType + '.' + depPlugin)
							if dependObj not in self._plugins[depType]:
								self._plugins[depType].insert(0, dependObj)
								self._strPlugins[depType].append(depPlugin)
							self._om.debug(self, 'Auto-enabling plugin: ' + depType + '.' + depPlugin)
						else:
							raise bizploitException('Plugin ' + pluginName + ' depends on plugin ' + dep + ' and ' + dep + ' is not enabled. ')
					else:
						# if someone in another planet depends on me... run first
						self._strPlugins[depType].remove(depPlugin)
						self._strPlugins[depType].insert(0, depPlugin)

			# Now we set the plugin options
			if pluginName in self._pluginsOptions[pluginType]:
				pOptions = self._pluginsOptions[pluginType][ pluginName ]
				plugin.setOptions(pOptions)

			# Append the plugin to the list
			requestedPluginsList.append (plugin)


		# The plugins are all on the requestedPluginsList, now I need to order them
		# based on the module dependencies. For example, if A depends on B , then
		# B must be runned first.

		orderedPluginList = []
		for plugin in requestedPluginsList:
			deps = plugin.getPluginDeps()
			if len(deps) != 0:
				# This plugin has dependencies, I should add the plugins in order
				for plugin2 in requestedPluginsList:
					if pluginType + '.' + plugin2.getName() in deps and plugin2 not in orderedPluginList:
						orderedPluginList.insert(1, plugin2)

			# Check if I was added because of a dep, if I wasnt, add me.
			if plugin not in orderedPluginList:
				orderedPluginList.insert(100, plugin)

		# This should never happend.
		if len(orderedPluginList) != len(requestedPluginsList):
			self._om.error(self, self, self, 'There is an error in the way bizploitCoreCore orders plugins. The ordered plugin list length is not equal to the requested plugin list. ', newLine=False)
			self._om.error(self, self, self, 'The error was found sorting plugins of type: ' + pluginType + '.')
			self._om.error(self, self, self, 'Please report this bug to the developers including a complete list of commands that you run to get to this error.')

			self._om.error(self, self, self, 'Ordered plugins:')
			for plugin in orderedPluginList:
				self._om.error(self, self, self, '- ' + plugin.getName())

			self._om.error(self, self, self, '\nRequested plugins:')
			for plugin in requestedPluginsList:
				self._om.error(self, self, self, '- ' + plugin.getName())

			sys.exit(-1)

		return orderedPluginList

	def _initPlugins(self):
		# First, create an instance of each requested plugin and add it to the plugin list
		# Plugins are added taking care of plugin dependencies
		self._plugins['discovery'] = self._rPlugFactory(self._strPlugins['discovery'] , 'discovery')
		self._plugins['vulnassess'] = self._rPlugFactory(self._strPlugins['vulnassess'] , 'vulnassess')
		self._plugins['exploit'] = self._rPlugFactory(self._strPlugins['exploit'] , 'exploit')

	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	MISC 
	
	The following section contains the methods used for general methods
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''


	def processExploitResult(self, resObj):
		'''
		Get the outcome of an exploit plugin.
		Outcome are shells/agents.
		'''

		if isinstance(resObj, baseShell):
			self.addShell(resObj)
			self._om.information(self, 'The plugin has created a new SHELL with ID: ' + str(resObj.getID()))
		elif isinstance(resObj, baseAgent):
			self.addAgent(resObj)
			self._om.information(self, 'The plugin has created a new AGENT with ID: ' + str(resObj.getID()))

	def _unloadRFCLibrary(self):
		try:
			import saprfcutil
			del saprfcutil
			del sys.modules['saprfcutil']
		except:
			self._om.debug(self, 'Could not unload the RFC Library')

	def _cleanTRCs(self):
		for tracefile in glob.glob('*.trc'):
			try:
				os.remove(tracefile)
			except:
				self._om.debug(self, 'Could not delete file: ' + tracefile)

	def setStartTime(self, value):
		self._startTime = value

	def getStartTime(self):
		return self._startTime

	def setStopTime(self, value):
		self._stopTime = value

	def getStopTime(self):
		return self._stopTime


	'''
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	VERSION MANAGEMENT
	
	The following section contains the methods used to manage bizploit versioning
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	'''
	def getFwkVersion(self):
		return self._fwkVersion

	def getName(self):
		return 'bizploitCore'

	def getID(self):
		return -10

	def getKB(self):
		return self._kb

	def setKB(self, value):
		self._kb = value

	def getOM(self):
		return self._om

	def setOM(self, value):
		self._om = value

# Make CORE World available
sCore = bizploitCore()
#sCore.checkRFCLibrary()