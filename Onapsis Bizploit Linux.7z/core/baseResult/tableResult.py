# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.baseResult.baseResult import baseResult as baseResult

class tableResult(baseResult):
    '''
    Result object for maps.
    '''
    def __init__( self,  key):
        baseResult.__init__(self,  key)
        self._header = ()
        self._rows = []
        self._title = ''

    def setHeader(self,  header):
        self._header = header
        
    def getHeader(self):
        return self._header

    def addRow(self,  row):
        self._rows.append(row)

    def getConsoleOutput(self):
        '''
        Output a result for printing in the console.
        Use a compatible format with the consoleUi tables.
        '''
        head = [val for val in self._header]
        table = [head]
        
        for row in self._rows:
            tabRow = [r for r in row]
            table.append(tabRow)
        
        return table

    def getGtkOutput(self):        
        tableString = "<table border=1><tr>"
        
        for tit in self._header:
            tableString += "<th>" + tit + "</th>"
        tableString += "</tr>"
        
        for row in self._rows:
            tableString += "<tr>"
            for field in row:
                tableString += "<td>" + field.strip() + "</td>"
            tableString += "</tr>"
        
        tableString += "</table>"
        
        return tableString

    def getTitle(self):
        return self._title

    def setTitle(self, value):
        self._title = value
        
