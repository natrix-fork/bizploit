# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
class baseResult:
	'''
	"Abstract" class for result objects
	'''

	def __init__( self, key):
		self._key = key
		self._title = ''
		self._data = None
		
	def setTitle(self,  title):
		self._title = title
		
	def getTitle(self):
		return self._title
	
	def getKey(self):
		return self._key
	
	def setData(self,  data):
		self._data = data
		
	def getData(self):
		return self._data

	def getConsoleOutput(self):
		raise 'Must be implemented by concrete result objects.'
		
	def getGtkOutput(self):
		raise 'Must be implemented by concrete result objects.'
	
	
	
