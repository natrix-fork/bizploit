# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Andres Riancho    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Andres Riancho

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

import traceback

import core.kb.knowledgeBase as kb        
from core.ui.consoleUi.util import *
from core.ui.consoleUi.history import *
from core.ui.consoleUi.help import *
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
from core.data.parseOptions import parseXML
from core.data.options.option import *
from core.data.options.optionList import optionList


class menu:
	'''
	Menu objects handle the commands and completion requests.
	Menus form an hierarchy and are able to delegate requests to their children.
	@author Alexander Berezhnoy (alexander.berezhnoy |at| gmail.com)
	'''

	def suggest(self, tokens, part, onlyLocalCommands=False):
		'''
		Suggest the possible completions
		@parameter tokens: list of string
		@parameter part: base for completion
		'''
		if len(tokens)==0:
			return self.suggestCommands(part, onlyLocalCommands)
		return self.suggestParams(tokens[0], tokens[1:], part)

	def isRaw(self=None):
		return False

	def getPath(self):
		if self._parent is None:
			return self._name
		else:
			return self._parent.getPath() + '/' + self._name

	def getHistory(self):
		return self._history

	def __init__(self, name, console, bizploit, parent=None, **other):
		self._name = name
		self._history = history()
		
		self._help = help()
		self._keysHelp = help()
		self._bizploit = bizploit
		self._handlers = {}
		self._parent = parent
		self._console = console
		self._children = {}
		self._onExitHandler = None

		self._loadHelp('common')
		helpMainRepository.loadHelp('keys', self._keysHelp)

		self._initHandlers()

	def _initHandlers( self ):
		self._universalCommands = ['back', 'exit', 'keys']
		
		self._paramHandlers = {}
		for cmd in [c for c in dir(self) if c.startswith('_cmd_')]:
			self._handlers[cmd[5:]] =  getattr(self, cmd)

		for cmd in self._handlers.keys():
			try:
				pHandler = getattr(self, '_para_'+cmd)
				self._paramHandlers[cmd] = pHandler
			except:
				pass

	def _loadHelp(self, name, vars=None):
		helpMainRepository.loadHelp(name, self._help, vars)

	def addChild(self, name, constructor):
		if type(constructor) in (tuple, list):
			constructor, params = constructor[0], constructor[1:]
		else:
			params = []

		self._children[name] = constructor(name, self._console, self._bizploit, self, *params)


	def suggestCommands(self, part='', onlyLocal=False):

		first, rest = splitPath(part)

		if rest is None:
			# the command must be in the current menu
			result = suggest(self.getCommands(onlyLocal), part)
			if self.getChildren() is not None:
				result +=   suggest(self.getChildren(), part)
			return result
		else:
			try:
				# delegate to the children
				subMenu = self.getChildren()[first]
				return subMenu.suggestCommands(rest, True)
			except:
				return []

	def suggestParams(self, command, params, part):
		if command in self._paramHandlers:
			return self._paramHandlers[command](params, part)

		children = self.getChildren()
		if command in children:
			child = children[command]
			return child.suggest(params, part, True)


	def getCommands(self, onlyLocal=False):
		'''
		By default, commands are defined by methods _cmd_<command>.
		'''
		cmds = self._handlers.keys()

		if onlyLocal:
			cmds = [c for c in cmds if c not in self._universalCommands]

		return cmds

	def getChildren(self):
		return self._children #self.getCommands()

	def getHandler(self, command):
		try:
			return self._handlers[command]
		except:
			return None
			

	def execute(self, tokens):

		if len(tokens) == 0:
			return self

		command, params = tokens[0], tokens[1:]
		handler = self.getHandler( command )
		if handler:
			return handler( params )

		children = self.getChildren()
		if command in children:
			child = children[command]
			return child.execute( params )

		raise bizploitException("Unknown command '%s'" % command)


	def _cmd_back(self, tokens):
		return self._console.back

	def _cmd_exit(self, tokens):
		return self._console.exit


	def _cmd_help(self, params, brief=False):
		if len(params) == 0:
			table = self._help.getPlainHelpTable(True)
			self._console.drawTable(table)
		else:
			subj = params[0]
			short, full = self._help.getHelp(subj)
			if short is None:
				raise bizploitException("No help for '%s'" % subj)

			om.out.console(self, short)
			if full:
				om.out.console(self, full)
				

	def _cmd_keys(self, params=None):
		table = self._keysHelp.getPlainHelpTable(True)
		self._console.drawTable(table)
		
	def _para_help(self, params, part):
		if len(params) ==0:
			return suggest(self._help.getItems(), part)
		else:
			return []

		
	def _getOptions(self,  configurable):
		'''
		This method is a wrapper around a new way to use options within bizploit.
		It is only used by the CLI. This is not nice, but the only way to keep compatibility with already developed plugins by thrid parties.
		'''
		options = parseXML(configurable.getOptionsXML())
		optList = optionList()
		for opt in options.keys():
			optList.append(OptionTranslateToNew(opt, options[opt]))
		
		return optList

	def _onExit(self):
		if self._onExitHandler == None:
			return
		else:
			apply(self._onExitHandler,  self._onExitHandlerArgs)
	
	def _setOnExitHandler(self,  handler,  *args):
		self._onExitHandler = handler
		self._onExitHandlerArgs = args
		
	def _onStart(self):
		return 
