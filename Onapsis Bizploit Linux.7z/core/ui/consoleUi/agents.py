# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import core.output.outputManager as om
from core.lib.misc import *
from core.ui.consoleUi.interactiveExploit import *
from core.ui.consoleUi.menu import *


class agentsMenu(menu):
	'''
	Menu for managing agents.
	
	@author: Mariano Nu�ez Di Croce 
	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)
		self._agents = self._bizploit.getAgents()

		self._loadHelp('agents')
	
	def _cmd_show(self, parameters):
		'''
		Show available agents 
		'''
		for agentObj in self._agents:
				om.out.console(self,'Agent ID: ' + str(agentObj.getID()) + ' [' + agentObj.getName() + ']')
				om.out.console(self,'\tTarget information (#' + str(agentObj.getTarget().getID()) + '): ')
				parsedConf = agentObj.getTarget().getConfiguration().split('\n')
				for line in parsedConf:
					om.out.console(self,'\t ' + line)
					
				om.out.console(self,'\t Connector: ' + agentObj.getConnector().getName() + ' (#' + str(agentObj.getConnector().getID()) + ')')
				parsedConf = agentObj.getConnector().getConfiguration().split('\n')
				for line in parsedConf:
					om.out.console(self,'\t ' + line)
		
				om.out.console(self,' ')
	
	def _cmd_kill(self, parameters):
		'''
		Kills a spawned agent
		'''
		if len(parameters) == 0:
			self._cmd_help(['kill'])
		else:
			ids = [s.getID() for s in self._agents]
			try:
				id = validateID(parameters[0], 'agent',  idList=ids)
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
			
			for agentObj in self._agents:
				if agentObj.getID() == id:
					agentObj.stop()
					self._bizploit.removeAgent(agentObj)
					om.out.information(self,'Agent #' + str(id) + ' killed.')					
					return True
				
			om.out.information(self,'Agent ID not found.')			
	

	def _cmd_start(self, parameters):
		'''
		Starts a new agent
		'''
		if len(parameters) == 0:
			self._cmd_help(['start'])
		else:
			ids = [s.getID() for s in self._agents]
			try:
				id = validateID(parameters[0], 'agent',  idList=ids)
			except bizploitException,  e:
				om.out.console(self, str(e))
				return
			
			# Create a menu for the agent and return it
			agentObj = self._bizploit.findAgentByID(id)
			om.out.information(self, 'Starting agent #' + str(id))
			return interactiveExploitMenu('agent/' + str(id), self._console, self._bizploit, self,  agentObj)		
			
