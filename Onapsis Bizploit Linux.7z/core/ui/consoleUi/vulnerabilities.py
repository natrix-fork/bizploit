# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
import copy
from core.ui.consoleUi.menu import *
from core.ui.consoleUi.config import *
from core.ui.consoleUi.util import *
import core.output.outputManager as om
from core.exceptions.bizploitException import bizploitException
from core.data.parseOptions import parseXML
from fwk.connectors.baseTarget import baseTarget
from core.lib.misc import *
from core.baseResult.tableResult import tableResult
import sys

class vulnerabilitiesMenu(menu):
	'''
	Menu for viewing vulnerabilities.
	@author: Mariano Nu�ez Di Croce 

	'''

	def __init__(self, name, console, bizploit, parent):
		menu.__init__(self, name, console, bizploit, parent)
	
		self._loadHelp('vulnerabilities')
	
	def _cmd_show(self, parameters):
		'''
		Show discovered vulnerabilities 
		'''
		table = [['ID', 'Name', 'Target-Connector',  'Exploitable by']]
		
		vulns = self._bizploit.getPluginResults(onlyVulns=True)
		
		if len(vulns) == 0:
			om.out.console(self, 'No vulnerabilities discovered so far.')
			return
		
		for vuln in vulns:
			row = []

			row.append(str(vuln.getID()))			
			row.append(vuln.getName())
			
			target,  conn = vuln.getConnectionInfo()			
			row.append(target.getHost() + '(' + str(target.getID()) + ')-' + conn.getName() + '(' + str(conn.getID()) + ')')
			
			# Get exploit plugins and check who can exploit this vuln.
			plugins = self._bizploit.getPluginList('exploit')
			res = []
			for pName in plugins:
				pInst = self._bizploit.getPluginInstance(pName,  'exploit')
				if pInst.canExploit(vuln):
					res.append(pName)
			
			row.append(', '.join(res))
			table.append(row)
		self._console.drawTable(table, True)

	def _cmd_viewDetails(self, parameters):
		'''
		Show information from a particular vulnerability
		'''
		if len(parameters) == 0:
			self._cmd_help(['viewDetails'])
			return 
		
		ids = [v.getID() for v in self._bizploit.getPluginResults(onlyVulns=True)]
		try:
			id = validateID(parameters[0], 'vulnerability',  idList=ids)
		except bizploitException,  e:
			om.out.console(self, str(e))
			return
		
		vuln = self._bizploit.findVulnerabilityByID(id)
		
		# Print vuln info
		table = []
		row = []
		row.append('Name')
		row.append(vuln.getName())
		table.append(row)
		row = []
		row.append('Risk')
		row.append(vuln.getRiskAsString())
		table.append(row)
		row = []
		row.append('Description')
		row.append(vuln.getDesc())
		table.append(row)
		
		if len(vuln.getSolution()) > 0:		
			row = []
			row.append('Solution')
			row.append(vuln.getSolution())
			table.append(row)
		
		if len(vuln.getRef()) > 0:		
			row = []			
			row.append('References')
			row.append(','.join(vuln.getRef()))
			table.append(row)	
		
		om.out.console(self,  'Vulnerability Summary:')
		self._console.drawTable(table, False)
		
		# Check for results
		for res in vuln.getResults():
			if isinstance(res,  tableResult):
				om.out.console(self,  'Vulnerability Information - ' + res.getTitle() + ':')
				self._console.drawTable(res.getConsoleOutput(), True)
			else:
				om.out.console(self,  'Vulnerability Information - ' + res.getKey() + ':')
				om.out.console(self, res.getConsoleOutput())
	
	def _para_viewDetails(self, params, part):
		l = len(params)
		if l==0:
			pos = [v.getID() for v in self._bizploit.getPluginResults(onlyVulns=True)]
			return suggest(pos, part)
		return []
