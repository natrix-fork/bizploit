# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Anres Riancho    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Andres Riancho

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''


from core.ui.consoleUi.menu import *
from core.ui.consoleUi.plugins import *
from core.ui.consoleUi.targets import *
from core.ui.consoleUi.shells import *
from core.ui.consoleUi.exploit import *
from core.ui.consoleUi.agents import *
from core.ui.consoleUi.tools import *
from core.ui.consoleUi.vulnerabilities import *
from core.ui.consoleUi.reporting import *
from core.ui.consoleUi.util import *
import core.ui.consoleUi.io.console as term

from core.exceptions.bizploitException import *

import threading
import sys
import time
import select


class rootMenu(menu):
	'''
	Main menu
	'''

	def __init__(self, name, console, core, parent=None):
		menu.__init__(self, name, console, core, parent)
		self._loadHelp( 'root' )

		mapDict(self.addChild, {	'plugins': pluginsMenu,  \
												'targets': targetsMenu,  \
												'config': (configMenu,  self._bizploit._config),  \
												'shells': shellsMenu,  \
												'agents': agentsMenu,  \
												'tools': toolsMenu,  \
												'vulnerabilities': vulnerabilitiesMenu,  \
												'exploit': exploitMenu,  \
												'reporting': reportingMenu
											})

	   
	def _cmd_start(self, params):
		'''
		Start the core in a different thread, monitor keystrokes in the main thread.
		@return: None
		'''
		self._bizploit.start(params)

	def _cmd_version(self, params):
		'''
		Show the bizploit version and exit
		'''
		om.out.console(self,  self._bizploit.getFullVersionInfo() )
