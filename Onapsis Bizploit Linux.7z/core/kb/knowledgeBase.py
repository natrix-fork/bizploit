# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.baseResult.pluginResult import pluginResult
import gobject
from gobject import GObject

class knowledgeBase(GObject):
    __gsignals__ = dict(new_vul=(gobject.SIGNAL_RUN_FIRST,
                    gobject.TYPE_NONE,()))
    
    '''
    This class records all data saved by plugins. 
    
    @author: Mariano Nu�ez Di Croce  
    '''
    
    def __init__(self):
        GObject.__init__(self)
        self._kb = {}
        self._globalKB = {}
        self._resIDCounter = 0
    
    def addNewEntry(self, connector):
        '''
        Adds a new connector entry to the knowledgeBase
        '''
        if connector not in self._kb.keys():
            self._kb[connector] = {}
    
    def removeEntry(self, connector):
        '''
        Removes a connector entry of the knowledgeBase
        '''
        if connector in self._kb.keys():
            del self._kb[connector]
    
    def save( self, connector, callingInstance, key, value):
        '''
        Save the specified value in the kb dictionary, according to the key specified.
        '''          
        name = callingInstance.__class__.__name__
        if name == 'str':
            name = callingInstance
        
        # Only one vuln of the same type        
        if isinstance(value, pluginResult) and value.isVulnerability():
            try:                
                # Check that this vulnerability is not already stored
                res = self._kb[connector][name][key]
                value.setID(res.getID())
            except:           
                value.setID(self._resIDCounter)
                self._resIDCounter += 1        
        if name not in self._kb[connector].keys():
            self._kb[connector][ name ] = { key: value }            
        else:
            self._kb[connector][ name ][ key ] = value
            
    def append( self, connector, callingInstance, key, value , unique=False):
        '''
        Append the specified value to the KB dict.
        '''
        name = callingInstance.__class__.__name__
        if name == 'str':
            name = callingInstance
            
        if isinstance(value, pluginResult) and value.isVulnerability():
            value.setID(self._resIDCounter)
            self._resIDCounter += 1
            
        if name not in self._kb[connector].keys():
            self._kb[connector][ name ] = { key: [value,] }
        else:
            if key in self._kb[connector][name].keys():
                if (unique and value not in self._kb[connector][name][key]) or not unique:
                    self._kb[connector][ name ][ key ].extend([value,])                
            else:
                self._kb[connector][ name ][ key ] = [value,]
                

    
    def getData( self, connector, key ):
        '''
        Get the data without caring on which plugin set it.
        @return: value saved in the KB by plugin
        '''
        res = []
        if connector not in self._kb.keys():
            return []
            
        for plugin in self._kb[connector].keys():
            if key in self._kb[connector][ plugin ].keys():
                return self._kb[connector][ plugin ][ key ]        
        
        return []
    
    def getDataForConnector ( self, connector):
        '''
        @return: value saved in the KB by plugin
        '''
        if connector not in self._kb.keys():
            return {}
        else:
            return self._kb[connector]
    
    def getRootEntries(self):
        return self._kb.keys()
    
    def getPluginsForConnector(self,  connector):
        return self._kb[connector].keys()
        
    def getKeysForPlugin(self,  connector,  plugin):
        return self._kb[connector][plugin]
    
    def getResultForKey( self, connector, plugin, key):
        '''
        @return: value saved in the KB by plugin
        '''        
        try:
            return self._kb[connector][ plugin ][ key ]
        except:                
            return None
    
    def dump(self):
        return self._kb
    
    # Methods for handling bizploitCore data.
    def saveGlobal(self,  key,  value):
        self._globalKB[key] = value
    
    def getGlobal(self,  key):
        if key in self._globalKB.keys():
            return self._globalKB[key]
        else:
            return None
        
# Make KB world-available
globalKB = knowledgeBase()
