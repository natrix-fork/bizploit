# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

import re
import xml.dom.minidom
from core.exceptions.bizploitException import bizploitException


def parseOptions( pluginName, optionsMap ):
    '''
    Parses options from the getOptions() and returns a the parsed result.
    '''
    parsedOptions = {}
    for i in optionsMap.keys():
        type = optionsMap[i]['type']
        value = optionsMap[i]['default']
        required = optionsMap[i]['required']
        res = None
        
        if required.lower() == 'true' and len(value) == 0:
            raise bizploitException('Option \'' + i + '\'cannot be empty.')
        
        try:
            type = type.lower()
            if type == 'integer':
                res = int(value)
            elif type == 'float':
                res = float(value)
            elif type == 'boolean':
                if value.lower() == 'true':
                    res = True
                elif value.lower() == 'false':
                    res = False
                else:
                    raise ValueError()
            elif type == 'list':
                # Yes, we are regex dummies
                value += ','
                res = re.findall('(\'.*?\'|.*?),', value)
                if res != []:
                    res = [y.strip() for y in res if y != '']
                else:
                    raise ValueError
            elif type == 'NumericList':
                # Yes, we are regex dummies
                value += ','
                res = re.findall('(.*?),', value)
                if res != []:
                    res = [int(y.strip()) for y in res]
                else:
                    raise ValueError
            elif type == 'string':
                res = str(value)
            else:
                raise bizploitException('Unknown type: ' + type)
        except ValueError:
            raise bizploitException('The variable "'+ i +'" has the following value: "' + value + '" and cannot be casted to "' + type + '".')
        else:
            parsedOptions[ i ] = res
    
    return pluginName, parsedOptions

def parseXML(xmlString ):
        xmlString.replace( '\t' , '' )
        xmlDoc = xml.dom.minidom.parseString( xmlString )
        
        options = {}
        
        def setParameter( optionName, tag ):
            try:
                options[ optionName ][ tag ] = option.getElementsByTagName(tag)[0].childNodes[0].data
            except:
                options[ optionName ][ tag ] = ''
                
        def setOrder( optionName, order ):
            options[ optionName ][ 'order' ] = str(order)
    
        counter = 0
        for option in xmlDoc.getElementsByTagName('Option'):
            optionName = option.getAttribute('name')
            options[ optionName ] = {}       
        
            setParameter( optionName, 'default' )
            setParameter( optionName, 'desc' )
            setParameter( optionName, 'help' )
            setParameter( optionName, 'type' )
            setParameter( optionName, 'required' )
            setParameter( optionName, 'visible' )
            setOrder( optionName, counter)
            counter += 1
                
        xmlDoc.unlink()
        return options
