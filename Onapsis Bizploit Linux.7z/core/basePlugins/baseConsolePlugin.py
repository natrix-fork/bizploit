# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from core.basePlugins.basePlugin import basePlugin
from core.ui.consoleUi.menu import menu

class baseConsolePlugin(basePlugin,  menu):

    def __init__( self ):
        basePlugin.__init__(self)

        self._commands = []
        self._commandHistory = []
        self._parent = None
        
    def setParentMenu(self,  menu):
        self._parent = menu
    
    def _exec( self, command ):
        '''
        Executes a user input.
        '''
        command, parameters = self._parse( command )
        
        if command != '':
            if command in self._menu.keys():
                #self._om.console(self, command + ' ' + ' '.join(parameters))
                func = self._menu[command]
                # We have to redirect the execution to the appropiate Connector method.
                # Connector methods are str objects,
                if isinstance(func, str):
                    funcName = func + '_' + self._connector.getName()
                    func = getattr(self, funcName)
                try:
                    res = func(parameters)
                except bizploitException,e:
                    #om.out.console(self, str(e) )
                    raise e
                else:
                    return res
            else:
                self._om.console(self, 'command not found' )
            
            self._om.console(self, '')
            return True
    
    # We redefine the run method to consolePlugins
    def run(self):
        self.sh()
    
    def setCommands(self, commands):
        self._commands = commands
    
    def _parse( self, command ):
        '''
        Parses the user input.
        
        @return: A command and its parameters in a tuple.
        '''
        self._commandHistory.append( command )
        c = command.split(' ')[0]
        p = []
        p.extend( command.split(' ')[1:] )
        return c, p
    
    # Redefine the __getattr__ method to avoid defining foo methods.
    def __getattr__(self, attrName):
        return attrName
