# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
	
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.basePlugins.basePlugin import basePlugin
from core.exceptions.bizploitException import bizploitException

class baseOutputPlugin(basePlugin):
	'''
	This is the base class for data output, all output plugins should inherit from it and implement the following methods :
		1. debug( message, verbose )
		2. information( message, verbose )
		3. error( message, verbose )
		4. vulnerability( message, verbose )

    @author: Andres Riancho ( andres.riancho@gmail.com )
    '''

	def __init__(self):
		self._pluginDeps = []
		self.verbosity = 0
	
	def initialize(self):
		'''
		Method for custom initialization by output plugins.
		'''
		
	def debug(self, message ):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action for debug messages.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method debug' )

	def information(self, message, verbose):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action for information messages.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method information' )

	def error(self, message, verbose):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action for error messages.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method error' )

	def vulnerability(self, message ):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action for vulnerability messages.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method vulnerability' )

	def console(self, message ):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action for vulnerability messages.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method console' )
	
	def logHttp(self, request, response ):
		'''
		This method is called from the output managerobject. The OM object was called from a plugin
		or from the framework. This method should take an action to log HTTP requests and responses.
		
		@return: No value is returned.
		'''
		raise bizploitException('Plugin is not implementing required method logHttp.' )
		
	def setOptions( self, OptionList ):
		'''
		Sets the Options given on the OptionList to self. The options are the result of a user
		entering some data on a window that was constructed using the XML Options that was
		retrieved from the plugin using getOptionsXML()
		
		This method MUST be implemented on every plugin. 
		
		@return: No value is returned.
		'''	
		if 'verbosity' in OptionList.keys():
			self.verbosity = OptionList['verbosity']
		

	def getOptionsXML(self):
		'''
		This method returns a XML containing the Options that the plugin has.
		Using this XML the framework will build a window, a menu, or some other input method to retrieve
		the info from the user. The XML has to validate against the xml schema file located at :
		bizploit/core/display.xsd
		
		This method MUST be implemented on every plugin. 
		
		@return: XML String
		@see: core/display.xsd
		'''
		return	'<?xml version="1.0" encoding="ISO-8859-1"?>\
		<OptionList>\
			<Option name="verbosity">\
				<default>0</default>\
				<desc>Verbosity level for this plugin.</desc>\
				<type>Integer</type>\
			</Option>\
		</OptionList>\
		'

	def getPluginDeps( self ):
		'''
		@return: A list with the names of the plugins that should be 
		runned before the current one.
		'''
		return self._pluginDeps

	def getMessageCache(self):
		'''
		Ouput plugins with caches should implement this method.
		'''
		return {}
	
	def isConfigurable(self):
		return (len(self.getOptionsXML()) > 0)


	def getType(self):
		return 'output'
	
	def checkSanity(self):
		return True
