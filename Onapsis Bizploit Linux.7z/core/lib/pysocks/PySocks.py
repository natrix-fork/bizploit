# -*- coding: latin-1 -*-
'''
SOCKS 4 proxy server class.

---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Xavier Lagraula    
Modified by Mariano Nu�ez Di Croce for Bizploit.
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright (C) 2001  Xavier Lagraula
See COPYRIGHT.txt and GPL.txt for copyrights information.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''

from core.exceptions.bizploitException import bizploitException
import core.output.outputManager as om
import threading
import thread
import time
import socket
import select
import os
import sys
import struct
#import core.output.outputManager as om

# SOCKS 4 protocol constant values.
SOCKS_VERSION                = 4
COMMAND_CONNECT                 = 1
COMMAND_BIND                    = 2
COMMANDS                        =  [    COMMAND_CONNECT,    COMMAND_BIND    ]
REQUEST_GRANTED                 = 90
REQUEST_REJECTED_FAILED         = 91
REQUEST_REJECTED_NO_IDENTD      = 92
REQUEST_REJECTED_IDENT_FAILED   = 93
# Sockets protocol constant values.
ERR_CONNECTION_RESET_BY_PEER    = 10054
ERR_CONNECTION_REFUSED          = 10061


# For debugging only.
def now():
	return time.ctime(time.time())


# Exception classes for the server
class SocksError(Exception): pass
class Connection_Closed(SocksError): pass
class Bind_TimeOut_Expired(SocksError): pass
class Request_Error(SocksError): pass

class Client_Connection_Closed(Connection_Closed): pass
class Remote_Connection_Closed(Connection_Closed): pass
class Remote_Connection_Failed(Connection_Closed): pass
class Remote_Connection_Failed_Invalid_Host(Remote_Connection_Failed): pass

class Request_Failed(Request_Error): pass
class Request_Failed_No_Identd(Request_Failed): pass
class Request_Failed_Ident_failed(Request_Failed): pass

class Request_Refused(Request_Error): pass
class Request_Bad_Version(Request_Refused): pass
class Request_Unknown_Command(Request_Refused): pass
class Request_Unauthorized_Client(Request_Refused): pass
class Request_Invalid_Port(Request_Refused): pass
class Request_Invalid_Format(Request_Refused): pass

# Server class
class socks4Proxy(threading.Thread):
	"""Threading SOCKS4 proxy class. """

	def __init__(self, bindAddress='127.0.0.1', bindPort=9999, connectHandler=None,  errHandler=None):
		threading.Thread.__init__(self)
		self._hander = None
		self._bindAddress = bindAddress
		self._bindPort = bindPort
		self._connectHandler = connectHandler
		self._errHandler = errHandler
		self._queueSize = 5
		
		self._srvSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	
		#om.out.debug(self,'The choosen ip adress is ' + self.external_ip)
	
	def run(self):
		# Bind to the listening port
		try:
			self._srvSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self._srvSocket.bind((self._bindAddress, self._bindPort))
			self._srvSocket.listen(self._queueSize)
		except socket.error,  e:
			# raise bizploitException(str(e))
			self._errHandler(str(e))
			return True
		
		while True:
			# Start listening for requests.
			try:
				sock, client_address = self._srvSocket.accept()
			except socket.error,  e:
				self._errHandler(str(e))
			req = sock.recv( 1024 ) 
			handler = socksHandler( sock, req )
			handler.setConnectHandler(self._connectHandler)
			handler.start()
	
	def stop(self):
		'''
		Stops the proxy
		'''
		self._srvSocket.close()
		
class socksHandler(threading.Thread):
	"""This request handler class handles SOCKS 4 requests."""

	def __init__(self, socket, req):
		threading.Thread.__init__(self)
		self._socket = socket
		self._req = req
		self._connHandler = self.handle_connect
		self._inacTimeout = 10
		self._bindTimeout = 10
		self._dataBuf = 1024
	
	def setConnectHandler(self, connHandler):
		self._connHandler = connHandler
	
	def run(self):
		try:
			decReq = self.decode_request(self._req) 
			self.handle(decReq)
		except:
			pass
	
	def handle(self, req):
		"""This function is the main request handler function."""
		

		try:
			# Read and decode the request from the client and verify that it
			# is well-formed.
			#print thread.get_ident(), 'Decoded request:', req

			# We are here so the request is valid.
			# We must decide of the action to take according to the "command"
			# part of the request.
			if req['command'] == COMMAND_CONNECT:
				self._connHandler(req, socksHandler = self, socksCliSocket = self._socket)
			elif req['command'] == COMMAND_BIND:
				self.handle_bind(req)

		# Global SOCKS errors handling.
		except Request_Failed_No_Identd:
			self.answer_rejected(REQUEST_REJECTED_NO_IDENTD)
		except Request_Failed_Ident_failed:
			self.answer_rejected(REQUEST_REJECTED_IDENT_FAILED)
		except Request_Error:
			self.answer_rejected()
		except Remote_Connection_Failed:
			self.answer_rejected()
		except Bind_TimeOut_Expired:
			self.answer_rejected()
		# Once established, if the remote or the client connection is closed
		# we must exit silently. This exception is in fact the way the function
		# used to forward data between the client and the remote server tells
		# us it has finished working.
		except Connection_Closed:
			pass


	def decode_request(self, data):
		"""This function reads the request socket for the request data, decodes
it and checks that it is well formed."""
		
		# It is useless to process too short a request.
		if len(data) < 9: 
			raise Request_Invalid_Format(data)
		
		# Extracting components of the request. Checks are made at each step.
		req = {}

		# SOCKS version of the request
		
		req['version']  = ord(data[0])
		if req['version'] != SOCKS_VERSION:
			raise Request_Bad_Version(req)

		# Command used.
		req['command']  = ord(data[1])
		if not req['command'] in COMMANDS:
			raise Request_Unknown_Command(req)

		# Address of the remote peer.
		req['address']  = (
			socket.inet_ntoa(data[4:8]),
			self.string2port(data[2:4]))
		if not is_port(req['address'][1]):
			raise Request_Invalid_Port(req)
		# Note: only the fact that the port is in [1, 65535] is checked here.
		# Address and port legitimity are later checked in validate_request.

		# Requester user ID. May not be provided.
		req['userid']   = self.get_string(data[8:])

		# If we are here, then the request is well-formed. Let us return it to
		# the caller.
		return req


	def handle_bind(self, req):
		"""This function handles a BIND request."""
		
		# Create a socket to receive incoming connection.
		remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		# From now on, whatever we do, we must close the "remote" socket before
		# leaving. I love try/finally blocks.
		try:
			# In this block, the only open connection is the client one, so a
			# ERR_CONNECTION_RESET_BY_PEER exception means "exit silently
			# because you won't be able to send me anything anyway".
			# Any other exception must interrupt processing and exit from here.
			try:
				# Binding the new socket to the chosen external ip
				remote.bind((self.server.external_ip, 0))
				remote.listen(1)

				# Collecting information about the socket to store it in the
				# "waiting binds" list.
				socket_ip, socket_port = remote.getsockname()
			except socket.error:
				# A "connection reset by peer" here means the client has closed
				# the connection.
				exception, value, traceback = sys.exc_info()
				if value[0] == ERR_CONNECTION_RESET_BY_PEER:
					raise Client_Connection_Closed((ERR_CONNECTION_RESET_BY_PEER, socket.errorTab[ERR_CONNECTION_RESET_BY_PEER]))
				else:
					# We may be able to make a more precise diagnostic, but
					# in fact, it doesn't seem useful here for now.
					raise Remote_Connection_Failed

			# Sending first answer meaning request is accepted and socket
			# is waiting for incoming connection.
			self.answer_granted(socket_ip, socket_port)

			try:
				# Waiting for incoming connection. I use a select here to
				# implement the timeout stuff.
				read_sock, junk, exception_sock = select.select([remote], [], [remote],self._bindTimeout)
				# If all lists are empty, then the select has ended because
				# of the timer.
				if (read_sock, junk, exception_sock) == ([], [], []):
					raise Bind_TimeOut_Expired
				# We also drop the connection if an exception condition is
				# detected on the socket. We must also warn the client that
				# its request is rejecte (remember that for a bind, the client
				# expects TWO answers from the proxy).
				if exception_sock:
					raise Remote_Connection_Failed

				# An incoming connection is pending. Let us accept it
				incoming, peer = remote.accept()
			except:
				# We try to keep a trace of the previous exception
				# for debugging purpose.
				raise Remote_Connection_Failed(sys.exc_info())

			# From now on , we must not forget to close this connection.
			try:
				# We must now check that the incoming connection is from
				# the expected server.
				if peer[0] != req['address'][0]:
					raise Remote_Connection_Failed_Invalid_Host

				# We can now tell the client the connection is OK, and
				# start the forwarding process.
				self.answer_granted()
				self.forward(self.request, incoming)
			# Mandatory closing of the socket with the remote peer.
			finally:
				incoming.close()

		# Mandatory closing ofthe listening socket
		finally:
			remote.close()


	def handle_connect(self, req, socksHandler = None, socksCliSocket=None):
		"""This function handles a CONNECT request."""
		
		# Create a socket to connect to the remote server
		remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		# From now on, we must not forget to close this socket before leaving.
		try:
			try:
				# Connection to the remote server
				om.out.debug(self,'agent: Connecting to', req['address'])


				# Possible way to handle the timeout defined in the protocol!
				# Make the connect non-blocking, then do a select and keep
				# an eye on the writable socket, just as I did with the
				# accept() from BIND requests.
				# Do this tomorrow... Geez... 00:47... Do this this evening.
				
				remote.connect(req['address'])
				
			# The only connection that can be reset here is the one of the
			# client, so we don't need to answer. Any other socket
			# exception forces us to try to answer to the client.
			except socket.error:
				exception, value, traceback = sys.exc_info()
				if value[0] == ERR_CONNECTION_RESET_BY_PEER:
					raise Client_Connection_Closed((ERR_CONNECTION_RESET_BY_PEER, socket.errorTab[ERR_CONNECTION_RESET_BY_PEER]))
				else:
					raise Remote_Connection_Failed
			except:
				raise Remote_Connection_Failed
		
			# From now on we will already have answered to the client.
			# Any exception occuring now must make us exit silently.
			try:
				# Telling the client that the connection it asked for is
				# granted.
				self.answer_granted()
				# Starting to relay information between the two peers.
				self.forward(self._socket, remote)
			# We don't have the right to "speak" to the client anymore.
			# So any socket failure means a "connection closed" and silent
			# exit.
			except socket.error:
				raise Connection_Closed
		# Mandatory closing of the remote socket.
		finally:
			remote.close()

	def answer_granted(self, dst_ip = '0.0.0.0', dst_port = 0):
		"""This function sends a REQUEST_GRANTED answer to the client."""
		self.answer(REQUEST_GRANTED, dst_ip, dst_port)

	def answer_rejected(self, reason = REQUEST_REJECTED_FAILED, dst_ip = '0.0.0.0', dst_port = 0):
		"""This function send a REQUEST_REJECTED answer to the client."""
		self.answer(reason, dst_ip, dst_port)

	def answer(self, code = REQUEST_GRANTED, ip_str = '0.0.0.0', port_int = 0):
		"""This function sends an answer to the client. This has been
factorised because all answers follow the same format."""

		# Any problem occuring here means that we are unable to "speak" to
		# the client -> we must act as if the connection to it had already
		# been closed.
		try:
			ip      = socket.inet_aton(ip_str)
			port    = self.port2string(port_int)
			packet  = chr(0)        # Version number is 0 in answer
			packet += chr(code)     # Error code
			packet += port
			packet += ip
			self._socket.send(packet)
		except Exception, ex:
			# Trying to keep a trace of the original exception.
			raise ex
			raise Client_Connection_Closed(sys.exc_info())

	def forward(self, client_sock, server_sock):
		"""This function makes the forwarding of data by listening to two
sockets, and writing to one everything it reads on the other.

This is done using select(), in order to be able to listen on both sockets
simultaneously and to implement an inactivity timeout."""
		
		# Once we're here, we are not supposed to "speak" with the client
		# anymore. So any error means for us to close the connection.
		
		# These are not used to anything significant now, but I keep them in
		# case I would want to do some statistics/logging.
		octets_in, octets_out = 0, 0
		try:
			try:
				# Here are the sockets we will be listening.
				sockslist = [client_sock, server_sock]
				while 1:
					# Let us listen...
					readables, writeables, exceptions = select.select(sockslist, [], [], self._inacTimeout)
					# If the "exceptions" list is not empty or if we are here
					# because of the timer (i.e. all lists are empty), then
					# we must must bail out, we have finished our work.
					if (exceptions
						or (readables, writeables, exceptions) == ([], [], [])):
						raise Connection_Closed

					# Only a precaution.                    
					data = ''

					# Just in case we would be in the improbable case of data
					# awaiting to be read on both sockets, we treat the
					# "readables" list as if it oculd contain more than one
					# element. Thus the "for" loop...
					for readable_sock in readables:
						# We know the socket we want to read of, but we still
						# must find what is the other socket. This method
						# builds a list containing one element.
						writeableslist = [client_sock, server_sock]
						writeableslist.remove(readable_sock)

						# We read one chunk of data and then send it to the
						# other socket
						data = readable_sock.recv(self._dataBuf)
						# We must handle the case where data=='' because of a
						# bug: we sometimes end with an half-closed socket,
						# i.e. a socket closed by the peer, on which one can
						# always read, but where there is no data to read.
						# This must be detected or it would lead to an infinite
						# loop.
						if data:
							writeableslist[0].send(data)
							# This is only for future logging/stats.
							if readable_sock == client_sock:
								octets_out += len(data)
							else:
								octets_in += len(data)
						else:
							# The sock is readable but nothing can be read.
							# This means a poorly detected connection close.
							raise Connection_Closed
			# If one peer closes its conenction, we have finished our work.
			except socket.error:
				exception, value, traceback = sys.exc_info()
				if value[0] == ERR_CONNECTION_RESET_BY_PEER:
					raise Connection_Closed
				raise
		finally:
			#print thread.get_ident(), octets_in, 'octets in and', octets_out, 'octets out. Connection closed.'
			pass


	def string2port(self, port_str):
		"""This function converts between a packed (16 bits) port number to an
integer."""
		return (ord(port_str[0]) << 8) + ord(port_str[1])

	def port2string(self, port):
		"""This function converts a port number (16 bits integer) into a packed
string (2 chars)."""
		return chr((port & 0xff00) >> 8)+ chr(port & 0x00ff)

	def get_string(self, nullterminated):
		"""This function converts a null terminated string stored in a Python
string to a "normal Python string."""
		return nullterminated[0: nullterminated.index(chr(0))]

def is_routable(address):
    # Splitting the address in its 4 components.
    first, second, junk1, junk2 = address.split('.')
    # Testing the address against the given intervals.
    if (first in ['10', '127']
        or (first == '172' and second >= '16' and second <= '31')
        or ((first, second) == ('192', '168'))):
        return 0
    return 1

def is_port(port):
    return (port > 0) and (port < 65536)

if __name__ == "__main__":
	server = socks4Proxy()
	server.start()
