# -*- coding: latin-1 -*-
'''
---------------------------------------------------------------------------
Bizploit - The Opensource ERP Penetration Testing Framework. 
Download at http://www.onapsis.com/bizploit 
--------------------------------------------------------------------------- 

@author:  Mariano Nu�ez Di Croce <mnunez@onapsis.com>    
    
Portions Copyright 2010 ONAPSIS S.R.L.
Base Copyright Mariano Nu�ez Di Croce @ CYBSEC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
---------------------------------------------------------------------------
'''
from core.exceptions.bizploitException import bizploitException
from core.reporting.VulnerabilityHTMLReport import VulnerabilityHTMLReport

class reportFactory:
    '''
    report factory
    '''
    
    def __init__(self, bizploit, type, format, file='', mode='w'):
        self._bizploit = bizploit
        self._type = type
        self._file = file        
        self._mode = mode
        self._format = format
        self._supportedFormats = ['html']
        
        self._f = None
        
        
    def create(self):    
        
        result = ''
        
        # Check for supported report types
        if self._format not in self._supportedFormats:
            raise bizploitException('Report format \'' + self._format + '\' is not supported.')
        
        # If filename defined, check if we can open it in the requested mode
        if len(self._file) and len(self._mode):
            try:
                self._f = open(self._file, self._mode)                
            except Exception, e:
                raise bizploitException('It is not possible to open/create target file. Error: ' + str(e))
            
        if self._type == 'vulnerability':
            if self._format == 'html':
                result = VulnerabilityHTMLReport(self._bizploit).generate()
        else:
            raise bizploitException('Report type \'' + self._type + '\' not implemented.')
        
        # Save to file
        if len(result):
            self._f.write(result)
            self._f.close()
    